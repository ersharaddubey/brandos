async function j(url, opts = {}) {
  const r = await fetch(url, opts);
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || r.statusText);
  return d;
}
const send = (method, body) => ({ method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
const post = (url) => j(url, { method: 'POST' });

export const api = {
  health: () => j('/api/health'),
  stats: () => j('/api/stats'),
  identities: {
    list: (q = '') => j('/api/identities' + q),
    get: (id) => j(`/api/identities/${id}`),
    keys: () => j('/api/identities/meta/keys'),
    schema: () => j('/api/identities/meta/schema'),
    create: (fd) => j('/api/identities', { method: 'POST', body: fd }),
    addReference: (id, fd) => j(`/api/identities/${id}/reference`, { method: 'POST', body: fd }),
    update: (id, b) => j(`/api/identities/${id}`, send('PUT', b)),
    lock: (id) => post(`/api/identities/${id}/lock`),
    unlock: (id) => post(`/api/identities/${id}/unlock`),
    reanalyze: (id) => post(`/api/identities/${id}/reanalyze`),
    remove: (id) => j(`/api/identities/${id}`, { method: 'DELETE' }),
  },
  prompts: {
    list: (qs = '') => j('/api/prompts' + qs),
    create: (b) => j('/api/prompts', send('POST', b)),
    addVersion: (id, b) => j(`/api/prompts/${id}/versions`, send('POST', b)),
    setCurrent: (id, v) => post(`/api/prompts/${id}/current/${v}`),
    setVisibility: (id, visibility) => j(`/api/prompts/${id}/visibility`, send('PATCH', { visibility })),
    remove: (id) => j(`/api/prompts/${id}`, { method: 'DELETE' }),
  },
  assets: {
    list: (qs = '') => j('/api/assets' + qs),
    upload: (fd) => j('/api/assets', { method: 'POST', body: fd }),
    duplicates: (qs = '') => j('/api/assets/duplicates' + qs),
    setVisibility: (id, visibility) => j(`/api/assets/${id}/visibility`, send('PATCH', { visibility })),
    setCategory: (id, category) => j(`/api/assets/${id}/category`, send('PATCH', { category })),
    remove: (id) => j(`/api/assets/${id}`, { method: 'DELETE' }),
  },
  compile: (b) => j('/api/compile', send('POST', b)),
  check: (fd) => j('/api/compile/check', { method: 'POST', body: fd }),
  imageToPrompt: (fd) => j('/api/compile/image-to-prompt', { method: 'POST', body: fd }),
  generateImage: (b) => j('/api/compile/generate-image', send('POST', b)),
  generations: {
    list: () => j('/api/generations'),
    get: (id) => j(`/api/generations/${id}`),
    create: (b) => j('/api/generations', send('POST', b)),
  },
  groups: {
    list: (qs = '') => j('/api/groups' + qs),
    create: (b) => j('/api/groups', send('POST', b)),
    update: (id, b) => j(`/api/groups/${id}`, send('PATCH', b)),
    addAsset: (id, assetId) => j(`/api/groups/${id}/assets`, send('POST', { assetId })),
    remove: (id, body = {}) => j(`/api/groups/${id}`, send('DELETE', body)),
  },
  recycle: {
    list: () => j('/api/recycle'),
    restore: (id) => j(`/api/recycle/${id}/restore`, { method: 'POST' }),
    remove: (id) => j(`/api/recycle/${id}`, { method: 'DELETE' }),
    empty: () => j('/api/recycle', { method: 'DELETE' }),
  },
};
