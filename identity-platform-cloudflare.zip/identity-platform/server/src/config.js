import 'dotenv/config';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default {
  port: Number(process.env.PORT || 5000),
  mongoUri: process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/identity_platform',
  uploadDir: path.resolve(__dirname, '../uploads'),
  similarThreshold: Number(process.env.SIMILAR_THRESHOLD || 6),
  ollama: {
    url: process.env.OLLAMA_URL || 'http://127.0.0.1:11434',
    textModel: process.env.OLLAMA_TEXT_MODEL || 'qwen3:8b',
    visionModel: process.env.OLLAMA_VISION_MODEL || 'qwen3-vl:8b',
    keepAlive: process.env.OLLAMA_KEEP_ALIVE || '30m',
    analyzeMaxPx: Number(process.env.ANALYZE_MAX_PX || 768),
  },
  /** Identity analysis + consistency: ollama | cloudflare */
  analysis: {
    provider: (process.env.ANALYSIS_PROVIDER || 'cloudflare').toLowerCase(),
    accountId: process.env.CLOUDFLARE_ACCOUNT_ID || '',
    token: process.env.CLOUDFLARE_API_TOKEN || '',
    visionModel: process.env.CF_VISION_MODEL || '@cf/meta/llama-3.2-11b-vision-instruct',
    textModel: process.env.CF_TEXT_MODEL || '@cf/meta/llama-3.1-8b-instruct',
  },
  faceCheckUrl: process.env.FACE_CHECK_URL || '',
  generator: {
    provider: process.env.GENERATOR_PROVIDER || 'mock',
    url: process.env.GENERATOR_URL || 'http://127.0.0.1:8000/generate',
    width: Number(process.env.GEN_WIDTH || 1024),
    height: Number(process.env.GEN_HEIGHT || 1024),
    steps: Number(process.env.GEN_STEPS || 4),
    cloudflareToken: process.env.CLOUDFLARE_API_TOKEN || '',
  },
};
