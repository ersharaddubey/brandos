import mongoose from 'mongoose';
const { Schema } = mongoose;

const attempt = new Schema(
  {
    n: Number,
    prompt: String,
    assetId: { type: Schema.Types.ObjectId, ref: 'Asset' },
    score: Number, // 0-100, null = unchecked
    mismatches: [String],
    suggestions: [String],
    checks: [{ identityId: Schema.Types.ObjectId, name: String, score: Number }],
    note: String,
    error: String,
  },
  { _id: false }
);

const schema = new Schema(
  {
    campaignId: { type: Schema.Types.ObjectId, ref: 'Campaign' },
    identityIds: [{ type: Schema.Types.ObjectId, ref: 'Identity' }],
    inputs: {
      goal: String,
      scene: String,
      composition: String,
      style: String,
      templateId: String,
    },
    settings: { maxAttempts: { type: Number, default: 3 }, threshold: { type: Number, default: 75 } },
    status: { type: String, enum: ['running', 'done', 'error'], default: 'running' },
    attempts: [attempt],
    bestAttempt: Number,
    error: String,
  },
  { timestamps: true }
);

export default mongoose.model('Generation', schema);
