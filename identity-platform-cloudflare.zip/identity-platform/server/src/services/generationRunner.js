import Generation from '../models/Generation.js';
import Identity from '../models/Identity.js';
import PromptTemplate from '../models/PromptTemplate.js';
import Asset from '../models/Asset.js';
import { buildPrompt } from './promptBuilder.js';
import { generateImage } from './generator.js';
import { ingestImage, assetBase64 } from './assets.js';
import { checkConsistency, improvePrompt } from './consistency.js';

/** Generate -> Check -> Detect mismatch -> Improve -> Regenerate (until threshold or maxAttempts) */
export async function runGeneration(genId) {
  const gen = await Generation.findById(genId);
  try {
    const identities = await Identity.find({ _id: { $in: gen.identityIds }, status: 'locked' });
    if (!identities.length) throw new Error('No locked identities selected');

    let templateBody;
    if (gen.inputs.templateId) {
      const t = await PromptTemplate.findById(gen.inputs.templateId);
      templateBody = t?.versions.find((v) => v.version === t.currentVersion)?.body;
    }
    let prompt = buildPrompt({ identities, ...gen.inputs, templateBody });

    // har locked identity ki reference generator ko jaati hai (character pehle, taaki face/main reference priority le)
    const ordered = [...identities].sort((a, b) => (a.type === 'character' ? -1 : 0) - (b.type === 'character' ? -1 : 0));
    const referencesBase64 = [];
    for (const idn of ordered) {
      const refDoc = idn.referenceAssetIds?.[0] && (await Asset.findById(idn.referenceAssetIds[0]));
      if (refDoc) referencesBase64.push(await assetBase64(refDoc));
    }
    // scene nahi diya => reference ka background/lighting bhi lock rahega aur check me bhi enforce hoga
    const lockScene = !gen.inputs.scene;

    let best = { n: 0, score: -1 };
    for (let n = 1; n <= gen.settings.maxAttempts; n++) {
      const attempt = { n, prompt, mismatches: [], suggestions: [], checks: [] };
      const { buffer } = await generateImage({ prompt, referencesBase64 });

      let check = null;
      try {
        check = await checkConsistency({ identities, imageBuffer: buffer, lockScene });
        attempt.score = check.score;
        attempt.checks = check.checks;
        attempt.mismatches = check.mismatches;
        attempt.suggestions = check.suggestions;
      } catch (e) {
        attempt.error = `Consistency check failed: ${e.message}`;
      }

      const { asset } = await ingestImage({
        buffer, kind: 'generated', identityIds: identities.map((i) => i._id),
        campaignId: gen.campaignId, generationId: gen._id, prompt, score: attempt.score ?? undefined,
      });
      attempt.assetId = asset._id;

      gen.attempts.push(attempt);
      const sc = attempt.score ?? -1;
      if (sc > best.score || best.n === 0) best = { n, score: sc };
      gen.bestAttempt = best.n;
      await gen.save();

      if (attempt.score == null) {
        // unchecked (Ollama down / no references) -> cannot improve automatically
        attempt.note = 'Unchecked - stopping loop';
        break;
      }
      if (attempt.score >= gen.settings.threshold) {
        attempt.note = 'Passed threshold';
        break;
      }
      if (n < gen.settings.maxAttempts) prompt = await improvePrompt({ prompt, mismatches: attempt.mismatches, suggestions: attempt.suggestions });
    }
    gen.status = 'done';
  } catch (e) {
    gen.status = 'error';
    gen.error = e.message;
  }
  gen.markModified('attempts');
  await gen.save();
}
