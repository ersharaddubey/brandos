import sharp from 'sharp';
import config from '../config.js';

const esc = (s) =>
  String(s).replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c]));

function wrap(text, n = 46, maxLines = 12) {
  const words = text.replace(/\s+/g, ' ').split(' ');
  const lines = [];
  let cur = '';
  for (const w of words) {
    if ((cur + ' ' + w).length > n) {
      lines.push(cur);
      cur = w;
    } else cur = cur ? cur + ' ' + w : w;
  }
  if (cur) lines.push(cur);
  return lines.slice(0, maxLines);
}

/** Parse aspect ratio string → { width, height }, sides multiple of 16. */
export function resolveSize({ width, height, aspectRatio } = {}) {
  const baseW = Number(width) || config.generator.width || 1024;
  const baseH = Number(height) || config.generator.height || 1024;
  if (!aspectRatio || !String(aspectRatio).trim()) {
    return { width: snap16(baseW), height: snap16(baseH) };
  }
  const m = String(aspectRatio)
    .trim()
    .match(/^(\d+(?:\.\d+)?)\s*[:/xX]\s*(\d+(?:\.\d+)?)$/);
  if (!m) return { width: snap16(baseW), height: snap16(baseH) };
  const aw = parseFloat(m[1]);
  const ah = parseFloat(m[2]);
  if (!(aw > 0 && ah > 0)) return { width: snap16(baseW), height: snap16(baseH) };
  const area = baseW * baseH;
  const scale = Math.sqrt(area / (aw * ah));
  return { width: snap16(aw * scale), height: snap16(ah * scale) };
}

function snap16(n) {
  return Math.max(256, Math.round(n / 16) * 16);
}

async function mock({ prompt, seed, width, height }) {
  const hue = seed % 360;
  const lines = wrap(prompt)
    .map((l, i) => `<text x="40" y="${120 + i * 34}" font-size="22" fill="#fff" font-family="monospace">${esc(l)}</text>`)
    .join('');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
    <rect width="100%" height="100%" fill="hsl(${hue},45%,28%)"/>
    <text x="40" y="70" font-size="34" fill="#ffd166" font-family="sans-serif" font-weight="bold">MOCK GENERATION  seed ${seed}</text>
    ${lines}</svg>`;
  return sharp(Buffer.from(svg)).png().toBuffer();
}

function isCloudflareUrl(url) {
  return /api\.cloudflare\.com/i.test(url || '') || /workers-ai|\/ai\/run\//i.test(url || '');
}

/**
 * Cloudflare Workers AI — Flux Schnell
 * POST body: { prompt, steps?, seed? }
 * Response: { success, result: { image: "<base64>" } } or { image: "<base64>" }
 */
async function cloudflare({ prompt, seed }) {
  const url = config.generator.url;
  const token = config.generator.cloudflareToken || process.env.CLOUDFLARE_API_TOKEN;
  if (!token) {
    throw new Error('CLOUDFLARE_API_TOKEN is missing — set it in server/.env');
  }

  const steps = Math.min(8, Math.max(1, Number(config.generator.steps) || 4));
  const body = {
    prompt: String(prompt || '').slice(0, 2048),
    steps,
  };
  if (seed != null) body.seed = Number(seed) || 0;

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(5 * 60 * 1000),
  });

  const text = await res.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    data = null;
  }

  if (!res.ok) {
    const errMsg =
      data?.errors?.[0]?.message ||
      data?.error ||
      text.slice(0, 400) ||
      res.statusText;
    throw new Error(`Cloudflare Workers AI ${res.status}: ${errMsg}`);
  }

  // Cloudflare wraps in { result: { image } } ; some paths return { image }
  const b64 =
    data?.result?.image ||
    data?.image ||
    data?.result?.images?.[0] ||
    data?.image_base64;

  if (!b64 || typeof b64 !== 'string') {
    throw new Error(
      'Cloudflare response had no image field. Body: ' + text.slice(0, 200)
    );
  }

  // Strip data-URI prefix if present
  const pure = b64.replace(/^data:image\/\w+;base64,/, '');
  return Buffer.from(pure, 'base64');
}

/** Generic local flux-server / other HTTP generators */
async function httpGeneric({ prompt, seed, width, height, referencesBase64 = [] }) {
  const headers = { 'Content-Type': 'application/json' };
  const token = config.generator.cloudflareToken || process.env.CLOUDFLARE_API_TOKEN;
  if (token && isCloudflareUrl(config.generator.url)) {
    headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(config.generator.url, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      prompt,
      seed,
      width,
      height,
      steps: config.generator.steps || 4,
      reference_image: referencesBase64[0] || null,
      reference_images: referencesBase64.length ? referencesBase64 : [],
    }),
    signal: AbortSignal.timeout(15 * 60 * 1000),
  });
  if (!res.ok) {
    const body = (await res.text()).slice(0, 300);
    throw new Error(`Generator ${res.status}: ${body}`);
  }
  const type = res.headers.get('content-type') || '';
  if (type.startsWith('image/')) return Buffer.from(await res.arrayBuffer());
  const data = await res.json();
  if (data.result?.image) return Buffer.from(String(data.result.image).replace(/^data:image\/\w+;base64,/, ''), 'base64');
  if (data.image_base64) return Buffer.from(data.image_base64, 'base64');
  if (data.image && typeof data.image === 'string') {
    return Buffer.from(String(data.image).replace(/^data:image\/\w+;base64,/, ''), 'base64');
  }
  if (data.image_url) return Buffer.from(await (await fetch(data.image_url)).arrayBuffer());
  throw new Error('Generator response had no image');
}

async function http(args) {
  if (isCloudflareUrl(config.generator.url)) {
    return cloudflare(args);
  }
  return httpGeneric(args);
}

/**
 * Generate an image from prompt.
 */
export async function generateImage({
  prompt,
  referencesBase64 = [],
  referenceBase64,
  width,
  height,
  aspectRatio,
} = {}) {
  const seed = Math.floor(Math.random() * 2 ** 31);
  const refs = referencesBase64.length ? referencesBase64 : referenceBase64 ? [referenceBase64] : [];
  const size = resolveSize({ width, height, aspectRatio });
  const args = {
    prompt,
    seed,
    width: size.width,
    height: size.height,
    referencesBase64: refs,
  };
  const buffer =
    config.generator.provider === 'http' ? await http(args) : await mock(args);
  return { buffer, seed, width: size.width, height: size.height };
}
