import { Router } from 'express';
import Asset from '../models/Asset.js';
import { wrap, upload } from '../middleware/common.js';
import { ingestImage, removeAssetFile } from '../services/assets.js';
import { hamming } from '../services/hash.js';
import config from '../config.js';

const r = Router();
const CATS = ['product', 'character', 'environment', 'brand'];

r.get('/', wrap(async (req, res) => {
  const { kind, identity, campaign, q, visibility, category } = req.query;
  const filter = {};
  if (kind) filter.kind = kind;
  if (identity) filter.identityIds = identity;
  if (campaign) filter.campaignId = campaign;
  if (visibility === 'public' || visibility === 'private') filter.visibility = visibility;
  if (category && CATS.includes(category)) filter.category = category;
  if (q) filter.$or = [{ prompt: new RegExp(q, 'i') }, { tags: new RegExp(q, 'i') }, { filename: new RegExp(q, 'i') }];
  res.json(await Asset.find(filter).sort('-createdAt').limit(300));
}));

/** Similar groups: within each of the 4 categories (or all if no category filter) */
r.get('/duplicates', wrap(async (req, res) => {
  const threshold = Number(req.query.threshold ?? config.similarThreshold);
  const vis = req.query.visibility;
  const category = req.query.category;
  const filter = { dhash: { $exists: true } };
  if (vis === 'public' || vis === 'private') filter.visibility = vis;
  if (category && CATS.includes(category)) filter.category = category;

  const all = await Asset.find(filter);
  // Group by category first, then cluster by dhash within each category
  const byCat = {};
  for (const a of all) {
    const key = a.category || 'uncategorized';
    (byCat[key] ||= []).push(a);
  }

  const result = [];
  for (const [cat, list] of Object.entries(byCat)) {
    if (list.length < 2) continue;
    const parent = list.map((_, i) => i);
    const find = (i) => (parent[i] === i ? i : (parent[i] = find(parent[i])));
    for (let i = 0; i < list.length; i++)
      for (let j = i + 1; j < list.length; j++)
        if (hamming(list[i].dhash, list[j].dhash) <= threshold) parent[find(i)] = find(j);
    const groups = {};
    list.forEach((a, i) => (groups[find(i)] ||= []).push(a));
    for (const g of Object.values(groups)) {
      if (g.length > 1) result.push({ category: cat, assets: g });
    }
  }
  res.json(result);
}));

r.post('/', upload.single('image'), wrap(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Image required' });
  const tags = (req.body.tags || '').split(',').map((t) => t.trim()).filter(Boolean);
  const visibility = req.body.visibility === 'public' ? 'public' : 'private';
  const category = CATS.includes(req.body.category) ? req.body.category : '';
  const out = await ingestImage({ buffer: req.file.buffer, kind: 'upload', tags, visibility, category });
  res.status(out.duplicate ? 200 : 201).json(out);
}));

r.patch('/:id/visibility', wrap(async (req, res) => {
  const vis = req.body.visibility === 'public' ? 'public' : 'private';
  const a = await Asset.findByIdAndUpdate(req.params.id, { visibility: vis }, { new: true });
  if (!a) return res.status(404).json({ error: 'Asset not found' });
  res.json(a);
}));

r.patch('/:id/category', wrap(async (req, res) => {
  const cat = CATS.includes(req.body.category) ? req.body.category : '';
  const a = await Asset.findByIdAndUpdate(req.params.id, { category: cat }, { new: true });
  if (!a) return res.status(404).json({ error: 'Asset not found' });
  res.json(a);
}));

r.delete('/:id', wrap(async (req, res) => {
  const a = await Asset.findByIdAndDelete(req.params.id);
  if (a) await removeAssetFile(a);
  res.json({ ok: true });
}));

export default r;
