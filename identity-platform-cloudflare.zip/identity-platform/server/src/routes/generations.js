import { Router } from 'express';
import Generation from '../models/Generation.js';
import Campaign from '../models/Campaign.js';
import { wrap } from '../middleware/common.js';
import { runGeneration } from '../services/generationRunner.js';

const r = Router();
const populate = (q) => q.populate('attempts.assetId').populate('campaignId', 'name');

r.get('/', wrap(async (req, res) => res.json(await populate(Generation.find().sort('-createdAt').limit(30)))));

r.get('/:id', wrap(async (req, res) => {
  const doc = await populate(Generation.findById(req.params.id));
  if (!doc) return res.status(404).json({ error: 'Generation not found' });
  res.json(doc);
}));

r.post('/', wrap(async (req, res) => {
  const { identityIds, campaignName, goal, scene, composition, style, templateId, maxAttempts = 3, threshold = 75 } = req.body;
  if (!Array.isArray(identityIds) || !identityIds.length) return res.status(400).json({ error: 'Select at least one locked identity' });
  let campaignId;
  if (campaignName?.trim()) {
    const c = await Campaign.findOneAndUpdate(
      { name: campaignName.trim() },
      { $set: { goal, identityIds } },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    campaignId = c._id;
  }
  const gen = await Generation.create({
    identityIds, campaignId,
    inputs: { goal, scene, composition, style, templateId: templateId || undefined },
    settings: { maxAttempts: Math.min(Number(maxAttempts) || 3, 6), threshold: Number(threshold) || 75 },
  });
  runGeneration(gen._id).catch(console.error); // runs in background; client polls
  res.status(202).json(gen);
}));

export default r;
