# Ollama + Single Flux setup

This project no longer uses Cloudflare Workers AI.

## Requirements
```bash
ollama serve
ollama pull llava          # vision (image → prompt)
ollama pull llama3.2       # text (enhance / tweak)
```

## server/.env — single Flux URL for ALL image generation
```
VISION_PROVIDER=ollama
OLLAMA_API_BASE=http://localhost:11434
OLLAMA_VISION_MODEL=llava
OLLAMA_TEXT_MODEL=llama3.2

# ONE endpoint for every generate / recreate image path
FLUX_API_URL=https://proofs-eggnog-syndrome.ngrok-free.dev
```

Server always calls: `{FLUX_API_URL}/generate?prompt=...`  
(from `server/src/services/imageGeneration.js` only)

## Run
```bash
cd server && rm -rf node_modules package-lock.json && npm install && npm start
cd client && npm install && npm run dev
```

UI: select **Local Ollama** → upload image → Generate Prompt.  
Image gen (any page) → uses `FLUX_API_URL` only.  
Enhance / Tweak use `OLLAMA_TEXT_MODEL` only.
