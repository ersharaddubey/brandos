# Prompt Gallery — Four Stages User Guide

## Stage 1 — Identity Lock

1. Sign up / log in.
2. Open Generate.
3. Upload a reference photo.
4. Let Ollama Vision analyze the photo and build identity anchors.
5. Review/edit the structured prompt.
6. Generate with the configured Flux endpoint.
7. Review the quality score and refinement history.
8. Save the prompt and generated image to the gallery.

Core idea: one reference image becomes a reusable identity-aware prompt.

## Stage 2 — Structured Prompt OS

Open **Structured OS** from the Four Stages page.

Use it to:
- browse saved prompts;
- inspect version history;
- copy/download Raw, Prompt JSON, Flux, Midjourney, or SDXL exports;
- manage team seat limits;
- record agency member invitations.

## Stage 3 — Private / On-prem

Open **Private / On-prem**.

Use the controls to configure:
- private mode;
- cloud upload permission;
- data residency label;
- audit logging.

The runtime panel shows Ollama and Flux configuration detected by the backend.

For true on-prem privacy, use local/private endpoints and disable cloud uploads. Do not treat an ngrok tunnel as private infrastructure.

## Stage 4 — Dedup + Asset Bank

Open **Asset Bank**.

Every generated image is indexed automatically as an asset.

Use:
- search;
- reusable prompt copy;
- Run Dedup.

The current dedup engine marks exact URL/content-hash duplicates and high token-overlap semantic-lite duplicates. It is intentionally simple and dependency-free; a future production version can swap in a vision embedding/perceptual-hash service without changing the UI contract.
