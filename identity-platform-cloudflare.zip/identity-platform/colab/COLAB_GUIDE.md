# Colab → Prompt Gallery Flux API

Prompt Gallery uses one Flux endpoint only:

`FLUX_API_URL=https://proofs-eggnog-syndrome.ngrok-free.dev`

The Node backend automatically calls:

`{FLUX_API_URL}/generate?prompt=...`

## 1. Load Flux in Colab

Your existing notebook must finish loading the Flux pipeline into a Python variable named `pipe`.

## 2. Start the adapter

Copy `flux_api_server.py` into a Colab cell and run it after `pipe` is loaded.

Install dependencies if the notebook does not already have them:

```python
!pip -q install fastapi uvicorn pyngrok pillow
```

Then create an ngrok tunnel:

```python
from pyngrok import ngrok
public_url = ngrok.connect(8000)
print("🚀 PUBLIC URL →", public_url)
print("FLUX_API_URL=", public_url)
```

Start the server:

```python
import uvicorn
uvicorn.run(app, host="0.0.0.0", port=8000)
```

## 3. Test the two routes

Root:

```text
https://YOUR-NGROK-URL.ngrok-free.dev/
```

Expected JSON contains `"status": "online"`.

Generate:

```text
https://YOUR-NGROK-URL.ngrok-free.dev/generate?prompt=a%20cinematic%20portrait
```

Expected response: PNG image, not 404.

## 4. Point Prompt Gallery to the same URL

In `server/.env`:

```env
FLUX_API_URL=https://YOUR-NGROK-URL.ngrok-free.dev
```

Do not append `/generate` to the environment variable.

## Important

An ngrok URL is public tunneling. It is fine for development, but it is not equivalent to a true on-prem/private deployment. Stage 3 is intended to use a private/local Flux endpoint, local Ollama, and private storage.
