import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import LockMeter from '../components/LockMeter.jsx';
import { TourProvider, GuideBar, Tip, EmptyHint } from '../components/Help.jsx';
import CreateGroup from '../components/CreateGroup.jsx';
import PageHeader from '../components/PageHeader.jsx';

const TYPES = ['product', 'character', 'environment', 'brand'];

const DUMMY_FORM = {
  name: 'Matte Teal Bottle',
  type: 'product',
  description: 'Matte teal stainless steel bottle, logo etched on left side, brushed metal cap',
};

const TOUR_STEPS = [
  {
    selector: '[data-tour="id-create"]',
    title: '1. New identity',
    body: 'Name + one of four types + reference image. Choose Asset Bank (private) or Open Shelf (shared). Create & analyse extracts a vision profile.',
    why: '“Reference → structured profile → Lock = identity asset.”',
  },
  {
    selector: '[data-tour="id-list"]',
    title: '2. Identity list',
    body: 'Open a card to review fields and Lock. Only locked identities appear in Studio.',
    why: '“Draft vs locked — avoid accidental changes.”',
  },
];

function IdentitiesInner() {
  const [list, setList] = useState([]);
  const [filter, setFilter] = useState('');
  const [form, setForm] = useState({ name: '', type: 'product', description: '' });
  const [visibility, setVisibility] = useState('private');
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const load = () =>
    api.identities.list(filter ? `?type=${filter}` : '').then(setList).catch((e) => setErr(e.message));
  useEffect(() => {
    load();
  }, [filter]);
  useEffect(() => {
    if (!list.some((i) => i.status === 'analyzing')) return;
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, [list]);

  const fillDummy = () => {
    setForm({ ...DUMMY_FORM });
    setErr('');
  };

  const submit = async (e) => {
    e.preventDefault();
    setErr('');
    if (!file) return setErr('Select a reference image (dummy form fills text only).');
    setBusy(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      fd.append('image', file);
      fd.append('visibility', visibility);
      await api.identities.create(fd);
      setForm({ name: '', type: form.type, description: '' });
      setFile(null);
      e.target.reset();
      load();
    } catch (e2) {
      setErr(e2.message);
    }
    setBusy(false);
  };

  return (
    <>
      <PageHeader title="Identity Lock" subtitle="Create product · character · brand · environment identities. Lock for consistency." showDelete={true} />
      <p className="sub">
        Upload a reference for product, character, environment, or brand → review profile → Lock.
        Reference assets go to Asset Bank (private) or Open Shelf (shared).
      </p>
      <GuideBar onDummy={fillDummy} dummyLabel="Fill dummy form" />
      {err && <div className="err">{err}</div>}

      <form className="card" onSubmit={submit} data-tour="id-create">
        <h2>
          New identity <Tip id="id.create" />
        </h2>
        <div className="two">
          <div>
            <label>Name</label>
            <input
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Matte Teal Bottle"
            />
          </div>
          <div>
            <label>Type</label>
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
              {TYPES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </div>
        </div>
        <label>Notes (optional)</label>
        <input
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="e.g. matte teal steel bottle, logo on left"
        />
        <label>Reference image</label>
        <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files[0])} />

        <label>Save reference to</label>
        <div className="vis-toggle">
          <button
            type="button"
            className={visibility === 'private' ? 'active' : ''}
            onClick={() => setVisibility('private')}
          >
            Asset Bank (private)
          </button>
          <button
            type="button"
            className={visibility === 'public' ? 'active' : ''}
            onClick={() => setVisibility('public')}
          >
            Open Shelf (shared)
          </button>
        </div>
        <p className="muted small" style={{ marginTop: 6 }}>
          {visibility === 'private'
            ? 'Only in your Asset Bank — for private campaigns.'
            : 'Shared on Open Shelf — for team reuse and templates.'}
        </p>

        <div className="row" style={{ marginTop: 14 }}>
          <button disabled={busy}>{busy ? 'Uploading…' : 'Create & analyse'}</button>
        </div>
      </form>

      <CreateGroup visibility="private" defaultType={form.type} onCreated={() => {}} />

      <div className="row" style={{ marginBottom: 12 }}>
        <span className="muted">Filter:</span>
        <select style={{ width: 160 }} value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="">all</option>
          {TYPES.map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-4" data-tour="id-list">
        {list.map((i) => (
          <Link to={`/identities/${i._id}`} className="card" key={i._id}>
            {i.referenceAssetIds?.[0] && (
              <img className="thumb" src={i.referenceAssetIds[0].url} alt={i.name} />
            )}
            <div className="row" style={{ marginTop: 10, justifyContent: 'space-between' }}>
              <b>{i.name}</b>
              <span className={'badge ' + i.status}>{i.status}</span>
            </div>
            <div className="muted small">
              {i.type} · v{i.version}
            </div>
            <LockMeter compact stats={i.lockStats} locked={i.status === 'locked'} />
          </Link>
        ))}
        {!list.length && (
          <EmptyHint
            title="No identities yet"
            body="Fill name + type, select a reference image, choose Asset Bank or Open Shelf, then Create & analyse."
            why="“Identity lock = the same face or product across every campaign.”"
          />
        )}
      </div>
    </>
  );
}

export default function Identities() {
  return (
    <TourProvider steps={TOUR_STEPS}>
      <IdentitiesInner />
    </TourProvider>
  );
}
