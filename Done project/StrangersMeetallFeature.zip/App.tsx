import React, { useState } from 'react';
import { View, StyleSheet, TouchableOpacity, Text } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { ThemeProvider, useTheme } from './src/theme/ThemeContext';
import Header from './src/components/Header';
import Footer from './src/components/Footer';
import Sidebar from './src/components/Sidebar';
import HomeScreen from './src/screens/HomeScreen';
import ExperiencesScreen from './src/screens/ExperiencesScreen';
import CitiesScreen from './src/screens/CitiesScreen';
import FreeMeetupScreen from './src/screens/FreeMeetupScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import ExperienceDetailScreen from './src/screens/ExperienceDetailScreen';
import CityDetailScreen from './src/screens/CityDetailScreen';
import CompanionsScreen from './src/screens/CompanionsScreen';
import CompanionDetailScreen from './src/screens/CompanionDetailScreen';
import BookingScreen from './src/screens/BookingScreen';
import EditProfileScreen from './src/screens/EditProfileScreen';
import MyBookingsScreen from './src/screens/MyBookingsScreen';
import FavoritesScreen from './src/screens/FavoritesScreen';
import NotificationsScreen from './src/screens/NotificationsScreen';
import PrivacyScreen from './src/screens/PrivacyScreen';
import HelpScreen from './src/screens/HelpScreen';
import TermsScreen from './src/screens/TermsScreen';
import AboutScreen from './src/screens/AboutScreen';
import FeatureDetailScreen from './src/screens/FeatureDetailScreen';
import CityEventsScreen from './src/screens/CityEventsScreen';
import { Experience, Companion } from './src/data/experiences';
import { getFeatureByKey, FeatureDetail } from './src/data/featureDetails';

type Screen =
  | 'Home'
  | 'Experiences'
  | 'Cities'
  | 'FreeMeetup'
  | 'Profile'
  | 'Companions'
  | 'ExperienceDetail'
  | 'CityDetail'
  | 'CompanionDetail'
  | 'Booking'
  | 'EditProfile'
  | 'MyBookings'
  | 'Favorites'
  | 'Notifications'
  | 'Privacy'
  | 'Help'
  | 'Terms'
  | 'About'
  | 'FeatureDetail'
  | 'CityEvents';

const PROFILE_SCREENS: Screen[] = [
  'EditProfile',
  'MyBookings',
  'Favorites',
  'Notifications',
  'Privacy',
  'Help',
  'Terms',
  'About',
];

const FEATURE_SCREENS: Screen[] = [
  'FreeMeetup',
  'FeatureDetail',
  'CityEvents',
  ...PROFILE_SCREENS,
];

function AppInner() {
  const insets = useSafeAreaInsets();
  const { colors, isDark, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = useState<string>('Home');
  const [screen, setScreen] = useState<Screen>('Home');
  const [selectedExperience, setSelectedExperience] = useState<Experience | null>(null);
  const [selectedCity, setSelectedCity] = useState<{ name: string; tagline: string } | null>(null);
  const [selectedCompanion, setSelectedCompanion] = useState<Companion | null>(null);
  const [selectedFeature, setSelectedFeature] = useState<FeatureDetail | null>(null);
  const [bookingCtx, setBookingCtx] = useState<{
    lookingFor?: string;
    activity?: string;
    featureLabel?: string;
    featureIcon?: string;
  }>({});
  const [history, setHistory] = useState<Screen[]>(['Home']);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const tabScreens = ['Home', 'Companions', 'Experiences', 'Cities', 'Profile'];

  const navigate = (next: string, params?: any) => {
    if (next === 'ExperienceDetail' && params?.experience) {
      setSelectedExperience(params.experience);
      setHistory((h) => [...h, 'ExperienceDetail']);
      setScreen('ExperienceDetail');
      return;
    }
    if (next === 'CityDetail' && params?.city) {
      setSelectedCity(params.city);
      setHistory((h) => [...h, 'CityDetail']);
      setScreen('CityDetail');
      return;
    }
    if (next === 'CompanionDetail' && params?.companion) {
      setSelectedCompanion(params.companion);
      setHistory((h) => [...h, 'CompanionDetail']);
      setScreen('CompanionDetail');
      return;
    }
    if (next === 'FeatureDetail' && params?.featureKey) {
      const f = getFeatureByKey(params.featureKey);
      if (f) {
        setSelectedFeature(f);
        setHistory((h) => [...h, 'FeatureDetail']);
        setScreen('FeatureDetail');
      }
      return;
    }
    if (next === 'CityEvents') {
      setHistory((h) => [...h, 'CityEvents']);
      setScreen('CityEvents');
      return;
    }
    if (next === 'Booking') {
      if (params?.companion) setSelectedCompanion(params.companion);
      setBookingCtx({
        lookingFor: params?.lookingFor,
        activity: params?.activity,
        featureLabel: params?.featureLabel,
        featureIcon: params?.featureIcon,
      });
      setHistory((h) => [...h, 'Booking']);
      setScreen('Booking');
      return;
    }
    if (FEATURE_SCREENS.includes(next as Screen)) {
      setHistory((h) => [...h, next as Screen]);
      setScreen(next as Screen);
      return;
    }
    if (tabScreens.includes(next)) {
      setActiveTab(next);
      setHistory([next as Screen]);
      setScreen(next as Screen);
    }
  };

  const goBack = () => {
    if (history.length > 1) {
      const newHistory = [...history];
      newHistory.pop();
      const prev = newHistory[newHistory.length - 1];
      setHistory(newHistory);
      setScreen(prev);
      if (tabScreens.includes(prev)) setActiveTab(prev);
    }
  };

  const isDetail =
    screen === 'ExperienceDetail' ||
    screen === 'CityDetail' ||
    screen === 'CompanionDetail' ||
    screen === 'Booking' ||
    FEATURE_SCREENS.includes(screen);

  const getTitle = () => {
    switch (screen) {
      case 'Experiences':
        return 'Experiences';
      case 'Cities':
        return 'Cities';
      case 'FreeMeetup':
        return 'Free Meetup';
      case 'Profile':
        return 'Profile';
      case 'Companions':
        return 'Companions';
      case 'ExperienceDetail':
        return selectedExperience?.title || 'Experience';
      case 'CityDetail':
        return selectedCity?.name || 'City';
      case 'CompanionDetail':
        return selectedCompanion?.name || 'Companion';
      case 'Booking':
        return bookingCtx.featureLabel || 'Book';
      case 'EditProfile':
        return 'Edit Profile';
      case 'MyBookings':
        return 'My Bookings';
      case 'Favorites':
        return 'Favorites';
      case 'Notifications':
        return 'Notifications';
      case 'Privacy':
        return 'Privacy & Safety';
      case 'Help':
        return 'Help & Support';
      case 'Terms':
        return 'Terms & Conditions';
      case 'About':
        return 'About';
      case 'FeatureDetail':
        return selectedFeature?.label || 'Feature';
      case 'CityEvents':
        return 'City Events';
      default:
        return undefined;
    }
  };

  const renderScreen = () => {
    switch (screen) {
      case 'Home':
        return <HomeScreen onNavigate={navigate} />;
      case 'Experiences':
        return <ExperiencesScreen onNavigate={navigate} />;
      case 'Cities':
        return <CitiesScreen onNavigate={navigate} />;
      case 'FreeMeetup':
        return <FreeMeetupScreen onNavigate={navigate} />;
      case 'Profile':
        return <ProfileScreen onNavigate={navigate} />;
      case 'Companions':
        return <CompanionsScreen onNavigate={navigate} />;
      case 'ExperienceDetail':
        return selectedExperience ? (
          <ExperienceDetailScreen
            experience={selectedExperience}
            onBack={goBack}
            onNavigate={navigate}
          />
        ) : null;
      case 'CityDetail':
        return selectedCity ? (
          <CityDetailScreen city={selectedCity} onBack={goBack} onNavigate={navigate} />
        ) : null;
      case 'CompanionDetail':
        return selectedCompanion ? (
          <CompanionDetailScreen
            companion={selectedCompanion}
            onBack={goBack}
            onNavigate={navigate}
          />
        ) : null;
      case 'Booking':
        return (
          <BookingScreen
            onBack={goBack}
            companion={selectedCompanion}
            lookingForPref={bookingCtx.lookingFor}
            activityPref={bookingCtx.activity}
            featureLabel={bookingCtx.featureLabel}
            featureIcon={bookingCtx.featureIcon}
          />
        );
      case 'FeatureDetail':
        return selectedFeature ? (
          <FeatureDetailScreen
            feature={selectedFeature}
            onBack={goBack}
            onNavigate={navigate}
          />
        ) : null;
      case 'CityEvents':
        return <CityEventsScreen onBack={goBack} onNavigate={navigate} />;
      case 'EditProfile':
        return <EditProfileScreen onBack={goBack} />;
      case 'MyBookings':
        return <MyBookingsScreen onBack={goBack} />;
      case 'Favorites':
        return <FavoritesScreen onBack={goBack} />;
      case 'Notifications':
        return <NotificationsScreen onBack={goBack} />;
      case 'Privacy':
        return <PrivacyScreen onBack={goBack} />;
      case 'Help':
        return <HelpScreen onBack={goBack} />;
      case 'Terms':
        return <TermsScreen onBack={goBack} />;
      case 'About':
        return <AboutScreen onBack={goBack} />;
      default:
        return <HomeScreen onNavigate={navigate} />;
    }
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top, backgroundColor: colors.background }]}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Header
        title={isDetail ? getTitle() : undefined}
        showBack={isDetail}
        onBack={goBack}
        onMenuPress={() => setSidebarOpen(true)}
        rightAction={
          <TouchableOpacity
            onPress={toggleTheme}
            style={[styles.themeBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
            hitSlop={8}
          >
            <Text style={{ fontSize: 16 }}>{isDark ? '☀️' : '🌙'}</Text>
          </TouchableOpacity>
        }
      />
      <View style={styles.body}>{renderScreen()}</View>
      {!isDetail && (
        <Footer
          activeTab={activeTab}
          onTabPress={(tab) => navigate(tab)}
          bottomInset={insets.bottom}
        />
      )}
      <Sidebar
        visible={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        activeTab={activeTab}
        onNavigate={navigate}
        currentScreen={screen}
        topInset={insets.top}
      />
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <AppInner />
      </ThemeProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  body: {
    flex: 1,
  },
  themeBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
});
