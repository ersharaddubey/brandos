const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

const extraBlock = /[\\/]backend[\\/].*/;
if (Array.isArray(config.resolver.blockList)) {
  config.resolver.blockList.push(extraBlock);
} else if (config.resolver.blockList) {
  config.resolver.blockList = [config.resolver.blockList, extraBlock];
} else {
  config.resolver.blockList = [extraBlock];
}

module.exports = config;
