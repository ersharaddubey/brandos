# StrangersMeet

## Data storage (important)

**No real database and no required `.env` for basic local use.**

| What | Where |
|------|--------|
| All records (slides, companions, experiences, cities, packages, bookings, users) | `backend/data.json` |
| Backend port / optional Cloudinary keys | environment variables (see `backend/.env.example`) |
| App → API base URL | `EXPO_PUBLIC_API_URL` (see root `.env.example`) |

Admin panel **Create / Update / Delete** writes directly to `backend/data.json`.  
The **mobile app** now loads companions, experiences, cities, packages and slides from the same API. If the API is offline, the app falls back to the static data in `src/data/`.

This JSON-file storage is for **local development only**. For production use MongoDB (or similar) and proper auth.

---

## Start the backend and admin panel

```bash
cd backend
npm install
npm start
```

Open **http://localhost:4000/admin**

Default credentials:

- Email: `admin@strangersmeet.app`
- Password: `admin123`

### Backend `.env` (`backend/.env`)

```bash
cd backend
cp .env.example .env
# edit .env — then:
npm install
npm start
```

```env
PORT=4000
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
CLOUDINARY_UPLOAD_PRESET=
```

`dotenv` loads this file automatically. On hosting panels, set the same variables in the dashboard.

### App (Expo) `.env` (project root)

```bash
cp .env.example .env
```

```env
EXPO_PUBLIC_API_URL=http://localhost:4000
EXPO_PUBLIC_CLOUDINARY_CLOUD_NAME=
EXPO_PUBLIC_CLOUDINARY_UPLOAD_PRESET=
```

On a physical phone use your PC LAN IP, e.g. `http://192.168.1.20:4000`.

---

## Start the Expo app

From project root (not `backend`):

```bash
npm install --legacy-peer-deps
npx expo start --clear
```

**Physical phone:** use your computer’s LAN IP:

```bash
EXPO_PUBLIC_API_URL=http://192.168.1.20:4000 npx expo start --clear
```

Do **not** use `localhost` on a real phone (it points to the phone itself).

Copy root `.env.example` → `.env` if you prefer a file for Expo.

---

## Images (Cloudinary)

1. Create a free account at [cloudinary.com](https://cloudinary.com).
2. Upload images in the Cloudinary Media Library (or use an unsigned upload preset).
3. Copy the **secure URL** (e.g. `https://res.cloudinary.com/.../image.jpg`).
4. In Admin → Companion / Experience / City / Profile form, paste the URL into **Image URL (Cloudinary)** / **Photo URL**.
5. The app can show that URL with React Native `<Image source={{ uri: item.imageUrl }} />` (wire UI as needed).

Admin forms already have `imageUrl` fields. No file is stored on this server — only the URL string in `data.json`.

---

## Public API (app uses these)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/slides` | Active hero slides |
| GET | `/api/companions` | Active companions |
| GET | `/api/experiences` | Active experiences |
| GET | `/api/cities` | Active cities |
| GET | `/api/packages` | Active packages |
| POST | `/api/bookings` | Create booking |

Admin CRUD lives under `/api/admin/*` and requires `Authorization: Bearer demo-admin-token`.

---

## Troubleshooting: admin works but app shows no updates

1. Backend must be running on the same URL the app calls.
2. On a phone, set `EXPO_PUBLIC_API_URL` to the PC’s LAN IP + port.
3. After changing data in admin, reopen the screen (API is fetched on mount).
4. Check `backend/data.json` — if the file updates after admin save, storage is fine; the app was previously using static `src/data/*` only (now fixed to fetch API first).
