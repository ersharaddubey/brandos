/* Admin page: packages */
function renderPackages(list) {
      document.getElementById('packagesTable').innerHTML = list.length ? list.map(p => `<tr>
        <td><b>${esc(p.title)}</b>${p.popular ? ' ⭐' : ''}</td>
        <td>${esc(p.category || '')}</td>
        <td>₹${p.price || 0} <small style="color:var(--muted)">${esc(p.unit || '')}</small></td>
        <td>${p.popular ? 'Yes' : '—'}</td>
        <td><span class="badge ${p.active !== false ? 'badge-live' : 'badge-off'}">${p.active !== false ? 'Active' : 'Off'}</span></td>
        <td>
          <button class="btn-ghost btn-sm" onclick='openModal("package",${JSON.stringify(p).replace(/'/g,"&#39;")})'>Edit</button>
          <button class="btn-danger btn-sm" onclick="deleteItem('packages','${p.id}')">Delete</button>
        </td>
      </tr>`).join('') : '<tr><td colspan="6"><div class="empty">No packages</div></td></tr>';
    }

