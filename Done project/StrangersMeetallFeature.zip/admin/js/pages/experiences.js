/* Admin page: experiences */
function renderExperiences(list) {
      document.getElementById('experiencesTable').innerHTML = list.length ? list.map(e => `<tr>
        <td style="font-size:1.4rem">${e.icon || '✨'}</td>
        <td><b>${esc(e.title)}</b></td>
        <td>${esc(e.subtitle || '')}</td>
        <td><span class="badge ${e.active !== false ? 'badge-live' : 'badge-off'}">${e.active !== false ? 'Active' : 'Off'}</span></td>
        <td>
          <button class="btn-ghost btn-sm" onclick='openModal("experience",${JSON.stringify(e).replace(/'/g,"&#39;")})'>Edit</button>
          <button class="btn-danger btn-sm" onclick="deleteItem('experiences','${e.id}')">Delete</button>
        </td>
      </tr>`).join('') : '<tr><td colspan="5"><div class="empty">No experiences</div></td></tr>';
    }

