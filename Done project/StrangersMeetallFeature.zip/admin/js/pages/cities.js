/* Admin page: cities */
function renderCities(list) {
      document.getElementById('citiesTable').innerHTML = list.length ? list.map(c => `<tr>
        <td><b>${esc(c.name)}</b></td>
        <td>${esc(c.tagline || '')}</td>
        <td><span class="badge ${c.active !== false ? 'badge-live' : 'badge-off'}">${c.active !== false ? 'Active' : 'Off'}</span></td>
        <td>
          <button class="btn-ghost btn-sm" onclick='openModal("city",${JSON.stringify(c).replace(/'/g,"&#39;")})'>Edit</button>
          <button class="btn-danger btn-sm" onclick="deleteItem('cities','${c.id}')">Delete</button>
        </td>
      </tr>`).join('') : '<tr><td colspan="4"><div class="empty">No cities</div></td></tr>';
    }

