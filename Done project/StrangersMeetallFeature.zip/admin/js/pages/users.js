/* Admin page: users */
function renderUsers(list) {
      document.getElementById('usersTable').innerHTML = list.length ? list.map(u => `<tr>
        <td><b>${esc(u.name)}</b></td>
        <td>${esc(u.email)}</td>
        <td><span class="badge badge-${u.role === 'admin' ? 'admin' : 'user'}">${u.role}</span></td>
        <td>
          <button class="btn-ghost btn-sm" onclick='openModal("user",${JSON.stringify(u).replace(/'/g,"&#39;")})'>Edit</button>
          ${u.id !== 'admin1' ? `<button class="btn-danger btn-sm" onclick="deleteItem('users','${u.id}')">Delete</button>` : ''}
        </td>
      </tr>`).join('') : '<tr><td colspan="4"><div class="empty">No users</div></td></tr>';
    }

