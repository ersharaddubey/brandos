/* Admin page: slides */
function renderSlides(list) {
      document.getElementById('slidesTable').innerHTML = list.length ? list
        .sort((a, b) => (a.order || 0) - (b.order || 0))
        .map(s => `<tr>
          <td>${s.order || '—'}</td>
          <td><span style="font-size:1.2rem">${s.emoji || ''}</span> <b>${esc(s.title)}</b><br><small style="color:var(--muted)">${esc(s.subtitle || '')}</small></td>
          <td>${esc(s.cta || '')}</td>
          <td><span class="badge ${s.active ? 'badge-live' : 'badge-off'}">${s.active ? 'Live' : 'Off'}</span></td>
          <td>
            <button class="btn-ghost btn-sm" onclick='openModal("slide",${JSON.stringify(s).replace(/'/g,"&#39;")})'>Edit</button>
            <button class="btn-ghost btn-sm" onclick="toggleItem('slides','${s.id}',${!s.active})">${s.active ? 'Unpublish' : 'Publish'}</button>
            <button class="btn-danger btn-sm" onclick="deleteItem('slides','${s.id}')">Delete</button>
          </td>
        </tr>`).join('') : '<tr><td colspan="5"><div class="empty">No slides</div></td></tr>';
    }

