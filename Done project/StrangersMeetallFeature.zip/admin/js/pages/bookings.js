/* Admin page: bookings */
function renderBookings(list) {
      document.getElementById('bookingsTable').innerHTML = list.length ? list.map(b => `<tr>
        <td>${new Date(b.createdAt).toLocaleString()}</td>
        <td>${esc(b.lookingFor || b.activity || '—')}</td>
        <td>${esc(b.mobile || '—')}</td>
        <td><small>${esc(b.city || '')} ${esc(b.duration || '')} ${esc(b.name || '')}</small></td>
        <td><span class="badge badge-${b.status}">${b.status}</span></td>
        <td>
          <button class="btn-ghost btn-sm" onclick="setBookingStatus('${b.id}','confirmed')">Confirm</button>
          <button class="btn-ghost btn-sm" onclick="setBookingStatus('${b.id}','cancelled')">Cancel</button>
          <button class="btn-danger btn-sm" onclick="deleteItem('bookings','${b.id}')">Delete</button>
        </td>
      </tr>`).join('') : '<tr><td colspan="6"><div class="empty"><div class="emoji">📭</div>No bookings yet</div></td></tr>';
    }

