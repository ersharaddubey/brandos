/* Admin page: city events */
function renderEvents(list) {
  const el = document.getElementById('eventsTable');
  if (!el) return;
  el.innerHTML = list.length ? list.map(e => `<tr>
    <td>${esc(e.city)}</td>
    <td><b>${esc(e.title)}</b><br><small style="color:var(--muted)">${esc(e.category)} · ${esc(e.venue)}</small></td>
    <td>${esc(e.date)}</td>
    <td>${esc(e.price)}</td>
    <td><span class="badge ${e.active ? 'badge-live' : 'badge-off'}">${e.active ? 'Live' : 'Off'}</span></td>
    <td>
      <button class="btn-ghost btn-sm" onclick='openModal("event",${JSON.stringify(e).replace(/'/g,"&#39;")})'>Edit</button>
      <button class="btn-danger btn-sm" onclick="deleteItem('events','${e.id}')">Delete</button>
    </td>
  </tr>`).join('') : '<tr><td colspan="6"><div class="empty">No city events</div></td></tr>';
}
