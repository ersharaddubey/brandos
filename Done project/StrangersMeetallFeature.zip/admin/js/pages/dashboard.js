/* Admin page: dashboard */
function renderStats(s) {
      const items = [
        { label: 'Slides', value: s.slides, cls: 'lavender' },
        { label: 'Companions', value: s.companions, cls: 'mint' },
        { label: 'Experiences', value: s.experiences, cls: 'pink' },
        { label: 'Cities', value: s.cities, cls: 'peach' },
        { label: 'Packages', value: s.packages, cls: 'lavender' },
        { label: 'Bookings', value: s.bookings, cls: 'mint' },
        { label: 'Pending', value: s.pending, cls: 'peach' },
        { label: 'Profiles', value: s.profiles, cls: 'pink' },
      ];
      document.getElementById('statsGrid').innerHTML = items.map(i => `
        <div class="stat-card ${i.cls}">
          <div class="label">${i.label}</div>
          <div class="value">${i.value}</div>
        </div>`).join('');
    }

function renderDashBookings(list) {
      const el = document.getElementById('dashBookings');
      if (!list.length) {
        el.innerHTML = '<div class="empty"><div class="emoji">📭</div>No bookings yet</div>';
        return;
      }
      el.innerHTML = `<div class="table-wrap"><table>
        <thead><tr><th>Date</th><th>Looking For</th><th>Mobile</th><th>Status</th></tr></thead>
        <tbody>${list.slice(0, 8).map(b => `<tr>
          <td>${new Date(b.createdAt).toLocaleString()}</td>
          <td>${esc(b.lookingFor || b.activity || '—')}</td>
          <td>${esc(b.mobile || '—')}</td>
          <td><span class="badge badge-${b.status}">${b.status}</span></td>
        </tr>`).join('')}</tbody></table></div>`;
    }

