/* Admin page: companions */
function renderCompanions(list) {
      document.getElementById('companionsTable').innerHTML = list.length ? list.map(c => `<tr>
        <td style="font-size:1.4rem">${c.icon || '👤'}</td>
        <td><b>${esc(c.name)}</b>${c.online ? ' <span style="color:var(--success);font-size:0.7rem">● online</span>' : ''}<br><small style="color:var(--muted)">${(c.tags || []).join(', ')}</small></td>
        <td>${esc(c.role)}</td>
        <td>₹${c.rate || 0}</td>
        <td>${esc(c.city || '—')}</td>
        <td><span class="badge ${c.active !== false ? 'badge-live' : 'badge-off'}">${c.active !== false ? 'Active' : 'Off'}</span></td>
        <td>
          <button class="btn-ghost btn-sm" onclick='openModal("companion",${JSON.stringify(c).replace(/'/g,"&#39;")})'>Edit</button>
          <button class="btn-danger btn-sm" onclick="deleteItem('companions','${c.id}')">Delete</button>
        </td>
      </tr>`).join('') : '<tr><td colspan="7"><div class="empty">No companions</div></td></tr>';
    }

