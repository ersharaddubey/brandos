/* Admin page: profiles */
function renderProfiles(list) {
      document.getElementById('profilesTable').innerHTML = list.length ? list.map(p => `<tr>
        <td style="font-size:1.4rem">${p.avatar || '👤'}</td>
        <td><b>${esc(p.name || '—')}</b>${p.age ? ` · ${p.age}` : ''}</td>
        <td>${esc(p.email || '')}<br><small>${esc(p.phone || '')}</small></td>
        <td>${esc(p.city || '—')}</td>
        <td>${esc(p.gender || '—')}</td>
        <td>
          <button class="btn-ghost btn-sm" onclick='openModal("profile",${JSON.stringify(p).replace(/'/g,"&#39;")})'>Edit</button>
          <button class="btn-danger btn-sm" onclick="deleteItem('profiles','${p.id}')">Delete</button>
        </td>
      </tr>`).join('') : '<tr><td colspan="6"><div class="empty"><div class="emoji">👤</div>No profiles yet — add users from the app or here</div></td></tr>';
    }

