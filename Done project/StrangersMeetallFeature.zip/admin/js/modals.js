/* Admin modals, save, delete */
// ── Modal forms ─────────────────────────────────────
    const formSchemas = {
      slide: [
        { key: 'title', label: 'Title', required: true },
        { key: 'subtitle', label: 'Subtitle' },
        { key: 'cta', label: 'CTA Text' },
        { key: 'target', label: 'Target Screen', type: 'select', options: ['Home','Companions','Experiences','Cities','Booking'] },
        { key: 'emoji', label: 'Emoji', style: 'width:80px' },
        { key: 'bg', label: 'Background Color', type: 'color' },
        { key: 'order', label: 'Order', type: 'number' },
        { key: 'active', label: 'Active', type: 'checkbox' },
      ],
      companion: [
        { key: 'name', label: 'Name', required: true },
        { key: 'role', label: 'Role', required: true },
        { key: 'icon', label: 'Icon / Emoji' },
        { key: 'imageUrl', label: 'Image URL (Cloudinary)' },
        { key: 'rate', label: 'Rate (₹)', type: 'number' },
        { key: 'rating', label: 'Rating', type: 'number' },
        { key: 'city', label: 'City' },
        { key: 'bio', label: 'Bio', type: 'textarea' },
        { key: 'tags', label: 'Tags (comma separated)' },
        { key: 'online', label: 'Online', type: 'checkbox' },
        { key: 'active', label: 'Active', type: 'checkbox' },
      ],
      experience: [
        { key: 'title', label: 'Title', required: true },
        { key: 'subtitle', label: 'Subtitle' },
        { key: 'description', label: 'Description', type: 'textarea' },
        { key: 'icon', label: 'Icon / Emoji' },
        { key: 'imageUrl', label: 'Image URL (Cloudinary)' },
        { key: 'color', label: 'Color', type: 'color' },
        { key: 'active', label: 'Active', type: 'checkbox' },
      ],
      city: [
        { key: 'name', label: 'City Name', required: true },
        { key: 'tagline', label: 'Tagline' },
        { key: 'imageUrl', label: 'Image URL (Cloudinary)' },
        { key: 'active', label: 'Active', type: 'checkbox' },
      ],
      package: [
        { key: 'title', label: 'Title', required: true },
        { key: 'category', label: 'Category', type: 'select', options: ['Regular','Event','Extra'] },
        { key: 'price', label: 'Price (₹)', type: 'number' },
        { key: 'unit', label: 'Unit (e.g. /hour)' },
        { key: 'features', label: 'Features (comma separated)' },
        { key: 'popular', label: 'Popular', type: 'checkbox' },
        { key: 'active', label: 'Active', type: 'checkbox' },
      ],
      profile: [
        { key: 'name', label: 'Full Name', required: true },
        { key: 'email', label: 'Email' },
        { key: 'phone', label: 'Phone' },
        { key: 'avatar', label: 'Avatar Emoji' },
        { key: 'imageUrl', label: 'Photo URL (Cloudinary)' },
        { key: 'gender', label: 'Gender', type: 'select', options: ['','Male','Female','Other','Prefer not to say'] },
        { key: 'age', label: 'Age', type: 'number' },
        { key: 'city', label: 'City' },
        { key: 'bio', label: 'Bio', type: 'textarea' },
        { key: 'interests', label: 'Interests (comma separated)' },
      ],
      event: [
        { key: 'title', label: 'Title', required: true },
        { key: 'city', label: 'City', required: true },
        { key: 'category', label: 'Category' },
        { key: 'date', label: 'Date' },
        { key: 'venue', label: 'Venue' },
        { key: 'price', label: 'Price' },
        { key: 'icon', label: 'Icon / Emoji' },
        { key: 'active', label: 'Active', type: 'checkbox' },
      ],
      user: [
        { key: 'name', label: 'Name', required: true },
        { key: 'email', label: 'Email', required: true },
        { key: 'password', label: 'Password', type: 'password' },
        { key: 'role', label: 'Role', type: 'select', options: ['admin','user'] },
        { key: 'phone', label: 'Phone' },
        { key: 'city', label: 'City' },
        { key: 'bio', label: 'Bio', type: 'textarea' },
        { key: 'avatar', label: 'Avatar Emoji' },
      ],
    };

    function openModal(type, data = null) {
      editType = type;
      editId = data ? data.id : null;
      const titles = {
        slide: data ? 'Edit Slide' : 'Add Slide',
        companion: data ? 'Edit Companion' : 'Add Companion',
        experience: data ? 'Edit Experience' : 'Add Experience',
        city: data ? 'Edit City' : 'Add City',
        package: data ? 'Edit Package' : 'Add Package',
        profile: data ? 'Edit Profile' : 'Add Profile',
        user: data ? 'Edit Admin User' : 'Add Admin User',
      };
      document.getElementById('modalTitle').textContent = titles[type] || 'Edit';
      const schema = formSchemas[type];
      let html = '<div class="form-row">';
      schema.forEach((f, i) => {
        let val = data ? data[f.key] : (f.type === 'checkbox' ? true : '');
        if (f.key === 'tags' || f.key === 'features' || f.key === 'interests') {
          val = Array.isArray(val) ? val.join(', ') : (val || '');
        }
        if (f.type === 'checkbox') {
          html += `<div class="form-group" style="grid-column:1/-1"><label class="check-row">
            <input type="checkbox" id="f_${f.key}" ${val ? 'checked' : ''} /> ${f.label}
          </label></div>`;
        } else if (f.type === 'textarea') {
          html += `<div class="form-group" style="grid-column:1/-1"><label>${f.label}</label>
            <textarea id="f_${f.key}">${esc(val)}</textarea></div>`;
        } else if (f.type === 'select') {
          html += `<div class="form-group"><label>${f.label}</label><select id="f_${f.key}">
            ${f.options.map(o => `<option value="${o}" ${val === o ? 'selected' : ''}>${o || '—'}</option>`).join('')}
          </select></div>`;
        } else if (f.type === 'color') {
          html += `<div class="form-group"><label>${f.label}</label>
            <input type="color" id="f_${f.key}" value="${val || '#E9E3FF'}" style="height:42px;padding:4px" /></div>`;
        } else {
          const full = (f.key === 'title' || f.key === 'name' || f.key === 'bio' || f.key === 'email') && i < 2;
          html += `<div class="form-group"${full ? ' style="grid-column:1/-1"' : ''}><label>${f.label}${f.required ? ' *' : ''}</label>
            <input type="${f.type || 'text'}" id="f_${f.key}" value="${esc(val)}" ${f.required ? 'required' : ''} /></div>`;
        }
      });
      html += '</div>';
      document.getElementById('modalBody').innerHTML = html;
      document.getElementById('modalOverlay').classList.add('open');
    }

    function closeModal() {
      document.getElementById('modalOverlay').classList.remove('open');
      editId = null;
      editType = null;
    }

    function collectForm() {
      const schema = formSchemas[editType];
      const body = {};
      schema.forEach(f => {
        const el = document.getElementById('f_' + f.key);
        if (!el) return;
        if (f.type === 'checkbox') body[f.key] = el.checked;
        else if (f.type === 'number') body[f.key] = el.value === '' ? null : Number(el.value);
        else if (f.key === 'tags' || f.key === 'features' || f.key === 'interests') {
          body[f.key] = el.value.split(',').map(s => s.trim()).filter(Boolean);
        } else body[f.key] = el.value;
      });
      return body;
    }

    async function saveModal() {
      const body = collectForm();
      const collectionMap = {
        slide: 'slides', companion: 'companions', experience: 'experiences',
        city: 'cities', package: 'packages', profile: 'profiles', user: 'users'
      };
      const col = collectionMap[editType];
      try {
        if (editId) {
          await api(`/api/admin/${col}/${editId}`, { method: 'PUT', body: JSON.stringify(body) });
          toast('Updated successfully');
        } else {
          await api(`/api/admin/${col}`, { method: 'POST', body: JSON.stringify(body) });
          toast('Created successfully');
        }
        closeModal();
        loadAll();
      } catch (e) {
        console.error(e);
        toast('Save failed');
      }
    }

    async function deleteItem(collection, id) {
      if (!confirm('Delete this item?')) return;
      try {
        if (collection === 'bookings') {
          await api('/api/admin/bookings/' + id, { method: 'DELETE' });
        } else {
          await api(`/api/admin/${collection}/${id}`, { method: 'DELETE' });
        }
        toast('Deleted');
        loadAll();
      } catch (e) {
        toast('Delete failed');
      }
    }

    async function toggleItem(collection, id, active) {
      try {
        await api(`/api/admin/${collection}/${id}`, { method: 'PUT', body: JSON.stringify({ active }) });
        loadAll();
      } catch (e) {
        toast('Update failed');
      }
    }

    async function setBookingStatus(id, status) {
      try {
        await api('/api/admin/bookings/' + id, { method: 'PATCH', body: JSON.stringify({ status }) });
        toast('Status updated');
        loadAll();
      } catch (e) {
        toast('Update failed');
      }
    }

    