/* StrangersMeet Admin — common */
const API = (location.protocol === 'file:' || !location.origin.includes('4000'))
  ? 'http://localhost:4000'
  : '';

let token = localStorage.getItem('sm_admin_token') || '';
let adminInfo = JSON.parse(localStorage.getItem('sm_admin_info') || '{}');
let editId = null;
let editType = null;
let cache = {};

function headers() {
  return { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token };
}

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}

async function login() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  try {
    const r = await fetch(API + '/api/admin/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    if (!r.ok) {
      document.getElementById('loginErr').textContent = 'Invalid credentials';
      return;
    }
    const j = await r.json();
    token = j.token;
    adminInfo = { name: j.name, email: j.email };
    localStorage.setItem('sm_admin_token', token);
    localStorage.setItem('sm_admin_info', JSON.stringify(adminInfo));
    showApp();
  } catch (e) {
    document.getElementById('loginErr').textContent = 'Server not reachable. Start backend first.';
  }
}

function logout() {
  token = '';
  localStorage.removeItem('sm_admin_token');
  localStorage.removeItem('sm_admin_info');
  document.getElementById('loginView').style.display = 'flex';
  document.getElementById('appView').style.display = 'none';
}

function showApp() {
  document.getElementById('loginView').style.display = 'none';
  document.getElementById('appView').style.display = 'block';
  document.getElementById('adminName').textContent = adminInfo.name || 'Admin';
  document.getElementById('adminEmail').textContent = adminInfo.email || '';
  document.getElementById('adminAv').textContent = (adminInfo.name || 'A')[0].toUpperCase();
  loadAll();
}

function showSection(name) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('sec-' + name).classList.add('active');
  document.querySelector(`[data-section="${name}"]`)?.classList.add('active');
  const titles = {
    dashboard: 'Dashboard', slides: 'Hero slides', companions: 'Companions',
    experiences: 'Experiences', cities: 'Cities', packages: 'Packages',
    bookings: 'Bookings', events: 'City Events', profiles: 'User Profiles', users: 'Admin Users'
  };
  document.getElementById('pageTitle').textContent = titles[name] || name;
  document.getElementById('sidebar').classList.remove('open');
}

async function api(path, opts = {}) {
  const r = await fetch(API + path, { ...opts, headers: { ...headers(), ...(opts.headers || {}) } });
  if (r.status === 401) { logout(); throw new Error('Unauthorized'); }
  if (!r.ok) throw new Error('Request failed');
  return r.json();
}

async function loadAll() {
  const get = async (path, fallback) => {
    try { return await api(path); }
    catch (e) { console.error('Admin API failed:', path, e); return fallback; }
  };
  const [slides, companions, experiences, cities, packages, bookings, profiles, users] = await Promise.all([
    get('/api/admin/slides', []),
    get('/api/admin/companions', []),
    get('/api/admin/experiences', []),
    get('/api/admin/cities', []),
    get('/api/admin/packages', []),
    get('/api/admin/bookings', []),
    get('/api/admin/profiles', []),
    get('/api/admin/users', []),
  ]);
  const stats = await get('/api/admin/stats', {
    slides: slides.length, companions: companions.length, experiences: experiences.length,
    cities: cities.length, packages: packages.length, bookings: bookings.length,
    pending: bookings.filter(b => b.status === 'pending').length,
    profiles: profiles.length, users: users.length
  });
  cache = { stats, slides, companions, experiences, cities, packages, bookings, profiles, users };
  if (typeof renderStats === 'function') renderStats(stats);
  if (typeof renderSlides === 'function') renderSlides(slides);
  if (typeof renderCompanions === 'function') renderCompanions(companions);
  if (typeof renderExperiences === 'function') renderExperiences(experiences);
  if (typeof renderCities === 'function') renderCities(cities);
  if (typeof renderPackages === 'function') renderPackages(packages);
  if (typeof renderBookings === 'function') renderBookings(bookings);
  if (typeof renderProfiles === 'function') renderProfiles(profiles);
  if (typeof renderUsers === 'function') renderUsers(users);
  if (typeof renderDashBookings === 'function') renderDashBookings(bookings);
}

function esc(s) {
  if (s == null) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
