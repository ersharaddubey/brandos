/* Admin boot */
if (token) showApp();
else document.getElementById('loginView').style.display = 'flex';
