export const heroSlides = [
  {
    id: 's1',
    title: 'Find Your Perfect Companion',
    subtitle: 'ID Verified · Platonic · Safe',
    cta: 'Browse Companions',
    target: 'Companions',
    bg: '#E9E3FF',
    emoji: '💜',
  },
  {
    id: 's2',
    title: 'From ₹99 / hour',
    subtitle: 'Virtual text · voice · video — or meet in person',
    cta: 'See packages',
    target: 'Booking',
    bg: '#DDF3E8',
    emoji: '💸',
  },
  {
    id: 's3',
    title: 'Equal Date™',
    subtitle: 'Split fair. Meet better.',
    cta: 'How it works',
    target: 'Home',
    bg: '#F4DDE3',
    emoji: '⚖️',
  },
  {
    id: 's4',
    title: 'Movie · Cafe · Event +1',
    subtitle: 'Fixed activity packages — one-tap book',
    cta: 'Explore',
    target: 'Experiences',
    bg: '#FFE5D0',
    emoji: '✨',
  },
  {
    id: 's5',
    title: 'Cities Across India',
    subtitle: 'Delhi · Mumbai · Bangalore & more',
    cta: 'See cities',
    target: 'Cities',
    bg: '#E0F2FE',
    emoji: '📍',
  },
];

/** Amazon-style top category strip */
export const mallCategories = [
  { key: 'boyfriend', label: 'Boyfriend', icon: '💙', screen: 'Companions' },
  { key: 'girlfriend', label: 'Girlfriend', icon: '💖', screen: 'Companions' },
  { key: 'platonic', label: 'Friend', icon: '🤝', screen: 'Companions' },
  { key: 'virtual', label: 'Virtual', icon: '📱', screen: 'Booking' },
  { key: 'gaming', label: 'Gaming', icon: '🎮', screen: 'Companions' },
  { key: 'experiences', label: 'Experiences', icon: '✨', screen: 'Experiences' },
  { key: 'cities', label: 'Cities', icon: '📍', screen: 'Cities' },
  { key: 'meetup', label: 'Free Meetup', icon: '🎉', screen: 'FreeMeetup' },
  { key: 'cityevents', label: 'Events', icon: '🎫', screen: 'CityEvents' },
  { key: 'book', label: 'Book Now', icon: '⚡', screen: 'Booking' },
];

/**
 * Male–Female meet features (Amazon department style)
 * Activity-first · public venues · platonic by default
 */
export const meetFeatures = [
  // A — 1:1 Meet types
  { key: 'date_hang', label: 'Date Hangout', icon: '💜', desc: 'Casual date vibe', screen: 'Companions', section: 'meet' },
  { key: 'cafe_chat', label: 'Cafe Chat', icon: '☕', desc: 'Coffee & talk · from ₹599', screen: 'Experiences', section: 'meet' },
  { key: 'movie_duo', label: 'Movie Duo', icon: '🎬', desc: 'Cinema + after · from ₹799', screen: 'Experiences', section: 'meet' },
  { key: 'food_crawl', label: 'Food Crawl', icon: '🍜', desc: 'Street food / new spots', screen: 'Experiences', section: 'meet' },
  { key: 'gym_partner', label: 'Gym Partner', icon: '🏋️', desc: 'Workout together · from ₹599', screen: 'Companions', section: 'meet' },
  { key: 'travel_duo', label: 'Travel Duo', icon: '✈️', desc: 'Day trip / city explore', screen: 'Companions', section: 'meet' },
  { key: 'event_plus1', label: 'Event +1', icon: '🎉', desc: 'Wedding / party · from ₹2499', screen: 'Booking', section: 'meet' },
  { key: 'virtual_chat', label: 'Virtual Chat', icon: '📱', desc: 'Text ₹99 · Voice ₹199 · Video ₹299', screen: 'Booking', section: 'meet' },
  { key: 'photo_walk', label: 'Photo Walk', icon: '📸', desc: 'City spots together', screen: 'Experiences', section: 'meet' },
  { key: 'study_partner', label: 'Study Partner', icon: '📚', desc: 'Library / focus cafe', screen: 'Companions', section: 'meet' },
  { key: 'long_drive', label: 'Long Drive', icon: '🚗', desc: 'Scenic drive + dinner', screen: 'Experiences', section: 'meet' },
  { key: 'language_x', label: 'Language Exchange', icon: '🗣️', desc: 'Practice & learn', screen: 'Companions', section: 'meet' },
  { key: 'trek_partner', label: 'Trek Partner', icon: '🥾', desc: 'Weekend short trek', screen: 'Experiences', section: 'meet' },
  // B — Group
  { key: 'micro_meet', label: 'Micro Meetup', icon: '👥', desc: '4–6 strangers, one table', screen: 'FreeMeetup', section: 'group' },
  { key: 'dinner_table', label: 'Dinner Table', icon: '🍽️', desc: 'Shared dinner group', screen: 'FreeMeetup', section: 'group' },
  { key: 'activity_crew', label: 'Activity Crew', icon: '🎯', desc: 'Host or join activity', screen: 'FreeMeetup', section: 'group' },
  { key: 'hobby_clan', label: 'Hobby Clan', icon: '🎲', desc: 'Weekly same hobby', screen: 'FreeMeetup', section: 'group' },
  { key: 'new_city_pack', label: 'New in City', icon: '🏙️', desc: 'Meet other newcomers', screen: 'FreeMeetup', section: 'group' },
  // C — Niche India
  { key: 'festival_buddy', label: 'Festival Buddy', icon: '🪔', desc: 'Diwali, mela, carnival', screen: 'Booking', section: 'niche' },
  { key: 'temple_walk', label: 'Temple Walk', icon: '🛕', desc: 'Darshan + calm company', screen: 'Companions', section: 'niche' },
  { key: 'career_coffee', label: 'Career Coffee', icon: '💼', desc: 'Informal career chat', screen: 'Companions', section: 'niche' },
  { key: 'pet_walk', label: 'Pet Walk', icon: '🐕', desc: 'Dog park / evening walk', screen: 'FreeMeetup', section: 'niche' },
  { key: 'late_chai', label: 'Late-Night Chai', icon: '🌙', desc: 'Safe public adda', screen: 'FreeMeetup', section: 'niche' },
  { key: 'museum_plus1', label: 'Museum +1', icon: '🖼️', desc: 'Exhibition company', screen: 'Experiences', section: 'niche' },
  { key: 'volunteer_day', label: 'Volunteer Day', icon: '💚', desc: 'NGO / clean-up together', screen: 'FreeMeetup', section: 'niche' },
];

export const meetSections = [
  { key: 'meet', title: 'MEET TYPES', subtitle: '1:1 · Virtual · In-person' },
  { key: 'group', title: 'GROUP HANGS', subtitle: '3–6 people · low pressure' },
  { key: 'niche', title: 'INDIA SPECIALS', subtitle: 'Local vibes only' },
];
