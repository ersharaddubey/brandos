/**
 * Events flow: select CITY first → then all categories + features + listings inside that city.
 * Does not navigate to Cities tab — stays under Events.
 */

export type CityEvent = {
  id: string;
  city: string;
  title: string;
  category: string;
  date: string;
  venue: string;
  price: string;
  icon: string;
  active: boolean;
  /** optional link to meet feature key */
  featureKey?: string;
};

/** List 2 — city event types */
export const eventCategories = [
  { key: 'Music', icon: '🎵', label: 'Music' },
  { key: 'Comedy', icon: '🎤', label: 'Comedy' },
  { key: 'Theatre', icon: '🎭', label: 'Theatre / Arts' },
  { key: 'Sports', icon: '⚽', label: 'Sports' },
  { key: 'Food', icon: '🍜', label: 'Food & Drink' },
  { key: 'Nightlife', icon: '🌙', label: 'Nightlife' },
  { key: 'Workshop', icon: '🛠️', label: 'Workshops' },
  { key: 'Tech', icon: '💻', label: 'Tech / Startup' },
  { key: 'Fitness', icon: '🏋️', label: 'Fitness' },
  { key: 'Festival', icon: '🪔', label: 'Festival / Mela' },
  { key: 'Movies', icon: '🎬', label: 'Movies' },
  { key: 'Networking', icon: '🤝', label: 'Networking' },
  { key: 'Spiritual', icon: '🛕', label: 'Spiritual' },
  { key: 'Market', icon: '🛍️', label: 'Markets' },
  { key: 'Kids', icon: '🧒', label: 'Kids / Family' },
];

/** List 1 — app features as bookable event-style activities inside a city */
export const cityAppFeatures = [
  { key: 'date_hang', label: 'Date Hangout', icon: '💜', category: 'Meet' },
  { key: 'cafe_chat', label: 'Cafe Chat', icon: '☕', category: 'Meet' },
  { key: 'movie_duo', label: 'Movie Duo', icon: '🎬', category: 'Movies' },
  { key: 'food_crawl', label: 'Food Crawl', icon: '🍜', category: 'Food' },
  { key: 'gym_partner', label: 'Gym Partner', icon: '🏋️', category: 'Fitness' },
  { key: 'travel_duo', label: 'Travel Duo', icon: '✈️', category: 'Meet' },
  { key: 'event_plus1', label: 'Event Plus-One', icon: '🎫', category: 'Meet' },
  { key: 'photo_walk', label: 'Photo Walk', icon: '📸', category: 'Meet' },
  { key: 'study_partner', label: 'Study Partner', icon: '📚', category: 'Meet' },
  { key: 'long_drive', label: 'Long Drive', icon: '🚗', category: 'Meet' },
  { key: 'language_x', label: 'Language Exchange', icon: '🗣️', category: 'Meet' },
  { key: 'trek_partner', label: 'Trek Partner', icon: '🥾', category: 'Fitness' },
  { key: 'micro_meet', label: 'Micro Meetup', icon: '👥', category: 'Networking' },
  { key: 'dinner_table', label: 'Dinner Table', icon: '🍽️', category: 'Food' },
  { key: 'activity_crew', label: 'Activity Crew', icon: '🎯', category: 'Meet' },
  { key: 'hobby_clan', label: 'Hobby Clan', icon: '🎲', category: 'Meet' },
  { key: 'new_city_pack', label: 'New in City', icon: '🏙️', category: 'Networking' },
  { key: 'festival_buddy', label: 'Festival Buddy', icon: '🪔', category: 'Festival' },
  { key: 'temple_walk', label: 'Temple Walk', icon: '🛕', category: 'Spiritual' },
  { key: 'career_coffee', label: 'Career Coffee', icon: '💼', category: 'Networking' },
  { key: 'pet_walk', label: 'Pet Walk', icon: '🐕', category: 'Fitness' },
  { key: 'late_chai', label: 'Late-Night Chai', icon: '🌙', category: 'Nightlife' },
  { key: 'museum_plus1', label: 'Museum +1', icon: '🖼️', category: 'Theatre' },
  { key: 'volunteer_day', label: 'Volunteer Day', icon: '💚', category: 'Meet' },
  { key: 'wishlist', label: 'Save / Wishlist', icon: '⭐', category: 'Meet' },
  { key: 'host_mode', label: 'Host a Meetup', icon: '📢', category: 'Networking' },
  { key: 'map_view', label: 'Map nearby', icon: '🗺️', category: 'Meet' },
  { key: 'safety_checkin', label: 'Safety Check-in', icon: '🛡️', category: 'Meet' },
];

export const eventCities = [
  'Mumbai',
  'Delhi NCR',
  'Bangalore',
  'Pune',
  'Ahmedabad',
  'Jaipur',
  'Goa',
  'Hyderabad',
  'Chennai',
  'Kolkata',
];

/** Sample listings per city × category (local data; free API can merge later) */
function seedEvents(): CityEvent[] {
  const samples: Omit<CityEvent, 'id' | 'city'>[] = [
    { title: 'Indie Night Live', category: 'Music', date: '2026-10-25', venue: 'Local live venue', price: '₹799', icon: '🎵', active: true },
    { title: 'Stand-up Night', category: 'Comedy', date: '2026-10-26', venue: 'Comedy club', price: '₹499', icon: '🎤', active: true },
    { title: 'Weekend Theatre', category: 'Theatre', date: '2026-10-27', venue: 'City auditorium', price: '₹600', icon: '🎭', active: true },
    { title: 'Morning Run Club', category: 'Sports', date: '2026-10-19', venue: 'City park', price: 'Free', icon: '🏃', active: true },
    { title: 'Food Truck Sunday', category: 'Food', date: '2026-10-20', venue: 'Central lawn', price: 'Free entry', icon: '🍔', active: true },
    { title: 'Open Mic & Karaoke', category: 'Nightlife', date: '2026-10-24', venue: 'Cafe lounge', price: '₹299', icon: '🎶', active: true },
    { title: 'Pottery Workshop', category: 'Workshop', date: '2026-10-21', venue: 'Art studio', price: '₹1200', icon: '🏺', active: true },
    { title: 'Founders Mixer', category: 'Tech', date: '2026-10-22', venue: 'Coworking space', price: '₹199', icon: '💻', active: true },
    { title: 'Yoga in the Park', category: 'Fitness', date: '2026-10-18', venue: 'Public park', price: 'Free', icon: '🧘', active: true },
    { title: 'Local Mela Night', category: 'Festival', date: '2026-10-28', venue: 'Heritage area', price: '₹150', icon: '🪔', active: true },
    { title: 'Special Screening', category: 'Movies', date: '2026-10-23', venue: 'Multiplex', price: '₹350', icon: '🎬', active: true },
    { title: 'Career Coffee Circle', category: 'Networking', date: '2026-10-20', venue: 'Cafe district', price: 'Pay for coffee', icon: '☕', active: true },
    { title: 'Temple Evening Aarti', category: 'Spiritual', date: '2026-10-19', venue: 'Main temple', price: 'Free', icon: '🛕', active: true },
    { title: 'Sunday Flea Market', category: 'Market', date: '2026-10-19', venue: 'Market square', price: 'Free', icon: '🛍️', active: true },
    { title: 'Kids Story Hour', category: 'Kids', date: '2026-10-25', venue: 'Library', price: 'Free', icon: '📚', active: true },
  ];

  const out: CityEvent[] = [];
  let n = 1;
  for (const city of eventCities) {
    for (const s of samples) {
      out.push({
        id: `ev-${n++}`,
        city,
        ...s,
        title: `${s.title}`,
        venue: `${city} · ${s.venue}`,
      });
    }
  }
  return out;
}

export const cityEvents: CityEvent[] = seedEvents();

/** Free public event APIs (docs links) — India coverage limited on most free tiers */
export const FREE_EVENT_APIS = [
  {
    name: 'Ticketmaster Discovery API',
    free: '5,000 calls/day',
    link: 'https://developer.ticketmaster.com/products-and-docs/apis/discovery-api/v2/',
    note: 'Best free tier; strong US/EU, weak India',
  },
  {
    name: 'SeatGeek Platform API',
    free: 'Free key with limits',
    link: 'https://platform.seatgeek.com/',
    note: 'Mostly US sports/concerts',
  },
  {
    name: 'Songkick API',
    free: 'API key required',
    link: 'https://www.songkick.com/developer',
    note: 'Music / concerts',
  },
  {
    name: 'FindLocal Events API',
    free: '1,000 calls/month',
    link: 'https://findlocal.community/',
    note: 'US + UK hyper-local only',
  },
  {
    name: 'Indian Festivals API (open source)',
    free: 'No auth',
    link: 'https://github.com/pyapril15/indian-festivals-api',
    note: 'Festival / holiday dates for India',
  },
];
