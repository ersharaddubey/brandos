export interface Experience {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  color: string;
  price?: number;
  duration?: string;
}

export const experiences: Experience[] = [
  {
    id: '1',
    title: 'Movie Date',
    subtitle: 'with Companion',
    description: 'Two people, one movie, and maybe a story worth telling. Ticket + company included vibe.',
    icon: '🎬',
    color: '#ff6b35',
    price: 799,
    duration: '2–3 hrs',
  },
  {
    id: '2',
    title: 'Cafe Meetup',
    subtitle: 'Chill Vibes',
    description: 'Coffee, conversations, and connections over a cozy cafe setting. Public place only.',
    icon: '☕',
    color: '#3b82f6',
    price: 599,
    duration: '1–2 hrs',
  },
  {
    id: '3',
    title: 'Road Trip',
    subtitle: 'with Companion',
    description: 'Unknown roads, great playlists, and conversations you will never forget.',
    icon: '🚗',
    color: '#a855f7',
    price: 2499,
    duration: 'Half day',
  },
  {
    id: '4',
    title: 'Long Drive & Dinner',
    subtitle: 'with Companion',
    description: 'A scenic drive, great food, and company that feels easy.',
    icon: '🍽️',
    color: '#f59e0b',
    price: 1999,
    duration: '3–4 hrs',
  },
  {
    id: '5',
    title: 'Mall & Shopping',
    subtitle: 'Stylist buddy',
    description: 'Mall runs, outfit opinions, and zero judgment shopping partner.',
    icon: '🛍️',
    color: '#ec4899',
    price: 699,
    duration: '2 hrs',
  },
  {
    id: '6',
    title: 'City Explorer',
    subtitle: 'Local spots',
    description: 'Day walks, hidden cafes, photo spots — someone who knows the city.',
    icon: '🧭',
    color: '#14b8a6',
    price: 1499,
    duration: '3 hrs',
  },
];

export const howItWorks = [
  {
    step: 1,
    title: 'Choose Experience or Companion',
    description: 'Pick an activity package or a verified companion that matches your vibe.',
  },
  {
    step: 2,
    title: 'Book Your Slot',
    description: 'Select date, duration, and role. Pay a small advance to confirm.',
  },
  {
    step: 3,
    title: 'Get Matched & Verified',
    description: 'ID-verified companion. Public venues for first meets. WhatsApp confirm optional.',
  },
  {
    step: 4,
    title: 'Meet · Enjoy · Review',
    description: 'Show up, enjoy real company, leave a review. Easy cancel up to 2 hrs before.',
  },
];

export const stats = [
  { value: '21K+', label: 'Members', icon: '👥' },
  { value: '350+', label: 'Events', icon: '📅' },
  { value: '20+', label: 'Cities', icon: '📍' },
  { value: '4.9', label: 'Rating', icon: '⭐' },
  { value: '100%', label: 'Verified', icon: '🛡️' },
];

export const features = [
  {
    title: 'ID Verified Companions',
    description: 'Government ID checked. Real people only.',
    icon: '🪪',
  },
  {
    title: '100% Platonic & Safe',
    description: 'Clear boundaries. Public places for first meets.',
    icon: '🤝',
  },
  {
    title: 'Equal Date™',
    description: 'Split cost fairly. Meet without full payment pressure.',
    icon: '⚖️',
  },
  {
    title: 'Easy Cancel · Full Refund',
    description: 'Cancel up to 2 hours before. No questions asked.',
    icon: '↩️',
  },
];

export const trustBadges = [
  { icon: '🪪', label: 'ID Verified' },
  { icon: '📍', label: 'Public Meetups' },
  { icon: '💜', label: '100% Platonic' },
  { icon: '🔒', label: 'Private & Confidential' },
  { icon: '↩️', label: 'Easy Cancel' },
  { icon: '⭐', label: 'Rated Companions' },
];

export const cities = [
  { name: 'Delhi NCR', tagline: 'Where connections begin' },
  { name: 'Ahmedabad', tagline: 'New vibes, new people' },
  { name: 'Jaipur', tagline: 'Royal meets romance' },
  { name: 'Surat', tagline: 'Feel the vibe of togetherness' },
  { name: 'Baroda', tagline: 'Culture, people & good times' },
  { name: 'Rajkot', tagline: 'Where friendships turn unforgettable' },
  { name: 'Jodhpur', tagline: 'Blue city, warm connections' },
  { name: 'Udaipur', tagline: 'Romance by the lakes' },
  { name: 'Pune', tagline: 'Smart city, better vibes' },
  { name: 'Kota', tagline: 'New people, new stories' },
  { name: 'Indore', tagline: 'Food, fun & friends' },
  { name: 'Bhopal', tagline: 'The city of lakes & lovely souls' },
  { name: 'Mumbai', tagline: 'Maximum city, maximum vibes' },
  { name: 'Lucknow', tagline: 'Nawabi vibes, modern connections' },
  { name: 'Hyderabad', tagline: 'Where every moment connects' },
  { name: 'Bangalore', tagline: 'Tech city, real connections' },
  { name: 'Kolkata', tagline: 'The city of joy & love' },
  { name: 'Chennai', tagline: 'Southern charm, epic nights' },
  { name: 'Goa', tagline: 'Unmatched energy, unforgettable nights' },
  { name: 'Chandigarh', tagline: 'Beautiful city, beautiful people' },
];

// ——— Companion model ———

export interface Companion {
  id: string;
  name: string;
  role: string;
  rating: number;
  rate: number; // ₹ per hour
  tags: string[];
  icon: string;
  bio: string;
  online?: boolean;
  city?: string;
  verified?: boolean;
  roles?: string[]; // brother | boyfriend | friend | event
  virtualOk?: boolean;
}

export const companionCategories = [
  { key: 'boyfriend', label: 'Rent a Boyfriend', icon: '💙', desc: 'Charming companion for events & dates' },
  { key: 'girlfriend', label: 'Rent a Girlfriend', icon: '💖', desc: 'Sweet company for social occasions' },
  { key: 'platonic', label: 'Platonic Friend', icon: '🤝', desc: 'Just good company, zero pressure' },
  { key: 'virtual', label: 'Virtual Companion', icon: '📱', desc: 'Text, voice or video from home' },
  { key: 'coffee', label: 'Coffee Date', icon: '☕', desc: 'Casual chat over coffee' },
  { key: 'gaming', label: 'Gaming Buddy', icon: '🎮', desc: 'Play, stream, hang online or offline' },
  { key: 'listener', label: 'Good Listener', icon: '🎧', desc: 'Someone to talk to, no judgment' },
  { key: 'shopping', label: 'Shopping Buddy', icon: '🛍️', desc: 'Stylist vibes & mall runs' },
  { key: 'travel', label: 'Travel Companion', icon: '✈️', desc: 'City guide & trip partner' },
  { key: 'fitness', label: 'Fitness Motivator', icon: '💪', desc: 'Gym buddy & health push' },
  { key: 'event', label: 'Event Partner', icon: '🎉', desc: 'Weddings, parties, corporate' },
];

export const companions: Companion[] = [
  {
    id: 'c1',
    name: 'Arjun M.',
    role: 'Rent a Boyfriend',
    rating: 4.9,
    rate: 999,
    tags: ['Charming', 'Good Listener', 'Event Date'],
    icon: '👨',
    bio: 'Warm, well-spoken companion for dinners, events, and social outings. Strictly platonic.',
    online: true,
    city: 'Delhi NCR',
    verified: true,
    roles: ['boyfriend', 'friend', 'event'],
    virtualOk: true,
  },
  {
    id: 'c2',
    name: 'Priya S.',
    role: 'Rent a Girlfriend',
    rating: 5.0,
    rate: 1499,
    tags: ['Conversationalist', 'Family Events', 'Sweet'],
    icon: '👩',
    bio: 'Elegant company for family functions, parties, and thoughtful conversations.',
    online: true,
    city: 'Mumbai',
    verified: true,
    roles: ['girlfriend', 'friend', 'event'],
    virtualOk: true,
  },
  {
    id: 'c3',
    name: 'Rahul K.',
    role: 'Tech & Gaming Buddy',
    rating: 4.8,
    rate: 599,
    tags: ['Gamer', 'Tech Guru', 'Casual'],
    icon: '🧑‍💻',
    bio: 'Co-op games, tech talk, and chill hangouts — online or at a cafe.',
    online: true,
    city: 'Bangalore',
    verified: true,
    roles: ['friend', 'gaming'],
    virtualOk: true,
  },
  {
    id: 'c4',
    name: 'Neha R.',
    role: 'Shopping & Stylist',
    rating: 4.9,
    rate: 899,
    tags: ['Fashion', 'Bargaining', 'Trendy'],
    icon: '💃',
    bio: 'Mall runs, outfit advice, and honest fashion opinions.',
    city: 'Delhi NCR',
    verified: true,
    roles: ['friend', 'shopping'],
    virtualOk: false,
  },
  {
    id: 'c5',
    name: 'Vikram Singh',
    role: 'Fitness Motivator',
    rating: 4.7,
    rate: 699,
    tags: ['Gym Spotter', 'Running', 'Health'],
    icon: '🏋️',
    bio: 'Gym sessions, morning runs, and accountability without the pressure.',
    online: true,
    city: 'Pune',
    verified: true,
    roles: ['friend', 'fitness'],
    virtualOk: true,
  },
  {
    id: 'c6',
    name: 'Aisha P.',
    role: 'Travel Companion',
    rating: 5.0,
    rate: 1299,
    tags: ['City Guide', 'Photography', 'Explorer'],
    icon: '🧭',
    bio: 'Day trips, city walks, and someone who knows the best spots.',
    city: 'Jaipur',
    verified: true,
    roles: ['friend', 'travel', 'event'],
    virtualOk: false,
  },
  {
    id: 'c7',
    name: 'Kabir S.',
    role: 'Caring Brother / Friend',
    rating: 4.8,
    rate: 799,
    tags: ['Brother', 'Family Events', 'Protective'],
    icon: '🧔',
    bio: 'Brother figure for family gatherings, outings, or when you just need solid company.',
    online: true,
    city: 'Lucknow',
    verified: true,
    roles: ['brother', 'friend', 'event'],
    virtualOk: true,
  },
  {
    id: 'c8',
    name: 'Meera T.',
    role: 'Virtual Listener',
    rating: 4.9,
    rate: 299,
    tags: ['Listener', 'Calm', 'Night OK'],
    icon: '🎧',
    bio: 'Text, voice or video — someone to talk to when the city feels empty. Strictly platonic.',
    online: true,
    city: 'Pan-India',
    verified: true,
    roles: ['listener', 'friend'],
    virtualOk: true,
  },
];

/** Role options shown at booking */
export const companionRoles = [
  { key: 'friend', label: 'Best Friend', icon: '😄', desc: 'No role-play — real company', from: 499 },
  { key: 'brother', label: 'Caring Brother', icon: '🤝', desc: 'Family events & protective presence', from: 499 },
  { key: 'boyfriend', label: 'Supportive Boyfriend', icon: '💛', desc: 'Events where you need a +1 partner', from: 799 },
  { key: 'girlfriend', label: 'Supportive Girlfriend', icon: '💖', desc: 'Social & family occasions', from: 799 },
  { key: 'event', label: 'Event +1', icon: '🎉', desc: 'Weddings, parties, corporate', from: 999 },
  { key: 'listener', label: 'Good Listener', icon: '🎧', desc: 'Talk it out — zero judgment', from: 199 },
];

// ——— Packages (market-aligned) ———

export const packages = [
  // Virtual — high volume entry
  {
    id: 'v1',
    category: 'Virtual',
    title: 'Text Companion',
    price: 99,
    unit: '/hour',
    features: ['WhatsApp / in-app text', 'At your pace', 'Full confidentiality', 'Platonic only'],
    popular: false,
  },
  {
    id: 'v2',
    category: 'Virtual',
    title: 'Voice Companion',
    price: 199,
    unit: '/hour',
    features: ['Phone / WhatsApp call', 'Real-time talk', 'Any time zone', 'Late night OK'],
    popular: true,
  },
  {
    id: 'v3',
    category: 'Virtual',
    title: 'Video Companion',
    price: 299,
    unit: '/hour',
    features: ['Google Meet / Zoom / WA', 'Face-to-face from home', 'Watch together option', 'Private link'],
    popular: false,
  },
  // In-person core
  {
    id: 'p1',
    category: 'In-Person',
    title: '1 Hour Meet',
    price: 699,
    unit: '/hour',
    features: ['1-hour companionship', 'Public venue', 'Basic conversation', 'ID verified'],
    popular: false,
  },
  {
    id: 'p2',
    category: 'In-Person',
    title: '3 Hours',
    price: 1899,
    unit: '/3 hours',
    features: ['3-hour companionship', 'Cafe / mall / walk', 'Quality time', 'Easy cancel'],
    popular: true,
  },
  {
    id: 'p3',
    category: 'In-Person',
    title: '6 Hours / Half Day',
    price: 3499,
    unit: '/6 hours',
    features: ['Half-day support', 'Event or outing', 'Priority match'],
    popular: false,
  },
  // Event
  {
    id: 'e1',
    category: 'Event',
    title: 'Event +1 (4 hrs)',
    price: 2499,
    unit: '/4 hours',
    features: ['Wedding / party ready', 'Professional conduct', 'Role: friend or partner'],
    popular: true,
  },
  {
    id: 'e2',
    category: 'Event',
    title: 'Full Day Event',
    price: 4999,
    unit: '/8 hours',
    features: ['Full day event partner', 'Corporate friendly', 'Priority booking'],
    popular: false,
  },
];

/** Fixed activity packages — one-tap book style */
export const activityPackages = [
  { id: 'a1', title: 'Movie Companion', icon: '🎬', price: 799, duration: '2–3 hrs', desc: 'Cinema + short hangout after' },
  { id: 'a2', title: 'Cafe & Chat', icon: '☕', price: 599, duration: '1.5–2 hrs', desc: 'Coffee, conversation, public cafe' },
  { id: 'a3', title: 'Mall & Shopping', icon: '🛍️', price: 699, duration: '2 hrs', desc: 'Shopping partner & honest opinions' },
  { id: 'a4', title: 'Event Plus-One', icon: '🎉', price: 2499, duration: '4 hrs', desc: 'Weddings, parties, office events' },
  { id: 'a5', title: 'City Explorer', icon: '🗺️', price: 1499, duration: '3 hrs', desc: 'Local spots, walks, photo stops' },
  { id: 'a6', title: 'Fitness Walk', icon: '🏃', price: 499, duration: '1.5 hrs', desc: 'Morning or evening walk together' },
  { id: 'a7', title: 'Long Drive & Dinner', icon: '🚗', price: 1999, duration: '3–4 hrs', desc: 'Scenic drive + meal' },
  { id: 'a8', title: 'Gym Partner', icon: '🏋️', price: 599, duration: '1–1.5 hrs', desc: 'Spotter & accountability' },
];

/** Subscriptions for retention */
export const subscriptions = [
  {
    id: 's1',
    title: 'Weekly Buddy',
    price: 1999,
    unit: '/week',
    sessions: 2,
    save: 'Save ~15%',
    features: ['2 sessions / week', 'Flexible schedule', 'Same companion preferred'],
    popular: false,
  },
  {
    id: 's2',
    title: 'Monthly Companion',
    price: 5999,
    unit: '/month',
    sessions: 4,
    save: 'Save ~20%',
    features: ['4 sessions / month', 'Priority booking', 'Mix virtual + in-person'],
    popular: true,
  },
  {
    id: 's3',
    title: 'Premium Plan',
    price: 9999,
    unit: '/month',
    sessions: 8,
    save: 'Save ~25%',
    features: ['8 sessions / month', 'Priority + dedicated support', 'Event slots included'],
    popular: false,
  },
];

export const activities = [
  'Social Event',
  'Movie / Concert',
  'Dinner / Cafe',
  'Just Chatting',
  'Gaming Session',
  'Shopping',
  'Travel / Day trip',
  'Gym / Walk',
  'Virtual (Text / Voice / Video)',
  'Wedding / Family Function',
];

export const durations = [
  { label: '1 Hour', hours: 1 },
  { label: '2 Hours', hours: 2 },
  { label: '3 Hours', hours: 3 },
  { label: '4 Hours', hours: 4 },
  { label: '6 Hours (Half Day)', hours: 6 },
  { label: '8 Hours (Full Day)', hours: 8 },
];

export const virtualModes = [
  { key: 'text', label: 'Text Chat', icon: '💬', price: 99, unit: '/hr' },
  { key: 'voice', label: 'Voice Call', icon: '📞', price: 199, unit: '/hr' },
  { key: 'video', label: 'Video Call', icon: '🎥', price: 299, unit: '/hr' },
];
