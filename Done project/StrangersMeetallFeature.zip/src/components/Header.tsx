import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { colors } from '../theme/colors';

interface HeaderProps {
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  onMenuPress?: () => void;
  rightAction?: React.ReactNode;
}

export default function Header({
  title,
  showBack,
  onBack,
  onMenuPress,
  rightAction,
}: HeaderProps) {
  return (
    <View style={styles.container}>
      <View style={styles.row}>
        {showBack ? (
          <TouchableOpacity onPress={onBack} style={styles.iconBtn} hitSlop={10}>
            <Text style={styles.backText}>←</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity onPress={onMenuPress} style={styles.iconBtn} hitSlop={10}>
            <View style={styles.menuLines}>
              <View style={styles.menuLine} />
              <View style={[styles.menuLine, styles.menuLineMid]} />
              <View style={styles.menuLine} />
            </View>
          </TouchableOpacity>
        )}

        {showBack && title ? (
          <Text style={styles.titleCentered} numberOfLines={1}>{title}</Text>
        ) : (
          <View style={styles.logoRow}>
            <View style={styles.logoMark}>
              <Text style={styles.logoMarkText}>S</Text>
            </View>
            <Text style={styles.logo}>Strangers</Text>
            <Text style={styles.logoAccent}>Meet</Text>
          </View>
        )}

        <View style={styles.right}>{rightAction || <View style={styles.placeholder} />}</View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.background,
    paddingTop: 6,
    paddingBottom: 10,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 44,
  },
  iconBtn: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: '#252432',
    shadowOffset: { width: 2, height: 3 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
  },
  menuLines: { width: 18, height: 14, justifyContent: 'space-between' },
  menuLine: { height: 2.5, backgroundColor: colors.text, borderRadius: 2 },
  menuLineMid: { width: 12 },
  backText: { color: colors.text, fontSize: 22, fontWeight: '600' },
  logoRow: { flexDirection: 'row', alignItems: 'center' },
  logoMark: {
    width: 28,
    height: 28,
    borderRadius: 10,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  logoMarkText: { color: '#fff', fontWeight: '900', fontSize: 14 },
  logo: { color: colors.text, fontSize: 17, fontWeight: '800' },
  logoAccent: { color: colors.primary, fontSize: 17, fontWeight: '800' },
  titleCentered: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
    flex: 1,
    textAlign: 'center',
    marginHorizontal: 8,
  },
  right: { minWidth: 42, alignItems: 'flex-end' },
  placeholder: { width: 42 },
});
