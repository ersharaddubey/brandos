/**
 * Optional free Ticketmaster Discovery API.
 * Key: https://developer.ticketmaster.com/products-and-docs/apis/discovery-api/v2/
 * EXPO_PUBLIC_TICKETMASTER_KEY in .env — India coverage limited; local data is always base.
 */
import { cityEvents, CityEvent } from '../data/cityEvents';

const TM_KEY = process.env.EXPO_PUBLIC_TICKETMASTER_KEY || '';

export async function fetchCityEvents(city: string): Promise<CityEvent[]> {
  const local = cityEvents.filter((e) => e.city === city && e.active);
  if (!TM_KEY) return local;

  try {
    const q = encodeURIComponent(city.split(' ')[0]);
    const url = `https://app.ticketmaster.com/discovery/v2/events.json?apikey=${TM_KEY}&city=${q}&size=20`;
    const r = await fetch(url);
    if (!r.ok) return local;
    const j = await r.json();
    const remote: CityEvent[] = (j._embedded?.events || []).map((ev: any, i: number) => ({
      id: `tm-${ev.id || i}`,
      city,
      title: ev.name || 'Event',
      category: ev.classifications?.[0]?.segment?.name || 'Music',
      date: (ev.dates?.start?.localDate as string) || '',
      venue: ev._embedded?.venues?.[0]?.name || 'Venue',
      price: ev.priceRanges
        ? `from ${ev.priceRanges[0].currency} ${ev.priceRanges[0].min}`
        : 'See tickets',
      icon: '🎫',
      active: true,
    }));
    return [...remote, ...local];
  } catch {
    return local;
  }
}
