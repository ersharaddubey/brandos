import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking } from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  onBack: () => void;
}

const FAQS = [
  { q: 'How do I book a companion?', a: 'Open Companions, choose someone, and tap Book.' },
  { q: 'Are meetups free?', a: 'Free Meetup events are free. Companion bookings may have rates.' },
  { q: 'How do I cancel a booking?', a: 'Go to My Bookings and cancel before the scheduled time.' },
  { q: 'Is my data safe?', a: 'Yes. See Privacy & Safety for details.' },
];

export default function HelpScreen({ onBack }: Props) {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.hero}>
        <Text style={styles.heroIcon}>💬</Text>
        <Text style={styles.heroTitle}>Help & Support</Text>
        <Text style={styles.heroSub}>24/7 support available</Text>
      </View>

      {FAQS.map((f, i) => (
        <View key={i} style={styles.faq}>
          <Text style={styles.q}>{f.q}</Text>
          <Text style={styles.a}>{f.a}</Text>
        </View>
      ))}

      <TouchableOpacity
        style={styles.contactBtn}
        onPress={() => Linking.openURL('mailto:support@strangersmeet.app')}
        activeOpacity={0.8}
      >
        <Text style={styles.contactText}>Email Support</Text>
      </TouchableOpacity>
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  hero: { alignItems: 'center', paddingVertical: 20 },
  heroIcon: { fontSize: 40, marginBottom: 8 },
  heroTitle: { color: colors.text, fontSize: 20, fontWeight: '700' },
  heroSub: { color: colors.textMuted, fontSize: 13, marginTop: 4 },
  faq: {
    backgroundColor: colors.card,
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  q: { color: colors.text, fontSize: 15, fontWeight: '600', marginBottom: 6 },
  a: { color: colors.textSecondary, fontSize: 13, lineHeight: 20 },
  contactBtn: {
    backgroundColor: colors.primary,
    borderRadius: 30,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 16,
  },
  contactText: { color: colors.textInverse, fontSize: 15, fontWeight: '700' },
});
