import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  onBack: () => void;
}

export default function TermsScreen({ onBack }: Props) {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.card}>
        <Text style={styles.icon}>📄</Text>
        <Text style={styles.title}>Terms & Conditions</Text>
        <Text style={styles.body}>
          By using StrangersMeet you agree to use the platform respectfully and lawfully.
        </Text>
        <Text style={styles.section}>1. Accounts</Text>
        <Text style={styles.body}>
          You are responsible for the accuracy of your profile and for keeping login details secure.
        </Text>
        <Text style={styles.section}>2. Bookings</Text>
        <Text style={styles.body}>
          Companion rates and experience fees are shown before confirmation. Cancellations follow the policy of each listing.
        </Text>
        <Text style={styles.section}>3. Conduct</Text>
        <Text style={styles.body}>
          Harassment, spam, or illegal activity will result in account suspension.
        </Text>
        <Text style={styles.section}>4. Liability</Text>
        <Text style={styles.body}>
          StrangersMeet is a discovery platform. Meetups happen at your own discretion; we are not liable for third-party interactions.
        </Text>
        <Text style={styles.muted}>Last updated: 2026 · Version 1.0.0</Text>
      </View>
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  card: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 24,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  icon: { fontSize: 36, marginBottom: 12 },
  title: { color: colors.text, fontSize: 20, fontWeight: '700', marginBottom: 12 },
  section: { color: colors.text, fontSize: 15, fontWeight: '700', marginTop: 14, marginBottom: 4 },
  body: { color: colors.textSecondary, fontSize: 14, lineHeight: 22 },
  muted: { color: colors.textMuted, fontSize: 12, marginTop: 20 },
});
