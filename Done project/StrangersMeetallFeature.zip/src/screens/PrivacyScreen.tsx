import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  onBack: () => void;
}

export default function PrivacyScreen({ onBack }: Props) {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.card}>
        <Text style={styles.icon}>🛡️</Text>
        <Text style={styles.title}>Privacy & Safety</Text>
        <Text style={styles.body}>
          Your data is stored securely. We never sell personal information to third parties.
        </Text>
        <Text style={styles.body}>
          • Profile details are only visible to matched companions{'\n'}
          • Location is used only for nearby experiences{'\n'}
          • You can request account deletion anytime{'\n'}
          • Report any unsafe behaviour via Help & Support
        </Text>
        <Text style={styles.muted}>
          Full privacy policy will be available once your account is connected.
        </Text>
      </View>
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  card: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 24,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  icon: { fontSize: 36, marginBottom: 12 },
  title: { color: colors.text, fontSize: 20, fontWeight: '700', marginBottom: 12 },
  body: { color: colors.textSecondary, fontSize: 14, lineHeight: 22, marginBottom: 12 },
  muted: { color: colors.textMuted, fontSize: 13, marginTop: 8 },
});
