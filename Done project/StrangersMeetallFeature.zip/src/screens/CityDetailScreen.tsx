import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { colors } from '../theme/colors';
import { experiences } from '../data/experiences';

interface Props {
  city: { name: string; tagline: string };
  onBack: () => void;
  onNavigate: (screen: string, params?: any) => void;
}

export default function CityDetailScreen({ city, onBack, onNavigate }: Props) {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.hero}>
        <Text style={styles.icon}>📍</Text>
        <Text style={styles.title}>{city.name}</Text>
        <Text style={styles.tagline}>{city.tagline}</Text>
      </View>

      <View style={styles.content}>
        <Text style={styles.sectionLabel}>AVAILABLE EXPERIENCES</Text>
        {experiences.map((exp) => (
          <TouchableOpacity
            key={exp.id}
            style={styles.expCard}
            onPress={() => onNavigate('ExperienceDetail', { experience: exp })}
            activeOpacity={0.85}
          >
            <Text style={styles.expIcon}>{exp.icon}</Text>
            <View style={styles.expInfo}>
              <Text style={[styles.expTitle, { color: exp.color }]}>{exp.title}</Text>
              <Text style={styles.expSub}>{exp.subtitle}</Text>
            </View>
            <Text style={styles.arrow}>→</Text>
          </TouchableOpacity>
        ))}

        <Text style={styles.sectionLabel}>ABOUT {city.name.toUpperCase()}</Text>
        <Text style={styles.desc}>
          Join the StrangersMeet community in {city.name}. Connect with verified members,
          book premium experiences, and create real memories. {city.tagline}.
        </Text>

        <TouchableOpacity style={styles.ctaBtn} activeOpacity={0.8}>
          <Text style={styles.ctaText}>Explore in {city.name}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.backBtn} onPress={onBack}>
          <Text style={styles.backText}>← Back to Cities</Text>
        </TouchableOpacity>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  hero: {
    alignItems: 'center',
    padding: 30,
    paddingTop: 20,
  },
  icon: {
    fontSize: 48,
    marginBottom: 12,
  },
  title: {
    color: colors.text,
    fontSize: 28,
    fontWeight: '800',
  },
  tagline: {
    color: colors.primary,
    fontSize: 15,
    marginTop: 6,
  },
  content: {
    padding: 20,
  },
  sectionLabel: {
    color: colors.secondary,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.5,
    marginBottom: 12,
    marginTop: 8,
  },
  expCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  expIcon: {
    fontSize: 28,
    marginRight: 12,
  },
  expInfo: {
    flex: 1,
  },
  expTitle: {
    fontSize: 15,
    fontWeight: '700',
  },
  expSub: {
    color: colors.textMuted,
    fontSize: 12,
  },
  arrow: {
    color: colors.primary,
    fontSize: 16,
  },
  desc: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 20,
  },
  ctaBtn: {
    backgroundColor: colors.primary,
    borderRadius: 30,
    paddingVertical: 14,
    alignItems: 'center',
  },
  ctaText: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
  },
  backBtn: {
    alignItems: 'center',
    marginTop: 16,
    padding: 10,
  },
  backText: {
    color: colors.primary,
    fontSize: 14,
    fontWeight: '600',
  },
});
