import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import { FeatureDetail } from '../data/featureDetails';

interface Props {
  feature: FeatureDetail;
  onBack: () => void;
  onNavigate: (screen: string, params?: any) => void;
}

export default function FeatureDetailScreen({ feature, onBack, onNavigate }: Props) {
  const { colors } = useTheme();

  const goBook = () => {
    onNavigate('Booking', {
      featureKey: feature.key,
      lookingFor: feature.lookingFor,
      activity: feature.activity,
      featureLabel: feature.label,
      featureIcon: feature.icon,
    });
  };

  const goRelated = () => {
    onNavigate(feature.screen, { featureKey: feature.key });
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={[styles.hero, { backgroundColor: colors.lavender }]}>
        <Text style={styles.icon}>{feature.icon}</Text>
        <Text style={[styles.title, { color: colors.text }]}>{feature.label}</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>{feature.desc}</Text>
        <View style={[styles.chip, { backgroundColor: colors.surface }]}>
          <Text style={[styles.chipText, { color: colors.primary }]}>
            Looking for · {feature.lookingFor}
          </Text>
        </View>
      </View>

      <View style={styles.content}>
        <Text style={[styles.sectionLabel, { color: colors.textMuted }]}>ABOUT</Text>
        <Text style={[styles.desc, { color: colors.textSecondary }]}>{feature.about}</Text>

        <Text style={[styles.sectionLabel, { color: colors.textMuted }]}>WHAT YOU GET</Text>
        {feature.points.map((item, i) => (
          <View key={i} style={styles.listItem}>
            <Text style={[styles.bullet, { color: colors.primary }]}>✓</Text>
            <Text style={[styles.listText, { color: colors.text }]}>{item}</Text>
          </View>
        ))}

        <Text style={[styles.sectionLabel, { color: colors.textMuted }]}>HOW IT WORKS</Text>
        {feature.steps.map((item, i) => (
          <View key={i} style={styles.stepRow}>
            <View style={[styles.stepCircle, { backgroundColor: colors.primary }]}>
              <Text style={styles.stepNum}>{i + 1}</Text>
            </View>
            <Text style={[styles.stepText, { color: colors.text }]}>{item}</Text>
          </View>
        ))}

        <Text style={[styles.sectionLabel, { color: colors.textMuted }]}>TIPS</Text>
        {feature.tips.map((item, i) => (
          <View key={i} style={styles.listItem}>
            <Text style={styles.tipBullet}>•</Text>
            <Text style={[styles.listText, { color: colors.textSecondary }]}>{item}</Text>
          </View>
        ))}

        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: colors.primary }]}
          activeOpacity={0.85}
          onPress={goBook}
        >
          <Text style={styles.bookText}>Book · {feature.label}</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.secondaryBtn, { borderColor: colors.borderStrong }]}
          activeOpacity={0.85}
          onPress={goRelated}
        >
          <Text style={[styles.secondaryText, { color: colors.primary }]}>
            Browse related →
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={onBack} style={styles.backLink}>
          <Text style={[styles.backText, { color: colors.textMuted }]}>← Back</Text>
        </TouchableOpacity>
      </View>
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  hero: {
    alignItems: 'center',
    paddingVertical: 28,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
  },
  icon: { fontSize: 48, marginBottom: 10 },
  title: { fontSize: 24, fontWeight: '800', textAlign: 'center' },
  subtitle: { fontSize: 14, marginTop: 6, textAlign: 'center' },
  chip: {
    marginTop: 14,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
  },
  chipText: { fontSize: 12, fontWeight: '700' },
  content: { padding: 20 },
  sectionLabel: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginTop: 18,
    marginBottom: 10,
  },
  desc: { fontSize: 14, lineHeight: 22 },
  listItem: { flexDirection: 'row', marginBottom: 8, alignItems: 'flex-start' },
  bullet: { fontWeight: '800', marginRight: 10, fontSize: 14 },
  tipBullet: { marginRight: 10, fontSize: 14 },
  listText: { flex: 1, fontSize: 14, lineHeight: 20 },
  stepRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  stepCircle: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  stepNum: { color: '#fff', fontWeight: '800', fontSize: 12 },
  stepText: { flex: 1, fontSize: 14, fontWeight: '600' },
  bookBtn: {
    marginTop: 28,
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
  },
  bookText: { color: '#fff', fontWeight: '800', fontSize: 16 },
  secondaryBtn: {
    marginTop: 12,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
  },
  secondaryText: { fontWeight: '700', fontSize: 14 },
  backLink: { marginTop: 20, alignItems: 'center' },
  backText: { fontSize: 14 },
});
