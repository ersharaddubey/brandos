import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch } from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  onBack: () => void;
}

export default function NotificationsScreen({ onBack }: Props) {
  const [push, setPush] = useState(true);
  const [email, setEmail] = useState(false);
  const [bookings, setBookings] = useState(true);
  const [promos, setPromos] = useState(false);

  const rows = [
    { label: 'Push notifications', desc: 'Receive alerts on your device', value: push, set: setPush },
    { label: 'Email updates', desc: 'Get updates in your inbox', value: email, set: setEmail },
    { label: 'Booking reminders', desc: 'Reminders before experiences', value: bookings, set: setBookings },
    { label: 'Offers & promos', desc: 'Special deals and news', value: promos, set: setPromos },
  ];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.list}>
        {rows.map((r, i) => (
          <View key={i} style={styles.row}>
            <View style={styles.rowText}>
              <Text style={styles.rowLabel}>{r.label}</Text>
              <Text style={styles.rowDesc}>{r.desc}</Text>
            </View>
            <Switch
              value={r.value}
              onValueChange={r.set}
              trackColor={{ false: colors.cardBorder, true: colors.primarySoft }}
              thumbColor={r.value ? colors.primary : colors.textMuted}
            />
          </View>
        ))}
      </View>
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  list: { padding: 16 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  rowText: { flex: 1, marginRight: 12 },
  rowLabel: { color: colors.text, fontSize: 15, fontWeight: '600' },
  rowDesc: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
});
