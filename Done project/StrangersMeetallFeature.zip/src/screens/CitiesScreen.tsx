import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { colors } from '../theme/colors';
import { cities as staticCities } from '../data/experiences';
import { fetchCities } from '../api';

interface Props {
  onNavigate: (screen: string, params?: any) => void;
}

export default function CitiesScreen({ onNavigate }: Props) {
  const [cities, setCities] = useState(staticCities);
  useEffect(() => {
    (async () => {
      const c = await fetchCities();
      if (c && c.length) setCities(c);
    })();
  }, []);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.label}>TOP CITIES</Text>
        <Text style={styles.title}>Vibes everywhere</Text>
        <Text style={styles.desc}>
          Spreading love, connections & unforgettable experiences across India's most vibrant cities.
        </Text>
      </View>

      <View style={styles.list}>
        {cities.map((city: any, i: number) => (
          <TouchableOpacity
            key={city.id || city.name || i}
            style={styles.cityCard}
            activeOpacity={0.8}
            onPress={() => onNavigate('CityDetail', { city })}
          >
            <View style={styles.cityLeft}>
              <Text style={styles.cityIcon}>📍</Text>
              <View>
                <Text style={styles.cityName}>{city.name}</Text>
                <Text style={styles.cityTagline}>{city.tagline}</Text>
              </View>
            </View>
            <Text style={styles.arrow}>→</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.bottom}>
        <Text style={styles.bottomTitle}>YOUR CITY, YOUR VIBE!</Text>
        <Text style={styles.bottomDesc}>
          No matter where you are, StrangersMeet is there to help you connect, vibe & create memories.
        </Text>
        <Text style={styles.comingSoon}>NEW CITIES COMING SOON! STAY TUNED!</Text>
      </View>

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 8,
  },
  label: {
    color: colors.secondary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.6,
    marginBottom: 8,
  },
  title: {
    color: colors.text,
    fontSize: 26,
    fontWeight: '800',
    marginBottom: 8,
  },
  desc: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 21,
  },
  list: {
    paddingHorizontal: 20,
    marginTop: 12,
  },
  cityCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.glass,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  cityLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  cityIcon: {
    fontSize: 22,
    marginRight: 12,
  },
  cityName: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
  },
  cityTagline: {
    color: colors.textMuted,
    fontSize: 12,
    marginTop: 2,
  },
  arrow: {
    color: colors.primary,
    fontSize: 18,
    fontWeight: '600',
  },
  bottom: {
    marginHorizontal: 20,
    marginTop: 16,
    padding: 20,
    backgroundColor: colors.glass,
    borderRadius: 18,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  bottomTitle: {
    color: colors.primary,
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 8,
  },
  bottomDesc: {
    color: colors.textSecondary,
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 12,
  },
  comingSoon: {
    color: colors.accent,
    fontSize: 12,
    fontWeight: '600',
  },
});
