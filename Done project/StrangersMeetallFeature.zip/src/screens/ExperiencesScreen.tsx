import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { colors } from '../theme/colors';
import { experiences as staticExperiences } from '../data/experiences';
import { fetchExperiences } from '../api';

const { width } = Dimensions.get('window');

interface Props {
  onNavigate: (screen: string, params?: any) => void;
}

export default function ExperiencesScreen({ onNavigate }: Props) {
  const [experiences, setExperiences] = useState(staticExperiences);
  useEffect(() => {
    (async () => {
      const e = await fetchExperiences();
      if (e && e.length) setExperiences(e);
    })();
  }, []);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.label}>EXPLORE</Text>
        <Text style={styles.title}>Experiences & Activity Packs</Text>
        <Text style={styles.desc}>
          From cinematic movie dates to midnight long drives, we've got the perfect vibe for you.
        </Text>
      </View>

      <View style={styles.grid}>
        {experiences.map((exp) => (
          <TouchableOpacity
            key={exp.id}
            style={styles.card}
            onPress={() => onNavigate('ExperienceDetail', { experience: exp })}
            activeOpacity={0.85}
          >
            <View style={[styles.iconCircle, { backgroundColor: exp.color + '22' }]}>
              <Text style={styles.icon}>{exp.icon}</Text>
            </View>
            <Text style={[styles.cardTitle, { color: exp.color }]}>{exp.title}</Text>
            <Text style={styles.cardSubtitle}>{exp.subtitle}</Text>
            <Text style={styles.cardDesc} numberOfLines={2}>{exp.description}</Text>
            {exp.price != null && (
              <Text style={{ color: colors.accent, fontWeight: '800', fontSize: 14, marginTop: 6 }}>
                from ₹{exp.price}{exp.duration ? ` · ${exp.duration}` : ''}
              </Text>
            )}
            <View style={styles.arrowRow}>
              <Text style={[styles.arrow, { color: exp.color }]}>Book →</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.equalDate}>
        <Text style={styles.equalTitle}>Equal Date™</Text>
        <Text style={styles.equalDesc}>
          India's first experience where both partners split the date cost 50-50 before booking.
          Fair. Transparent. Respectful.
        </Text>
      </View>

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 8,
  },
  label: {
    color: colors.secondary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.6,
    marginBottom: 8,
  },
  title: {
    color: colors.text,
    fontSize: 26,
    fontWeight: '800',
    marginBottom: 8,
  },
  desc: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 21,
  },
  grid: {
    paddingHorizontal: 20,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  card: {
    width: (width - 52) / 2,
    backgroundColor: colors.glass,
    borderRadius: 18,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  iconCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  icon: {
    fontSize: 24,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '700',
  },
  cardSubtitle: {
    color: colors.textSecondary,
    fontSize: 12,
    marginBottom: 6,
  },
  cardDesc: {
    color: colors.textMuted,
    fontSize: 12,
    lineHeight: 16,
    marginBottom: 8,
  },
  arrowRow: {
    marginTop: 'auto',
  },
  arrow: {
    fontSize: 13,
    fontWeight: '600',
  },
  equalDate: {
    marginHorizontal: 20,
    marginTop: 12,
    backgroundColor: colors.primarySoft,
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 45, 155, 0.3)',
  },
  equalTitle: {
    color: colors.primary,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  equalDesc: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 20,
  },
});
