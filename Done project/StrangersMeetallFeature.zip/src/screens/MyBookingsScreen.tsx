import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  onBack: () => void;
}

export default function MyBookingsScreen({ onBack }: Props) {
  const bookings: any[] = []; // empty — show blank state

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {bookings.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyIcon}>🎫</Text>
          <Text style={styles.emptyTitle}>No bookings yet</Text>
          <Text style={styles.emptyDesc}>
            Your upcoming experiences and companion bookings will appear here.
          </Text>
        </View>
      ) : (
        bookings.map((b, i) => (
          <View key={i} style={styles.card}>
            <Text style={styles.cardTitle}>{b.title || 'Booking'}</Text>
            <Text style={styles.cardMeta}>{b.status || 'pending'}</Text>
          </View>
        ))
      )}
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  empty: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
    paddingHorizontal: 32,
  },
  emptyIcon: { fontSize: 48, marginBottom: 16 },
  emptyTitle: { color: colors.text, fontSize: 18, fontWeight: '700', marginBottom: 8 },
  emptyDesc: { color: colors.textMuted, fontSize: 14, textAlign: 'center', lineHeight: 20 },
  card: {
    backgroundColor: colors.card,
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  cardTitle: { color: colors.text, fontSize: 16, fontWeight: '600' },
  cardMeta: { color: colors.textMuted, fontSize: 13, marginTop: 4 },
});
