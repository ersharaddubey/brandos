import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { colors } from '../theme/colors';
import { companions as staticCompanions, companionCategories, packages as staticPackages } from '../data/experiences';
import { fetchCompanions, fetchPackages } from '../api';

interface Props {
  onNavigate: (screen: string, params?: any) => void;
}

export default function CompanionsScreen({ onNavigate }: Props) {
  const [filter, setFilter] = useState<'All' | 'Online'>('All');
  const [companions, setCompanions] = useState(staticCompanions);
  const [packages, setPackages] = useState(staticPackages);

  useEffect(() => {
    (async () => {
      const [c, p] = await Promise.all([fetchCompanions(), fetchPackages()]);
      if (c && c.length) setCompanions(c);
      if (p && p.length) setPackages(p);
    })();
  }, []);

  const list =
    filter === 'Online' ? companions.filter((c: any) => c.online) : companions;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.label}>COMPANIONS</Text>
        <Text style={styles.title}>Find your perfect{'\n'}platonic companion</Text>
        <Text style={styles.desc}>
          Verified, safe, strictly non-physical. From coffee chats to event partners.
        </Text>
      </View>

      {/* Categories */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.catScroll}
        contentContainerStyle={styles.catContent}
      >
        {companionCategories.map((cat) => (
          <TouchableOpacity key={cat.key} style={styles.catChip} activeOpacity={0.8}>
            <Text style={styles.catIcon}>{cat.icon}</Text>
            <Text style={styles.catLabel}>{cat.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Filter */}
      <View style={styles.filterRow}>
        {(['All', 'Online'] as const).map((f) => (
          <TouchableOpacity
            key={f}
            style={[styles.filterBtn, filter === f && styles.filterBtnActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
              {f}
            </Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity
          style={styles.bookCta}
          onPress={() => onNavigate('Booking')}
          activeOpacity={0.85}
        >
          <Text style={styles.bookCtaText}>⚡ Instant Book</Text>
        </TouchableOpacity>
      </View>

      {/* Companion cards */}
      <View style={styles.list}>
        {list.map((c) => (
          <TouchableOpacity
            key={c.id}
            style={styles.card}
            activeOpacity={0.85}
            onPress={() => onNavigate('CompanionDetail', { companion: c })}
          >
            <View style={styles.cardTop}>
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>{c.icon}</Text>
              </View>
              <View style={styles.cardInfo}>
                <View style={styles.nameRow}>
                  <Text style={styles.name}>{c.name}</Text>
                  {c.online && <View style={styles.onlineDot} />}
                </View>
                <Text style={styles.role}>{c.role}</Text>
                <View style={styles.tags}>
                  {c.tags.slice(0, 3).map((t) => (
                    <View key={t} style={styles.tag}>
                      <Text style={styles.tagText}>{t}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>
            <View style={styles.cardBottom}>
              <Text style={styles.rating}>⭐ {c.rating.toFixed(1)}{c.verified ? ' · 🪪' : ''}{c.city ? ` · ${c.city}` : ''}</Text>
              <Text style={styles.rate}>₹{c.rate}/hr</Text>
              <TouchableOpacity
                style={styles.bookBtn}
                onPress={() => onNavigate('Booking', { companion: c })}
              >
                <Text style={styles.bookBtnText}>Book</Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      {/* Packages preview — Virtual + In-Person + Event */}
      <View style={styles.section}>
        <Text style={styles.sectionLabel}>PACKAGES</Text>
        <Text style={styles.sectionTitle}>Virtual · In-person · Event</Text>
        <Text style={{ color: colors.textSecondary, fontSize: 13, marginBottom: 12, paddingHorizontal: 4 }}>
          From ₹99/hr virtual to event +1 packages. ID verified · Platonic · Easy cancel.
        </Text>
        {packages.map((p) => (
          <View key={p.id} style={[styles.pkgCard, p.popular && styles.pkgPopular]}>
            {p.popular && <Text style={styles.popularBadge}>Most Popular</Text>}
            <Text style={{ color: colors.secondary, fontSize: 10, fontWeight: '700', letterSpacing: 1, marginBottom: 4 }}>
              {p.category.toUpperCase()}
            </Text>
            <View style={styles.pkgRow}>
              <Text style={styles.pkgTitle}>{p.title}</Text>
              <Text style={styles.pkgPrice}>₹{p.price.toLocaleString()}</Text>
            </View>
            <Text style={styles.pkgUnit}>{p.unit}</Text>
            {p.features.map((f, i) => (
              <Text key={i} style={styles.pkgFeature}>• {f}</Text>
            ))}
            <TouchableOpacity
              style={styles.pkgBtn}
              onPress={() => onNavigate('Booking', { package: p, activityPref: p.category === 'Virtual' ? `Virtual (${p.title})` : p.title })}
            >
              <Text style={styles.pkgBtnText}>Book Now</Text>
            </TouchableOpacity>
          </View>
        ))}
      </View>

      <View style={{ height: 28 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 24, paddingTop: 20, paddingBottom: 8 },
  label: {
    color: colors.secondary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.6,
    marginBottom: 8,
  },
  title: {
    color: colors.text,
    fontSize: 26,
    fontWeight: '800',
    lineHeight: 32,
    marginBottom: 8,
  },
  desc: { color: colors.textSecondary, fontSize: 14, lineHeight: 21 },
  catScroll: { marginTop: 16 },
  catContent: { paddingHorizontal: 20, gap: 10 },
  catChip: {
    backgroundColor: colors.glass,
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
    marginRight: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    alignItems: 'center',
    minWidth: 100,
  },
  catIcon: { fontSize: 22, marginBottom: 6 },
  catLabel: { color: colors.textSecondary, fontSize: 11, fontWeight: '600', textAlign: 'center' },
  filterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginTop: 18,
    marginBottom: 8,
    gap: 8,
  },
  filterBtn: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
    backgroundColor: colors.glass,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  filterBtnActive: {
    backgroundColor: colors.primarySoft,
    borderColor: 'rgba(255,45,155,0.35)',
  },
  filterText: { color: colors.textMuted, fontSize: 13, fontWeight: '600' },
  filterTextActive: { color: colors.primary },
  bookCta: {
    marginLeft: 'auto',
    backgroundColor: colors.primary,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
  },
  bookCtaText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  list: { paddingHorizontal: 20, marginTop: 8 },
  card: {
    backgroundColor: colors.glass,
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  cardTop: { flexDirection: 'row', marginBottom: 12 },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: colors.secondarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  avatarText: { fontSize: 26 },
  cardInfo: { flex: 1 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  name: { color: colors.text, fontSize: 16, fontWeight: '700' },
  onlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.success,
  },
  role: { color: colors.textSecondary, fontSize: 13, marginTop: 2 },
  tags: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 6, gap: 6 },
  tag: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  tagText: { color: colors.textMuted, fontSize: 11 },
  cardBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: colors.cardBorder,
    paddingTop: 12,
  },
  rating: { color: colors.textSecondary, fontSize: 13, marginRight: 12 },
  rate: { color: colors.accent, fontSize: 15, fontWeight: '800', flex: 1 },
  bookBtn: {
    backgroundColor: colors.primary,
    paddingVertical: 8,
    paddingHorizontal: 18,
    borderRadius: 12,
  },
  bookBtnText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  section: { paddingHorizontal: 20, paddingTop: 28 },
  sectionLabel: {
    color: colors.secondary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.6,
    marginBottom: 8,
  },
  sectionTitle: {
    color: colors.text,
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 14,
  },
  pkgCard: {
    backgroundColor: colors.glass,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  pkgPopular: {
    borderColor: 'rgba(255,45,155,0.4)',
    backgroundColor: colors.primarySoft,
  },
  popularBadge: {
    color: colors.primary,
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 6,
  },
  pkgRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  pkgTitle: { color: colors.text, fontSize: 17, fontWeight: '700' },
  pkgPrice: { color: colors.accent, fontSize: 18, fontWeight: '800' },
  pkgUnit: { color: colors.textMuted, fontSize: 12, marginBottom: 8 },
  pkgFeature: { color: colors.textSecondary, fontSize: 13, marginBottom: 3 },
  pkgBtn: {
    marginTop: 12,
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 10,
    alignItems: 'center',
  },
  pkgBtnText: { color: '#fff', fontSize: 14, fontWeight: '700' },
});
