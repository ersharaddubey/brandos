import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import { createBooking } from '../api';
import {
  companionCategories,
  activities,
  durations,
  Companion,
  virtualModes,
  activityPackages,
  companionRoles,
  packages,
  subscriptions,
  trustBadges,
} from '../data/experiences';

interface Props {
  onBack: () => void;
  companion?: Companion | null;
  initialPackage?: { price: number; title: string } | null;
  lookingForPref?: string;
  activityPref?: string;
  featureLabel?: string;
  featureIcon?: string;
}

const PLATFORM_FEE = 99;

export default function BookingScreen({
  onBack,
  companion,
  lookingForPref,
  activityPref,
  featureLabel,
  featureIcon,
}: Props) {
  const { colors } = useTheme();
  const [mode, setMode] = useState<'inperson' | 'virtual' | 'activity' | 'sub'>(
    activityPref?.toLowerCase().includes('virtual') ? 'virtual' : 'inperson'
  );
  const [lookingFor, setLookingFor] = useState(
    lookingForPref || companion?.role || companionCategories[0].label
  );
  const [activity, setActivity] = useState(activityPref || activities[0]);
  const [durationIdx, setDurationIdx] = useState(0);
  const [virtualIdx, setVirtualIdx] = useState(1); // voice default
  const [activityPkgIdx, setActivityPkgIdx] = useState(0);
  const [subIdx, setSubIdx] = useState(1);
  const [roleIdx, setRoleIdx] = useState(0);
  const [mobile, setMobile] = useState('');
  const [showLooking, setShowLooking] = useState(false);
  const [showActivity, setShowActivity] = useState(false);
  const [showDuration, setShowDuration] = useState(false);

  const hours = durations[durationIdx].hours;
  const ratePerHour = companion?.rate || packages.find((p) => p.id === 'p1')?.price || 699;

  const pricing = useMemo(() => {
    if (mode === 'virtual') {
      const v = virtualModes[virtualIdx];
      return { label: v.label, subtotal: v.price * Math.max(hours, 1), unit: v.unit };
    }
    if (mode === 'activity') {
      const a = activityPackages[activityPkgIdx];
      return { label: a.title, subtotal: a.price, unit: a.duration };
    }
    if (mode === 'sub') {
      const s = subscriptions[subIdx];
      return { label: s.title, subtotal: s.price, unit: s.unit };
    }
    return {
      label: durations[durationIdx].label,
      subtotal: ratePerHour * hours,
      unit: `${hours} hr`,
    };
  }, [mode, virtualIdx, activityPkgIdx, subIdx, durationIdx, ratePerHour, hours]);

  const total = pricing.subtotal + (mode === 'sub' ? 0 : PLATFORM_FEE);

  const lookingOptions = useMemo(
    () => companionCategories.map((c) => c.label),
    []
  );

  const confirm = async () => {
    if (mobile.replace(/\D/g, '').length < 10) {
      Alert.alert('Mobile required', 'Enter a valid 10-digit WhatsApp number.');
      return;
    }
    const summaryActivity =
      mode === 'virtual'
        ? `Virtual · ${virtualModes[virtualIdx].label}`
        : mode === 'activity'
          ? activityPackages[activityPkgIdx].title
          : mode === 'sub'
            ? subscriptions[subIdx].title
            : activity;

    await createBooking({
      lookingFor,
      activity: summaryActivity,
      duration: mode === 'activity' || mode === 'sub' ? pricing.unit : durations[durationIdx].label,
      mobile,
      total,
      companionId: companion?.id,
      companionName: companion?.name,
      feature: featureLabel || companionRoles[roleIdx]?.label,
    });
    Alert.alert(
      'Booking request sent',
      `We'll confirm on WhatsApp (${mobile}).\n\n${featureLabel ? featureLabel + '\n' : ''}${lookingFor} · ${summaryActivity}\nTotal: ₹${total.toLocaleString()}\n\nTrust: ID verified · Platonic · Public meets · Easy cancel`,
      [{ text: 'OK', onPress: onBack }]
    );
  };

  const modes = [
    { key: 'inperson' as const, label: 'In-Person', icon: '🤝' },
    { key: 'virtual' as const, label: 'Virtual', icon: '📱' },
    { key: 'activity' as const, label: 'Activity Pack', icon: '✨' },
    { key: 'sub' as const, label: 'Weekly / Monthly', icon: '🔁' },
  ];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <Text style={[styles.label, { color: colors.secondary }]}>BOOKING</Text>
        <Text style={[styles.title, { color: colors.text }]}>
          {featureIcon ? `${featureIcon} ` : ''}
          {featureLabel || 'Book a companion'}
        </Text>
        <Text style={[styles.desc, { color: colors.textMuted }]}>
          Verified · Platonic · Public venues · WhatsApp confirm
        </Text>
      </View>

      {/* Trust strip */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.trustScroll}>
        {trustBadges.map((b) => (
          <View key={b.label} style={[styles.trustChip, { borderColor: colors.cardBorder, backgroundColor: colors.glass }]}>
            <Text style={styles.trustIcon}>{b.icon}</Text>
            <Text style={[styles.trustLabel, { color: colors.textSecondary }]}>{b.label}</Text>
          </View>
        ))}
      </ScrollView>

      {companion && (
        <View style={[styles.companionBanner, { borderColor: colors.cardBorder, backgroundColor: colors.glass }]}>
          <Text style={styles.bannerIcon}>{companion.icon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={[styles.bannerName, { color: colors.text }]}>{companion.name}</Text>
            <Text style={[styles.bannerRole, { color: colors.textMuted }]}>
              {companion.role} · ₹{companion.rate}/hr
              {companion.verified ? ' · 🪪 Verified' : ''}
            </Text>
          </View>
        </View>
      )}

      {/* Mode tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.modeRow}>
        {modes.map((m) => (
          <TouchableOpacity
            key={m.key}
            onPress={() => setMode(m.key)}
            style={[
              styles.modeChip,
              {
                backgroundColor: mode === m.key ? colors.primary : colors.glass,
                borderColor: mode === m.key ? colors.primary : colors.cardBorder,
              },
            ]}
          >
            <Text style={styles.modeIcon}>{m.icon}</Text>
            <Text style={{ color: mode === m.key ? '#fff' : colors.text, fontWeight: '700', fontSize: 12 }}>
              {m.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.form}>
        {/* Role */}
        <Text style={[styles.fieldLabel, { color: colors.secondary }]}>ROLE</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {companionRoles.map((r, i) => (
            <TouchableOpacity
              key={r.key}
              onPress={() => {
                setRoleIdx(i);
                setLookingFor(r.label);
              }}
              style={[
                styles.roleChip,
                {
                  borderColor: roleIdx === i ? colors.primary : colors.cardBorder,
                  backgroundColor: roleIdx === i ? colors.primary + '22' : colors.glass,
                },
              ]}
            >
              <Text style={{ fontSize: 16 }}>{r.icon}</Text>
              <Text style={{ color: colors.text, fontWeight: '700', fontSize: 12 }}>{r.label}</Text>
              <Text style={{ color: colors.textMuted, fontSize: 10 }}>from ₹{r.from}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {mode === 'virtual' && (
          <>
            <Text style={[styles.fieldLabel, { color: colors.secondary }]}>VIRTUAL MODE</Text>
            <View style={styles.virtualGrid}>
              {virtualModes.map((v, i) => (
                <TouchableOpacity
                  key={v.key}
                  onPress={() => setVirtualIdx(i)}
                  style={[
                    styles.virtualCard,
                    {
                      borderColor: virtualIdx === i ? colors.primary : colors.cardBorder,
                      backgroundColor: virtualIdx === i ? colors.primary + '22' : colors.glass,
                    },
                  ]}
                >
                  <Text style={{ fontSize: 24 }}>{v.icon}</Text>
                  <Text style={{ color: colors.text, fontWeight: '800', marginTop: 4 }}>{v.label}</Text>
                  <Text style={{ color: colors.accent, fontWeight: '800' }}>₹{v.price}{v.unit}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}

        {mode === 'activity' && (
          <>
            <Text style={[styles.fieldLabel, { color: colors.secondary }]}>ACTIVITY PACKAGE</Text>
            {activityPackages.map((a, i) => (
              <TouchableOpacity
                key={a.id}
                onPress={() => setActivityPkgIdx(i)}
                style={[
                  styles.pkgRow,
                  {
                    borderColor: activityPkgIdx === i ? colors.primary : colors.cardBorder,
                    backgroundColor: activityPkgIdx === i ? colors.primary + '18' : colors.glass,
                  },
                ]}
              >
                <Text style={{ fontSize: 22 }}>{a.icon}</Text>
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={{ color: colors.text, fontWeight: '800' }}>{a.title}</Text>
                  <Text style={{ color: colors.textMuted, fontSize: 12 }}>{a.desc} · {a.duration}</Text>
                </View>
                <Text style={{ color: colors.accent, fontWeight: '800' }}>₹{a.price}</Text>
              </TouchableOpacity>
            ))}
          </>
        )}

        {mode === 'sub' && (
          <>
            <Text style={[styles.fieldLabel, { color: colors.secondary }]}>SUBSCRIPTION</Text>
            {subscriptions.map((s, i) => (
              <TouchableOpacity
                key={s.id}
                onPress={() => setSubIdx(i)}
                style={[
                  styles.pkgRow,
                  {
                    borderColor: subIdx === i ? colors.primary : colors.cardBorder,
                    backgroundColor: subIdx === i ? colors.primary + '18' : colors.glass,
                  },
                ]}
              >
                <View style={{ flex: 1 }}>
                  <Text style={{ color: colors.text, fontWeight: '800' }}>
                    {s.title} {s.popular ? '· Popular' : ''}
                  </Text>
                  <Text style={{ color: colors.textMuted, fontSize: 12 }}>
                    {s.sessions} sessions · {s.save}
                  </Text>
                  {s.features.map((f) => (
                    <Text key={f} style={{ color: colors.textSecondary, fontSize: 11 }}>• {f}</Text>
                  ))}
                </View>
                <Text style={{ color: colors.accent, fontWeight: '800' }}>
                  ₹{s.price}{s.unit}
                </Text>
              </TouchableOpacity>
            ))}
          </>
        )}

        {mode === 'inperson' && (
          <>
            <Text style={[styles.fieldLabel, { color: colors.secondary }]}>LOOKING FOR</Text>
            <TouchableOpacity
              style={[styles.select, { borderColor: colors.cardBorder, backgroundColor: colors.glass }]}
              onPress={() => setShowLooking(!showLooking)}
            >
              <Text style={[styles.selectText, { color: colors.text }]}>{lookingFor}</Text>
              <Text style={{ color: colors.textMuted }}>▼</Text>
            </TouchableOpacity>
            {showLooking &&
              lookingOptions.map((opt) => (
                <TouchableOpacity
                  key={opt}
                  style={[styles.option, { borderBottomColor: colors.cardBorder }]}
                  onPress={() => {
                    setLookingFor(opt);
                    setShowLooking(false);
                  }}
                >
                  <Text style={{ color: colors.text }}>{opt}</Text>
                </TouchableOpacity>
              ))}

            <Text style={[styles.fieldLabel, { color: colors.secondary }]}>ACTIVITY</Text>
            <TouchableOpacity
              style={[styles.select, { borderColor: colors.cardBorder, backgroundColor: colors.glass }]}
              onPress={() => setShowActivity(!showActivity)}
            >
              <Text style={[styles.selectText, { color: colors.text }]}>{activity}</Text>
              <Text style={{ color: colors.textMuted }}>▼</Text>
            </TouchableOpacity>
            {showActivity &&
              activities.map((opt) => (
                <TouchableOpacity
                  key={opt}
                  style={[styles.option, { borderBottomColor: colors.cardBorder }]}
                  onPress={() => {
                    setActivity(opt);
                    setShowActivity(false);
                  }}
                >
                  <Text style={{ color: colors.text }}>{opt}</Text>
                </TouchableOpacity>
              ))}
          </>
        )}

        {(mode === 'inperson' || mode === 'virtual') && (
          <>
            <Text style={[styles.fieldLabel, { color: colors.secondary }]}>DURATION</Text>
            <TouchableOpacity
              style={[styles.select, { borderColor: colors.cardBorder, backgroundColor: colors.glass }]}
              onPress={() => setShowDuration(!showDuration)}
            >
              <Text style={[styles.selectText, { color: colors.text }]}>
                {durations[durationIdx].label}
              </Text>
              <Text style={{ color: colors.textMuted }}>▼</Text>
            </TouchableOpacity>
            {showDuration &&
              durations.map((d, i) => (
                <TouchableOpacity
                  key={d.label}
                  style={[styles.option, { borderBottomColor: colors.cardBorder }]}
                  onPress={() => {
                    setDurationIdx(i);
                    setShowDuration(false);
                  }}
                >
                  <Text style={{ color: colors.text }}>{d.label}</Text>
                </TouchableOpacity>
              ))}
          </>
        )}

        <Text style={[styles.fieldLabel, { color: colors.secondary }]}>WHATSAPP NUMBER</Text>
        <TextInput
          style={[styles.input, { borderColor: colors.cardBorder, color: colors.text, backgroundColor: colors.glass }]}
          placeholder="10-digit mobile"
          placeholderTextColor={colors.textMuted}
          keyboardType="phone-pad"
          value={mobile}
          onChangeText={setMobile}
          maxLength={10}
        />

        <View style={[styles.totalBox, { borderColor: colors.cardBorder, backgroundColor: colors.glass }]}>
          <View style={styles.totalRow}>
            <Text style={{ color: colors.textMuted }}>{pricing.label}</Text>
            <Text style={{ color: colors.text }}>₹{pricing.subtotal.toLocaleString()}</Text>
          </View>
          {mode !== 'sub' && (
            <View style={styles.totalRow}>
              <Text style={{ color: colors.textMuted }}>Platform fee</Text>
              <Text style={{ color: colors.text }}>₹{PLATFORM_FEE}</Text>
            </View>
          )}
          <View style={[styles.totalRow, { marginTop: 8 }]}>
            <Text style={[styles.totalLabel, { color: colors.text }]}>Total</Text>
            <Text style={[styles.totalValue, { color: colors.primary }]}>
              ₹{total.toLocaleString()}
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={[styles.confirmBtn, { backgroundColor: colors.primary }]}
          onPress={confirm}
          activeOpacity={0.85}
        >
          <Text style={styles.confirmText}>Confirm · WhatsApp us</Text>
        </TouchableOpacity>
        <Text style={{ textAlign: 'center', color: colors.textMuted, fontSize: 11, marginTop: 8 }}>
          Cancel up to 2 hrs before for full refund · 100% platonic
        </Text>
      </View>
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 8 },
  label: { fontSize: 11, fontWeight: '800', letterSpacing: 1.2 },
  title: { fontSize: 22, fontWeight: '800', marginTop: 6 },
  desc: { fontSize: 13, marginTop: 4 },
  trustScroll: { paddingHorizontal: 16, marginBottom: 8 },
  trustChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    marginRight: 8,
  },
  trustIcon: { fontSize: 12 },
  trustLabel: { fontSize: 11, fontWeight: '600' },
  companionBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 16,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    gap: 12,
    marginBottom: 8,
  },
  bannerIcon: { fontSize: 28 },
  bannerName: { fontSize: 16, fontWeight: '800' },
  bannerRole: { fontSize: 12, marginTop: 2 },
  modeRow: { paddingHorizontal: 16, gap: 8, paddingVertical: 8 },
  modeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: 1,
    marginRight: 8,
  },
  modeIcon: { fontSize: 14 },
  form: { padding: 16 },
  fieldLabel: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1,
    marginTop: 14,
    marginBottom: 8,
  },
  select: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  selectText: { fontSize: 15, fontWeight: '600' },
  option: {
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderBottomWidth: 1,
  },
  input: {
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 14,
    fontSize: 15,
  },
  roleChip: {
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginRight: 8,
    alignItems: 'center',
    minWidth: 100,
  },
  virtualGrid: { flexDirection: 'row', gap: 10 },
  virtualCard: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 14,
    padding: 12,
    alignItems: 'center',
  },
  pkgRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 14,
    padding: 12,
    marginBottom: 8,
  },
  totalBox: {
    marginTop: 20,
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  totalLabel: { fontSize: 16, fontWeight: '800' },
  totalValue: { fontSize: 18, fontWeight: '800' },
  confirmBtn: {
    marginTop: 20,
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
  },
  confirmText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
