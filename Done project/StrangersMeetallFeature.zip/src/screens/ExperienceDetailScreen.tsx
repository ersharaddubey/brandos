import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { colors } from '../theme/colors';
import { Experience } from '../data/experiences';

interface Props {
  experience: Experience;
  onBack: () => void;
  onNavigate?: (screen: string, params?: any) => void;
}

export default function ExperienceDetailScreen({ experience, onBack, onNavigate }: Props) {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.hero}>
        <Text style={styles.icon}>{experience.icon}</Text>
        <Text style={[styles.title, { color: experience.color }]}>{experience.title}</Text>
        <Text style={styles.subtitle}>{experience.subtitle}</Text>
      </View>

      <View style={styles.content}>
        <Text style={styles.sectionLabel}>ABOUT</Text>
        <Text style={styles.desc}>{experience.description}</Text>

        <Text style={styles.sectionLabel}>WHAT TO EXPECT</Text>
        {[
          'Meet verified strangers who share your vibe',
          'Safe and curated experience',
          'Equal Date™ – split costs fairly',
          'Create unforgettable memories',
          '24/7 support from our team',
        ].map((item, i) => (
          <View key={i} style={styles.listItem}>
            <Text style={styles.bullet}>✓</Text>
            <Text style={styles.listText}>{item}</Text>
          </View>
        ))}

        <Text style={styles.sectionLabel}>HOW IT WORKS</Text>
        {[
          'Choose this experience',
          'Pick your preferred date & time',
          'Get matched with like-minded people',
          'Show up and enjoy!',
        ].map((item, i) => (
          <View key={i} style={styles.stepRow}>
            <View style={[styles.stepCircle, { backgroundColor: experience.color }]}>
              <Text style={styles.stepNum}>{i + 1}</Text>
            </View>
            <Text style={styles.stepText}>{item}</Text>
          </View>
        ))}

        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: experience.color }]}
          activeOpacity={0.8}
          onPress={() =>
            onNavigate?.('Booking', {
              activity: experience.title.includes('Movie')
                ? 'Movie / Concert'
                : experience.title.includes('Cafe')
                ? 'Coffee / Cafe'
                : experience.title.includes('Drive') || experience.title.includes('Road')
                ? 'Travel / Day trip'
                : 'Social Event',
              featureLabel: experience.title,
              featureIcon: experience.icon,
              lookingFor: 'Rent a Girlfriend',
            })
          }
        >
          <Text style={styles.bookText}>Book This Experience</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.backBtn} onPress={onBack}>
          <Text style={styles.backText}>← Back to Experiences</Text>
        </TouchableOpacity>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  hero: {
    alignItems: 'center',
    padding: 30,
    paddingTop: 20,
  },
  icon: {
    fontSize: 64,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 16,
    marginTop: 4,
  },
  content: {
    padding: 20,
  },
  sectionLabel: {
    color: colors.secondary,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.5,
    marginBottom: 10,
    marginTop: 16,
  },
  desc: {
    color: colors.textSecondary,
    fontSize: 15,
    lineHeight: 22,
  },
  listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  bullet: {
    color: colors.success,
    fontSize: 16,
    marginRight: 10,
    fontWeight: '700',
  },
  listText: {
    color: colors.textSecondary,
    fontSize: 14,
    flex: 1,
  },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  stepCircle: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  stepNum: {
    color: colors.text,
    fontSize: 13,
    fontWeight: '800',
  },
  stepText: {
    color: colors.textSecondary,
    fontSize: 14,
  },
  bookBtn: {
    borderRadius: 30,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 30,
  },
  bookText: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
  },
  backBtn: {
    alignItems: 'center',
    marginTop: 16,
    padding: 10,
  },
  backText: {
    color: colors.primary,
    fontSize: 14,
    fontWeight: '600',
  },
});
