import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  onBack: () => void;
}

export default function AboutScreen({ onBack }: Props) {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.card}>
        <Text style={styles.logo}>♥</Text>
        <Text style={styles.brand}>STRANGERS MEET</Text>
        <Text style={styles.tagline}>More than Dating. More than Networking.</Text>
        <View style={styles.divider} />
        <Text style={styles.body}>
          StrangersMeet helps you discover experiences, companions, and free meetups in your city.
          Connect with new people over shared interests and real-world activities.
        </Text>
        <Text style={styles.version}>Version 1.0.0</Text>
        <Text style={styles.copy}>© 2026 StrangersMeet. All rights reserved.</Text>
      </View>
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  card: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  logo: { fontSize: 40, color: colors.accent, marginBottom: 8 },
  brand: { color: colors.text, fontSize: 18, fontWeight: '800', letterSpacing: 1 },
  tagline: { color: colors.textMuted, fontSize: 13, marginTop: 6, textAlign: 'center' },
  divider: {
    height: 1,
    backgroundColor: colors.cardBorder,
    alignSelf: 'stretch',
    marginVertical: 20,
  },
  body: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 22,
    textAlign: 'center',
  },
  version: { color: colors.primary, fontSize: 14, fontWeight: '600', marginTop: 24 },
  copy: { color: colors.textMuted, fontSize: 12, marginTop: 8 },
});
