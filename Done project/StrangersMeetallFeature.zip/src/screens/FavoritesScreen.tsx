import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  onBack: () => void;
}

export default function FavoritesScreen({ onBack }: Props) {
  const favorites: any[] = [];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {favorites.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyIcon}>❤️</Text>
          <Text style={styles.emptyTitle}>No favorites yet</Text>
          <Text style={styles.emptyDesc}>
            Save experiences and companions you love. They will show up here.
          </Text>
        </View>
      ) : (
        favorites.map((f, i) => (
          <View key={i} style={styles.card}>
            <Text style={styles.cardTitle}>{f.title || 'Favorite'}</Text>
          </View>
        ))
      )}
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  empty: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
    paddingHorizontal: 32,
  },
  emptyIcon: { fontSize: 48, marginBottom: 16 },
  emptyTitle: { color: colors.text, fontSize: 18, fontWeight: '700', marginBottom: 8 },
  emptyDesc: { color: colors.textMuted, fontSize: 14, textAlign: 'center', lineHeight: 20 },
  card: {
    backgroundColor: colors.card,
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  cardTitle: { color: colors.text, fontSize: 16, fontWeight: '600' },
});
