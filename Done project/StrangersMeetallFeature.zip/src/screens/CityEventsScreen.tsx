import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import {
  cityEvents,
  eventCategories,
  eventCities,
  cityAppFeatures,
} from '../data/cityEvents';

const { width } = Dimensions.get('window');
const CARD_W = (width - 16 * 2 - 10) / 2;

interface Props {
  onBack: () => void;
  onNavigate: (screen: string, params?: any) => void;
  initialCity?: string;
}

/**
 * Flow: Events → pick CITY → inside city: all event types + app features + listings
 * Does NOT open Cities tab.
 */
export default function CityEventsScreen({ onNavigate, initialCity }: Props) {
  const { colors } = useTheme();
  const [city, setCity] = useState<string | null>(initialCity || null);
  const [cat, setCat] = useState<string | null>(null);

  const listings = useMemo(() => {
    if (!city) return [];
    return cityEvents.filter(
      (e) => e.active && e.city === city && (!cat || e.category === cat)
    );
  }, [city, cat]);

  const featuresForCity = useMemo(() => {
    if (!cat) return cityAppFeatures;
    return cityAppFeatures.filter((f) => f.category === cat || f.category === 'Meet');
  }, [cat]);

  // ── Step 1: city picker ──────────────────────────────────
  if (!city) {
    return (
      <ScrollView
        style={[styles.container, { backgroundColor: colors.background }]}
        contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
      >
        <Text style={[styles.heading, { color: colors.text }]}>Events</Text>
        <Text style={[styles.sub, { color: colors.textMuted }]}>
          Pehle city choose karo · phir uske andar saari categories & features
        </Text>

        <Text style={[styles.section, { color: colors.textMuted }]}>SELECT CITY</Text>
        <View style={styles.cityGrid}>
          {eventCities.map((c) => (
            <TouchableOpacity
              key={c}
              style={[
                styles.cityCard,
                { backgroundColor: colors.surface, borderColor: colors.border },
              ]}
              activeOpacity={0.85}
              onPress={() => {
                setCity(c);
                setCat(null);
              }}
            >
              <Text style={styles.cityIcon}>📍</Text>
              <Text style={[styles.cityName, { color: colors.text }]}>{c}</Text>
              <Text style={{ color: colors.textMuted, fontSize: 10, marginTop: 2 }}>
                {eventCategories.length} categories
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    );
  }

  // ── Step 2: inside city ──────────────────────────────────
  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: 48 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.topBar}>
        <TouchableOpacity
          onPress={() => setCity(null)}
          style={[styles.changeCity, { backgroundColor: colors.primarySoft }]}
        >
          <Text style={{ color: colors.primary, fontWeight: '700', fontSize: 13 }}>
            ← Change city
          </Text>
        </TouchableOpacity>
        <Text style={[styles.cityTitle, { color: colors.text }]}>{city}</Text>
        <Text style={[styles.sub, { color: colors.textMuted, marginHorizontal: 16 }]}>
          Saari event types + app features isi city ke andar
        </Text>
      </View>

      {/* Event type categories */}
      <Text style={[styles.section, { color: colors.textMuted }]}>EVENT TYPES</Text>
      <View style={styles.catGrid}>
        <TouchableOpacity
          style={[
            styles.catChip,
            { backgroundColor: colors.surface, borderColor: colors.border },
            !cat && { backgroundColor: colors.primarySoft, borderColor: colors.primary },
          ]}
          onPress={() => setCat(null)}
        >
          <Text style={{ fontSize: 16 }}>✨</Text>
          <Text
            style={[
              styles.catChipText,
              { color: !cat ? colors.primary : colors.textSecondary },
            ]}
          >
            All
          </Text>
        </TouchableOpacity>
        {eventCategories.map((c) => (
          <TouchableOpacity
            key={c.key}
            style={[
              styles.catChip,
              { backgroundColor: colors.surface, borderColor: colors.border },
              cat === c.key && {
                backgroundColor: colors.primarySoft,
                borderColor: colors.primary,
              },
            ]}
            onPress={() => setCat(c.key)}
          >
            <Text style={{ fontSize: 16 }}>{c.icon}</Text>
            <Text
              style={[
                styles.catChipText,
                { color: cat === c.key ? colors.primary : colors.textSecondary },
              ]}
              numberOfLines={1}
            >
              {c.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* App features inside this city */}
      <Text style={[styles.section, { color: colors.textMuted }]}>
        MEET FEATURES IN {city.toUpperCase()}
      </Text>
      <View style={styles.featureGrid}>
        {featuresForCity.map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[
              styles.featureCard,
              { backgroundColor: colors.surface, borderColor: colors.border },
            ]}
            activeOpacity={0.85}
            onPress={() =>
              onNavigate('FeatureDetail', { featureKey: f.key, city })
            }
          >
            <Text style={{ fontSize: 22 }}>{f.icon}</Text>
            <Text style={[styles.featureLabel, { color: colors.text }]} numberOfLines={1}>
              {f.label}
            </Text>
            <Text style={{ color: colors.textMuted, fontSize: 10 }}>{f.category}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Listings */}
      <Text style={[styles.section, { color: colors.textMuted }]}>
        UPCOMING IN {city.toUpperCase()}
        {cat ? ` · ${cat}` : ''}
      </Text>
      {listings.length === 0 ? (
        <View style={styles.empty}>
          <Text style={{ fontSize: 36 }}>📭</Text>
          <Text style={[styles.emptyTitle, { color: colors.text }]}>No listings</Text>
          <Text style={{ color: colors.textMuted, textAlign: 'center', paddingHorizontal: 24 }}>
            Is category me abhi sample event nahi — feature se book kar sakte ho
          </Text>
        </View>
      ) : (
        listings.map((e) => (
          <TouchableOpacity
            key={e.id}
            style={[
              styles.listCard,
              { backgroundColor: colors.card, borderColor: colors.cardBorder },
            ]}
            activeOpacity={0.85}
            onPress={() =>
              onNavigate('Booking', {
                activity: 'Social Event',
                lookingFor: 'Rent a Girlfriend',
                featureLabel: `${e.title} · ${city}`,
                featureIcon: e.icon,
                eventId: e.id,
              })
            }
          >
            <View style={[styles.iconBox, { backgroundColor: colors.lavender }]}>
              <Text style={{ fontSize: 22 }}>{e.icon}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.listTitle, { color: colors.text }]}>{e.title}</Text>
              <Text style={{ color: colors.textMuted, fontSize: 12, marginTop: 2 }}>
                {e.category} · {e.venue}
              </Text>
              <Text style={{ color: colors.textSecondary, fontSize: 12, marginTop: 4 }}>
                {e.date} · {e.price}
              </Text>
            </View>
            <Text style={{ color: colors.primary, fontWeight: '800', fontSize: 13 }}>Book</Text>
          </TouchableOpacity>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  heading: { fontSize: 24, fontWeight: '800', marginBottom: 4 },
  sub: { fontSize: 13, marginBottom: 8, lineHeight: 18 },
  section: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginTop: 18,
    marginBottom: 10,
    marginHorizontal: 16,
  },
  cityGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  cityCard: {
    width: CARD_W,
    borderRadius: 16,
    borderWidth: 1,
    paddingVertical: 18,
    paddingHorizontal: 12,
    alignItems: 'center',
  },
  cityIcon: { fontSize: 28, marginBottom: 6 },
  cityName: { fontSize: 14, fontWeight: '800', textAlign: 'center' },
  topBar: { paddingTop: 8 },
  changeCity: {
    alignSelf: 'flex-start',
    marginLeft: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    marginBottom: 8,
  },
  cityTitle: {
    fontSize: 22,
    fontWeight: '800',
    marginHorizontal: 16,
  },
  catGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 12,
    gap: 8,
  },
  catChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  catChipText: { fontSize: 11, fontWeight: '700', maxWidth: 90 },
  featureGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 12,
    gap: 8,
  },
  featureCard: {
    width: (width - 24 - 16) / 3,
    borderRadius: 14,
    borderWidth: 1,
    paddingVertical: 12,
    paddingHorizontal: 6,
    alignItems: 'center',
  },
  featureLabel: { fontSize: 11, fontWeight: '700', marginTop: 6, textAlign: 'center' },
  listCard: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 16,
    marginBottom: 10,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    gap: 12,
  },
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  listTitle: { fontSize: 15, fontWeight: '700' },
  empty: { alignItems: 'center', paddingVertical: 32 },
  emptyTitle: { fontSize: 16, fontWeight: '700', marginTop: 8 },
});
