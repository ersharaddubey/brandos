import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  onNavigate: (screen: string, params?: any) => void;
}

export default function FreeMeetupScreen({ onNavigate }: Props) {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.hero}>
        <View style={styles.freeBadge}>
          <Text style={styles.freeBadgeText}>100% FREE EVENT</Text>
        </View>
        <Text style={styles.heroTitle}>NOT JUST A PARTY,</Text>
        <Text style={styles.heroTitlePink}>IT'S AN EXPERIENCE.</Text>
        <Text style={styles.heroSub}>Feel the vibe. Meet the tribe. Make memories. ♥</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>AAO, MILO, VIBE KARO!</Text>
        <Text style={styles.cardDesc}>
          No advance. No pressure. Just pure vibes.
        </Text>
        <View style={styles.slotsRow}>
          <View style={styles.slot}>
            <Text style={styles.slotNum}>50</Text>
            <Text style={styles.slotLabel}>MALE SLOTS</Text>
          </View>
          <View style={styles.slot}>
            <Text style={styles.slotNum}>50</Text>
            <Text style={styles.slotLabel}>FEMALE SLOTS</Text>
          </View>
          <View style={styles.slot}>
            <Text style={styles.slotNum}>100%</Text>
            <Text style={styles.slotLabel}>FREE</Text>
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>FREE PARTY MEIN KYA MILEGA?</Text>
        {[
          'Mast garmagaram party vibes',
          'Dhamakedaar music & crazy energy',
          'StrangersMeet ki puri team se milne ka moka',
          'New people, new connections, new stories',
          'Games, activities & surprises',
          'Food, drinks & great vibes',
        ].map((item, i) => (
          <View key={i} style={styles.listItem}>
            <Text style={styles.bullet}>♥</Text>
            <Text style={styles.listText}>{item}</Text>
          </View>
        ))}
      </View>

      <View style={styles.features}>
        {[
          { icon: '🎵', title: 'INSANE VIBES', desc: 'Music, Dance & Epic Energy' },
          { icon: '👥', title: 'NEW PEOPLE', desc: 'Meet Amazing Like-minded People' },
          { icon: '🎮', title: 'PURE FUN', desc: 'Games, Activities & Surprises' },
          { icon: '🆓', title: 'ZERO COST', desc: '100% Free Forever' },
          { icon: '💖', title: 'REAL CONNECTIONS', desc: 'Genuine bonds that last' },
          { icon: '🛡️', title: 'SAFE & VERIFIED', desc: 'Trusted community' },
        ].map((f, i) => (
          <View key={i} style={styles.featureItem}>
            <Text style={styles.featureIcon}>{f.icon}</Text>
            <Text style={styles.featureTitle}>{f.title}</Text>
            <Text style={styles.featureDesc}>{f.desc}</Text>
          </View>
        ))}
      </View>

      <View style={styles.citiesSection}>
        <Text style={styles.sectionTitle}>Yaha par hote hain apne Free Meetups</Text>
        <Text style={styles.citiesSub}>Real conversations. New people. Better vibes.</Text>
        {['Delhi NCR', 'Ahmedabad', 'Jaipur', 'Surat', 'Pune', 'Mumbai'].map((c, i) => (
          <View key={i} style={styles.cityRow}>
            <Text style={styles.cityName}>{c}</Text>
            <Text style={styles.cityArrow}>Let's meet →</Text>
          </View>
        ))}
      </View>

      <View style={styles.bottomCta}>
        <Text style={styles.bottomTitle}>♥ NO TICKET. NO FEE.</Text>
        <Text style={styles.bottomTitle}>JUST REAL CONNECTIONS.</Text>
        <TouchableOpacity style={styles.ctaBtn} activeOpacity={0.8}>
          <Text style={styles.ctaText}>Register for Free Meetup</Text>
        </TouchableOpacity>
        <Text style={styles.note}>Limited slots • First Come First Serve</Text>
      </View>

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  hero: {
    padding: 20,
    paddingTop: 16,
    alignItems: 'center',
  },
  freeBadge: {
    backgroundColor: colors.success + '33',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 6,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.success,
  },
  freeBadgeText: {
    color: colors.success,
    fontSize: 13,
    fontWeight: '800',
  },
  heroTitle: {
    color: colors.text,
    fontSize: 26,
    fontWeight: '800',
    textAlign: 'center',
  },
  heroTitlePink: {
    color: colors.primary,
    fontSize: 26,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 12,
  },
  heroSub: {
    color: colors.textSecondary,
    fontSize: 15,
    textAlign: 'center',
  },
  card: {
    margin: 16,
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    alignItems: 'center',
  },
  cardTitle: {
    color: colors.primary,
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 8,
  },
  cardDesc: {
    color: colors.textSecondary,
    fontSize: 14,
    marginBottom: 20,
  },
  slotsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },
  slot: {
    alignItems: 'center',
  },
  slotNum: {
    color: colors.accent,
    fontSize: 24,
    fontWeight: '800',
  },
  slotLabel: {
    color: colors.textMuted,
    fontSize: 11,
    marginTop: 4,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: colors.text,
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 16,
  },
  listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  bullet: {
    color: colors.primary,
    fontSize: 14,
    marginRight: 10,
  },
  listText: {
    color: colors.textSecondary,
    fontSize: 15,
    flex: 1,
  },
  features: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 12,
    justifyContent: 'space-between',
  },
  featureItem: {
    width: '48%',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  featureIcon: {
    fontSize: 28,
    marginBottom: 8,
  },
  featureTitle: {
    color: colors.primary,
    fontSize: 12,
    fontWeight: '800',
    marginBottom: 4,
  },
  featureDesc: {
    color: colors.textMuted,
    fontSize: 11,
    textAlign: 'center',
  },
  citiesSection: {
    padding: 20,
  },
  citiesSub: {
    color: colors.textSecondary,
    fontSize: 13,
    marginBottom: 16,
  },
  cityRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: colors.card,
    borderRadius: 10,
    padding: 14,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  cityName: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '600',
  },
  cityArrow: {
    color: colors.primary,
    fontSize: 13,
    fontWeight: '600',
  },
  bottomCta: {
    padding: 24,
    alignItems: 'center',
  },
  bottomTitle: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  ctaBtn: {
    backgroundColor: colors.primary,
    borderRadius: 30,
    paddingVertical: 14,
    paddingHorizontal: 32,
    marginTop: 20,
  },
  ctaText: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
  },
  note: {
    color: colors.textMuted,
    fontSize: 12,
    marginTop: 12,
  },
});
