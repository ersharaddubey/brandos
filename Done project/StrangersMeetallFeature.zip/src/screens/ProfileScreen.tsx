import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  onNavigate: (screen: string, params?: any) => void;
}

export default function ProfileScreen({ onNavigate }: Props) {
  const menuItems = [
    { icon: '👤', title: 'Edit Profile', desc: 'Update your details', screen: 'EditProfile' },
    { icon: '🎫', title: 'My Bookings', desc: 'View upcoming experiences', screen: 'MyBookings' },
    { icon: '❤️', title: 'Favorites', desc: 'Saved experiences', screen: 'Favorites' },
    { icon: '🔔', title: 'Notifications', desc: 'Manage alerts', screen: 'Notifications' },
    { icon: '🛡️', title: 'Privacy & Safety', desc: 'Your data is safe', screen: 'Privacy' },
    { icon: '💬', title: 'Help & Support', desc: '24/7 support available', screen: 'Help' },
    { icon: '📄', title: 'Terms & Conditions', desc: 'Read our policies', screen: 'Terms' },
    { icon: 'ℹ️', title: 'About StrangersMeet', desc: 'Version 1.0.0', screen: 'About' },
  ];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.profileHeader}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>SM</Text>
        </View>
        <Text style={styles.name}>Welcome!</Text>
        <Text style={styles.sub}>Join StrangersMeet to connect & vibe</Text>
        <TouchableOpacity
          style={styles.joinBtn}
          activeOpacity={0.8}
          onPress={() => onNavigate('EditProfile')}
        >
          <Text style={styles.joinText}>Join StrangersMeet</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.statsBox}>
        <View style={styles.statCol}>
          <Text style={styles.statNum}>0</Text>
          <Text style={styles.statLabel}>Experiences</Text>
        </View>
        <View style={styles.divider} />
        <View style={styles.statCol}>
          <Text style={styles.statNum}>0</Text>
          <Text style={styles.statLabel}>Matches</Text>
        </View>
        <View style={styles.divider} />
        <View style={styles.statCol}>
          <Text style={styles.statNum}>0</Text>
          <Text style={styles.statLabel}>Reviews</Text>
        </View>
      </View>

      <View style={styles.menu}>
        {menuItems.map((item, i) => (
          <TouchableOpacity
            key={i}
            style={styles.menuItem}
            activeOpacity={0.7}
            onPress={() => onNavigate(item.screen)}
          >
            <Text style={styles.menuIcon}>{item.icon}</Text>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>{item.title}</Text>
              <Text style={styles.menuDesc}>{item.desc}</Text>
            </View>
            <Text style={styles.menuArrow}>›</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerLogo}>♥ STRANGERS MEET</Text>
        <Text style={styles.footerText}>More than Dating. More than Networking.</Text>
        <Text style={styles.footerCopy}>© 2026 StrangersMeet. All rights reserved.</Text>
      </View>

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  profileHeader: {
    alignItems: 'center',
    padding: 24,
    paddingTop: 20,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  avatarText: {
    color: colors.text,
    fontSize: 28,
    fontWeight: '800',
  },
  name: {
    color: colors.text,
    fontSize: 22,
    fontWeight: '700',
  },
  sub: {
    color: colors.textSecondary,
    fontSize: 14,
    marginTop: 4,
    marginBottom: 16,
  },
  joinBtn: {
    backgroundColor: colors.primary,
    borderRadius: 30,
    paddingVertical: 12,
    paddingHorizontal: 28,
  },
  joinText: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '700',
  },
  statsBox: {
    flexDirection: 'row',
    marginHorizontal: 16,
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    marginBottom: 20,
  },
  statCol: {
    flex: 1,
    alignItems: 'center',
  },
  statNum: {
    color: colors.accent,
    fontSize: 22,
    fontWeight: '800',
  },
  statLabel: {
    color: colors.textMuted,
    fontSize: 12,
    marginTop: 4,
  },
  divider: {
    width: 1,
    backgroundColor: colors.cardBorder,
  },
  menu: {
    paddingHorizontal: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 14,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  menuIcon: {
    fontSize: 22,
    marginRight: 12,
  },
  menuContent: {
    flex: 1,
  },
  menuTitle: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '600',
  },
  menuDesc: {
    color: colors.textMuted,
    fontSize: 12,
    marginTop: 2,
  },
  menuArrow: {
    color: colors.textMuted,
    fontSize: 22,
  },
  footer: {
    alignItems: 'center',
    padding: 30,
    marginTop: 10,
  },
  footerLogo: {
    color: colors.accent,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 1,
  },
  footerText: {
    color: colors.textMuted,
    fontSize: 12,
    marginTop: 6,
  },
  footerCopy: {
    color: colors.textMuted,
    fontSize: 11,
    marginTop: 8,
  },
});
