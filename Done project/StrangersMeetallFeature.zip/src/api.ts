/**
 * API client for StrangersMeet backend.
 *
 * Set EXPO_PUBLIC_API_URL when running on a physical device, e.g.:
 *   EXPO_PUBLIC_API_URL=http://192.168.1.20:4000 npx expo start --clear
 *
 * Default: http://localhost:4000 (works for emulator / web / same machine).
 */
const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:4000';

async function getJson<T>(path: string): Promise<T | null> {
  try {
    const r = await fetch(`${API_URL}${path}`);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return (await r.json()) as T;
  } catch {
    return null;
  }
}

export async function fetchSlides() {
  return getJson<any[]>('/api/slides');
}

export async function fetchCompanions() {
  return getJson<any[]>('/api/companions');
}

export async function fetchExperiences() {
  return getJson<any[]>('/api/experiences');
}

export async function fetchCities() {
  return getJson<any[]>('/api/cities');
}

export async function fetchPackages() {
  return getJson<any[]>('/api/packages');
}

export async function createBooking(payload: Record<string, unknown>) {
  try {
    const r = await fetch(`${API_URL}/api/bookings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!r.ok) throw new Error('fail');
    return await r.json();
  } catch {
    return { id: 'local-' + Date.now(), ...payload, status: 'pending', offline: true };
  }
}

export function getApiBaseUrl() {
  return API_URL;
}
