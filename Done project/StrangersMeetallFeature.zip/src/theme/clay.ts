import { ViewStyle } from 'react-native';
import { colors } from './colors';

/** Soft raised clay card */
export const clayRaised: ViewStyle = {
  backgroundColor: colors.surfaceRaised,
  borderRadius: 20,
  borderWidth: 1,
  borderColor: colors.border,
  shadowColor: '#252432',
  shadowOffset: { width: 4, height: 6 },
  shadowOpacity: 0.08,
  shadowRadius: 12,
  elevation: 4,
};

export const claySoft: ViewStyle = {
  backgroundColor: colors.surface,
  borderRadius: 16,
  borderWidth: 1,
  borderColor: colors.border,
  shadowColor: '#252432',
  shadowOffset: { width: 2, height: 4 },
  shadowOpacity: 0.06,
  shadowRadius: 8,
  elevation: 2,
};

export const clayInset: ViewStyle = {
  backgroundColor: colors.backgroundSecondary,
  borderRadius: 14,
  borderWidth: 1,
  borderColor: colors.borderStrong,
};
