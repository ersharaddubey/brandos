export type AppColors = {
  background: string;
  backgroundSecondary: string;
  surface: string;
  surfaceRaised: string;
  lavender: string;
  clayPink: string;
  mint: string;
  peach: string;
  cream: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  textInverse: string;
  primary: string;
  primarySoft: string;
  primaryDark: string;
  accent: string;
  accentSoft: string;
  success: string;
  warning: string;
  danger: string;
  border: string;
  borderStrong: string;
  shadow: string;
  card: string;
  cardBorder: string;
  cardSolid: string;
  glass: string;
  glassStrong: string;
  secondary: string;
  secondarySoft: string;
  pink: string;
  purple: string;
  orange: string;
  overlay: string;
};

export const lightColors: AppColors = {
  background: '#F8F6F2',
  backgroundSecondary: '#F0EDE6',
  surface: '#FFFFFF',
  surfaceRaised: '#FFFEFB',
  lavender: '#E9E3FF',
  clayPink: '#F4DDE3',
  mint: '#DDF3E8',
  peach: '#FFE5D0',
  cream: '#FFF8F0',
  text: '#252432',
  textSecondary: '#5C5A6E',
  textMuted: '#8E8BA0',
  textInverse: '#FFFFFF',
  primary: '#7563E8',
  primarySoft: 'rgba(117, 99, 232, 0.14)',
  primaryDark: '#5B4BC4',
  accent: '#E87A9A',
  accentSoft: 'rgba(232, 122, 154, 0.16)',
  success: '#2F9E6A',
  warning: '#E5A54B',
  danger: '#E25C5C',
  border: 'rgba(37, 36, 50, 0.06)',
  borderStrong: 'rgba(37, 36, 50, 0.1)',
  shadow: 'rgba(37, 36, 50, 0.08)',
  card: '#FFFFFF',
  cardBorder: 'rgba(37, 36, 50, 0.08)',
  cardSolid: '#FFFFFF',
  glass: '#FFFFFF',
  glassStrong: '#FFFEFB',
  secondary: '#7563E8',
  secondarySoft: 'rgba(117, 99, 232, 0.14)',
  pink: '#E87A9A',
  purple: '#7563E8',
  orange: '#E5A54B',
  overlay: 'rgba(37, 36, 50, 0.45)',
};

export const darkColors: AppColors = {
  background: '#12111A',
  backgroundSecondary: '#1A1824',
  surface: '#1E1C28',
  surfaceRaised: '#242230',
  lavender: '#2E2A45',
  clayPink: '#3A2832',
  mint: '#1E332A',
  peach: '#3A3024',
  cream: '#2A2618',
  text: '#F2F0F7',
  textSecondary: '#B8B5C6',
  textMuted: '#8A8799',
  textInverse: '#FFFFFF',
  primary: '#9B8CF0',
  primarySoft: 'rgba(155, 140, 240, 0.18)',
  primaryDark: '#7563E8',
  accent: '#F094B0',
  accentSoft: 'rgba(240, 148, 176, 0.18)',
  success: '#3ECF8E',
  warning: '#E5A54B',
  danger: '#E25C5C',
  border: 'rgba(255, 255, 255, 0.08)',
  borderStrong: 'rgba(255, 255, 255, 0.12)',
  shadow: 'rgba(0, 0, 0, 0.35)',
  card: '#1E1C28',
  cardBorder: 'rgba(255, 255, 255, 0.08)',
  cardSolid: '#1E1C28',
  glass: '#1E1C28',
  glassStrong: '#242230',
  secondary: '#9B8CF0',
  secondarySoft: 'rgba(155, 140, 240, 0.18)',
  pink: '#F094B0',
  purple: '#9B8CF0',
  orange: '#E5A54B',
  overlay: 'rgba(0, 0, 0, 0.6)',
};

/** Default export = light (backward compatible imports) */
export const colors = lightColors;
