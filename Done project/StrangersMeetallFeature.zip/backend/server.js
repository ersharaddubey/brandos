require('dotenv').config(); // loads backend/.env if present

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { randomUUID } = require('crypto');

const app = express();
const PORT = process.env.PORT || 4000;
const DATA = path.join(__dirname, 'data.json');

// ---------- Cloudinary (optional) ----------
let cloudinary = null;
const hasCloudinary =
  process.env.CLOUDINARY_CLOUD_NAME &&
  process.env.CLOUDINARY_API_KEY &&
  process.env.CLOUDINARY_API_SECRET;

if (hasCloudinary) {
  try {
    cloudinary = require('cloudinary').v2;
    cloudinary.config({
      cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
      api_key: process.env.CLOUDINARY_API_KEY,
      api_secret: process.env.CLOUDINARY_API_SECRET,
      secure: true,
    });
  } catch (e) {
    console.warn('Cloudinary package missing — run: npm install cloudinary');
    cloudinary = null;
  }
}

app.use(cors());
app.use(express.json({ limit: '10mb' })); // larger for base64 image upload

function read() {
  return JSON.parse(fs.readFileSync(DATA, 'utf8'));
}
function write(data) {
  fs.writeFileSync(DATA, JSON.stringify(data, null, 2));
}

// Health
app.get('/api/health', (_, res) =>
  res.json({
    ok: true,
    service: 'strangersmeet-api',
    cloudinary: !!cloudinary,
  })
);

// ── Public read APIs (mobile app) ──────────────────────────────────────────
app.get('/api/slides', (_, res) => {
  const d = read();
  res.json((d.slides || []).filter((s) => s.active !== false).sort((a, b) => (a.order || 0) - (b.order || 0)));
});

app.get('/api/companions', (_, res) => {
  const d = read();
  res.json((d.companions || []).filter((c) => c.active !== false));
});

app.get('/api/experiences', (_, res) => {
  const d = read();
  res.json((d.experiences || []).filter((e) => e.active !== false));
});

app.get('/api/cities', (_, res) => {
  const d = read();
  res.json((d.cities || []).filter((c) => c.active !== false));
});

app.get('/api/packages', (_, res) => {
  const d = read();
  res.json((d.packages || []).filter((p) => p.active !== false));
});

// Public: bookings create
app.post('/api/bookings', (req, res) => {
  const d = read();
  const booking = {
    id: randomUUID(),
    ...req.body,
    status: 'pending',
    createdAt: new Date().toISOString(),
  };
  d.bookings = d.bookings || [];
  d.bookings.unshift(booking);
  write(d);
  res.status(201).json(booking);
});

app.get('/api/bookings', (req, res) => {
  const d = read();
  res.json(d.bookings || []);
});

// Admin auth (demo token — replace for production)
app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body || {};
  const d = read();
  const user = (d.users || []).find(
    (u) => u.email === email && u.password === password && u.role === 'admin'
  );
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ token: 'demo-admin-token', name: user.name, email: user.email });
});

function adminAuth(req, res, next) {
  const h = req.headers.authorization || '';
  if (h !== 'Bearer demo-admin-token') return res.status(401).json({ error: 'Unauthorized' });
  next();
}

// ── Cloudinary image upload (admin) ────────────────────────────────────────
// POST /api/admin/upload
// Body: { "image": "data:image/jpeg;base64,...." }  OR  { "image": "https://..." }
// Returns: { url, public_id, width, height }
app.post('/api/admin/upload', adminAuth, async (req, res) => {
  if (!cloudinary) {
    return res.status(503).json({
      error:
        'Cloudinary not configured. Set CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET in backend/.env and run npm install',
    });
  }
  const image = req.body?.image;
  if (!image || typeof image !== 'string') {
    return res.status(400).json({ error: 'Send JSON body: { "image": "<base64 data URL or https URL>" }' });
  }
  try {
    const result = await cloudinary.uploader.upload(image, {
      folder: 'strangersmeet',
      resource_type: 'image',
    });
    res.json({
      url: result.secure_url,
      public_id: result.public_id,
      width: result.width,
      height: result.height,
    });
  } catch (err) {
    console.error('Cloudinary upload failed:', err.message);
    res.status(500).json({ error: err.message || 'Upload failed' });
  }
});

// Admin collection APIs — all data in data.json
const COLLECTIONS = ['slides', 'companions', 'experiences', 'cities', 'packages', 'profiles', 'users'];
function ensureCollections(data) {
  for (const name of [...COLLECTIONS, 'bookings']) {
    if (!Array.isArray(data[name])) data[name] = [];
  }
  return data;
}
function publicUser(user) {
  const { password, ...safe } = user;
  return safe;
}

app.get('/api/admin/stats', adminAuth, (_, res) => {
  const d = ensureCollections(read());
  res.json({
    slides: d.slides.length,
    companions: d.companions.length,
    experiences: d.experiences.length,
    cities: d.cities.length,
    packages: d.packages.length,
    bookings: d.bookings.length,
    pending: d.bookings.filter((b) => b.status === 'pending').length,
    profiles: d.profiles.length,
    users: d.users.length,
  });
});

for (const collection of COLLECTIONS) {
  app.get(`/api/admin/${collection}`, adminAuth, (req, res) => {
    const d = ensureCollections(read());
    const rows = d[collection];
    res.json(collection === 'users' ? rows.map(publicUser) : rows);
  });
  app.post(`/api/admin/${collection}`, adminAuth, (req, res) => {
    const d = ensureCollections(read());
    const item = { ...req.body, id: randomUUID() };
    if (collection === 'users' && (!item.email || !item.password)) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    if (typeof item.tags === 'string') item.tags = item.tags.split(',').map((s) => s.trim()).filter(Boolean);
    if (typeof item.features === 'string') item.features = item.features.split(',').map((s) => s.trim()).filter(Boolean);
    if (typeof item.interests === 'string') item.interests = item.interests.split(',').map((s) => s.trim()).filter(Boolean);
    d[collection].unshift(item);
    write(d);
    res.status(201).json(collection === 'users' ? publicUser(item) : item);
  });
  app.put(`/api/admin/${collection}/:id`, adminAuth, (req, res) => {
    const d = ensureCollections(read());
    const i = d[collection].findIndex((item) => String(item.id) === req.params.id);
    if (i < 0) return res.status(404).json({ error: 'Not found' });
    const updates = { ...req.body };
    delete updates.id;
    if (collection === 'users' && !updates.password) delete updates.password;
    if (typeof updates.tags === 'string') updates.tags = updates.tags.split(',').map((s) => s.trim()).filter(Boolean);
    if (typeof updates.features === 'string') updates.features = updates.features.split(',').map((s) => s.trim()).filter(Boolean);
    if (typeof updates.interests === 'string') updates.interests = updates.interests.split(',').map((s) => s.trim()).filter(Boolean);
    d[collection][i] = { ...d[collection][i], ...updates, id: d[collection][i].id };
    write(d);
    res.json(collection === 'users' ? publicUser(d[collection][i]) : d[collection][i]);
  });
  app.delete(`/api/admin/${collection}/:id`, adminAuth, (req, res) => {
    const d = ensureCollections(read());
    if (collection === 'users' && req.params.id === 'admin1') {
      return res.status(400).json({ error: 'Cannot delete the default admin account' });
    }
    const before = d[collection].length;
    d[collection] = d[collection].filter((item) => String(item.id) !== req.params.id);
    if (before === d[collection].length) return res.status(404).json({ error: 'Not found' });
    write(d);
    res.json({ ok: true });
  });
}

app.get('/api/admin/bookings', adminAuth, (_, res) => res.json(ensureCollections(read()).bookings));
app.patch('/api/admin/bookings/:id', adminAuth, (req, res) => {
  const d = ensureCollections(read());
  const i = d.bookings.findIndex((b) => String(b.id) === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Not found' });
  const updates = { ...req.body };
  delete updates.id;
  d.bookings[i] = { ...d.bookings[i], ...updates };
  write(d);
  res.json(d.bookings[i]);
});
app.delete('/api/admin/bookings/:id', adminAuth, (req, res) => {
  const d = ensureCollections(read());
  const before = d.bookings.length;
  d.bookings = d.bookings.filter((b) => String(b.id) !== req.params.id);
  if (before === d.bookings.length) return res.status(404).json({ error: 'Not found' });
  write(d);
  res.json({ ok: true });
});

app.use('/admin', express.static(path.join(__dirname, '../admin')));

app.listen(PORT, () => {
  console.log(`StrangersMeet API http://localhost:${PORT}`);
  console.log(`Admin UI      http://localhost:${PORT}/admin`);
  console.log(`Data file     ${DATA}`);
  if (cloudinary) {
    console.log(`Cloudinary    ON (${process.env.CLOUDINARY_CLOUD_NAME})`);
  } else {
    console.log(`Cloudinary    OFF — set keys in backend/.env then: npm install`);
  }
});
