# Integrations diagnostics

The Integrations page calls `GET /api/providers/integrations/status`, which is registered by this project's Express server in `server/src/index.js` and `server/src/routes/providers.js`. A JSON `{ "error": "Not found" }` response usually means the browser proxy is reaching a different/old server process or the API is running on a different port; it is not evidence that every integration is offline.

## Verify the correct backend

From the project root, start the backend in one terminal:

```bash
cd server
cp .env.example .env  # only if .env does not already exist; preserve your own settings
npm install
npm run dev
```

The sample `.env.example` uses port 5001. In another terminal, test:

```bash
curl -i http://localhost:5001/api/health
curl -i http://localhost:5001/api/providers/integrations/status
```

Start the frontend from `client`; `vite.config.js` proxies `/api` and `/uploads` to `http://localhost:5001`. If port 5001 is occupied by an older project/server, stop that process before restarting this project's backend. Do not mark services online until their own status probe succeeds.

Qdrant and n8n buttons need their service URLs configured and running. The `.env` values are local defaults; install/start those services or configure reachable URLs before expecting success.
