/**
 * FILE: frontend/src/config.js
 * PURPOSE: Central place for API / WebSocket URLs.
 * Values come from Vite env (src/.env) with production fallbacks.
 */

const API_BASE =
  (import.meta.env.VITE_API_BASE || 'https://api.supportassistant-ai.com').replace(
    /\/$/,
    ''
  );

const WS_URL =
  import.meta.env.VITE_WS_URL || 'wss://api.supportassistant-ai.com/stream';

export const config = {
  /** e.g. https://api.supportassistant-ai.com */
  apiBase: API_BASE,

  /** Auth endpoints base: .../api/auth */
  authUrl: `${API_BASE}/api/auth`,

  /** Conversations: .../api/conversations */
  conversationsUrl: `${API_BASE}/api/conversations`,

  /** Plan: .../api/plan */
  planUrl: `${API_BASE}/api/plan`,

  /** Profile: .../api/profile */
  profileUrl: `${API_BASE}/api/profile`,

  /** AI (text / screenshot): .../api/ai */
  aiUrl: `${API_BASE}/api/ai`,

  /** Live audio WebSocket */
  websocketUrl: WS_URL,
};

export default config;
