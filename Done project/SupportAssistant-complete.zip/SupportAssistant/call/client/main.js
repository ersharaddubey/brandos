/**
 * FILE: electron/main.js
 * PURPOSE: Electron main process — window management, IPC, audio source
 * discovery only. Actual audio capture (getUserMedia/AudioContext/
 * AudioWorklet) happens in the RENDERER — see frontend/src/audio/
 * systemAudioCapture.js and its header comment for why.
 *
 * PHASE 2 CHANGES FROM PREVIOUS VERSION:
 * - Removed the require('./audio') import and the audio-start/audio-stop/
 *   audio-status IPC handlers. They called createAudioCapture(), which
 *   lived in electron/audio/index.js and tried to call browser-only APIs
 *   (navigator.mediaDevices, AudioContext, etc.) from this main/Node
 *   process — that file has been deleted, along with windows.capture.js,
 *   mac.capture.js, and vad.js (see PROJECT_NOTES / conversation history
 *   for the full explanation).
 * - Added ipcMain.handle('audio-check-readiness', ...) — the ONE piece of
 *   audio work that legitimately belongs in main, because desktopCapturer
 *   is main-process-only. This just finds a usable screen/audio source and
 *   hands its id back to the renderer, which does the actual capture.
 *
 * PHASE 13 STEP 1 CHANGE (this revision):
 * - Added ipcMain.handle('capture-screenshot', ...) — reuses the same
 *   desktopCapturer API device-detector.js already depends on for audio
 *   readiness, but this time requests an actual thumbnail image (not just
 *   a source id) and returns it as a base64 PNG data URL, ready to send
 *   straight to POST /api/ai/screenshot's `image` field.
 */

const { app, BrowserWindow, ipcMain, screen, session, desktopCapturer, globalShortcut, systemPreferences, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { autoUpdater } = require('electron-updater');
const { detectSystemAudioDevices } = require('./audio/device-detector');
const { storeTokens, getTokens, clearTokens, hasTokens } = require('./secure-store');

// ── Configuration ──────────────────────────────────────────────
const isDev = !app.isPackaged; // true in dev (npm start), false in packaged exe/dmg
const isMac = process.platform === 'darwin';
const isWin = process.platform === 'win32';

// ── macOS system-audio loopback flags (MUST be set before app is ready) ──
// getUserMedia({chromeMediaSource:'desktop'}) gives NO system audio on macOS.
// The working path is getDisplayMedia + setDisplayMediaRequestHandler(audio:'loopback'),
// which needs these Chromium features turned on.
if (isMac) {
  app.commandLine.appendSwitch(
    'enable-features',
    'MacLoopbackAudioForScreenShare,MacSckSystemAudioLoopbackOverride'
  );
}

// ── macOS privacy helpers ──────────────────────────────────────
function macScreenStatus() {
  return isMac ? systemPreferences.getMediaAccessStatus('screen') : 'granted';
}
function macMicStatus() {
  return isMac ? systemPreferences.getMediaAccessStatus('microphone') : 'granted';
}
function openMacPrivacy(pane) {
  // pane: 'Privacy_ScreenCapture' | 'Privacy_Microphone'
  if (!isMac) return;
  shell.openExternal(`x-apple.systempreferences:com.apple.preference.security?${pane}`).catch(() => {});
}

let mainWindow = null;
let isQuitting = false;

// ── Professional Window Management ─────────────────────────────
class WindowManager {
  constructor() {
    this.window = null;
    this.bounds = null;
    this.isVisible = false;
    this.isMinimized = false;
    this.stealthEnabled = true; 
    this.configPath = path.join(app.getPath('userData'), 'window-config.json');
  }

  saveConfig(data) {
    try {
      const dir = path.dirname(this.configPath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(this.configPath, JSON.stringify(data, null, 2));
    } catch (err) {
      console.warn('Failed to save config:', err.message);
    }
  }

  loadConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        return JSON.parse(fs.readFileSync(this.configPath, 'utf8'));
      }
    } catch (err) {
      console.warn('Failed to load config:', err.message);
    }
    return null;
  }

  getDefaultBounds() {
    const { width, height } = screen.getPrimaryDisplay().workAreaSize;
    return {
      x: Math.round((width - 420) / 2),
      y: Math.round((height - 650) / 2),
      width: 420,
      height: 650,
    };
  }

  // createWindow() {
  //   const savedConfig = this.loadConfig();
  //   const defaultBounds = this.getDefaultBounds();
  //   this.bounds = savedConfig?.bounds || defaultBounds;

  //   this.window = new BrowserWindow({
  //     width: this.bounds.width || 420,
  //     height: this.bounds.height || 650,
  //     minWidth: 360,
  //     minHeight: 500,
  //     x: this.bounds.x,
  //     y: this.bounds.y,
  //     frame: false,
  //     transparent: true,
  //     alwaysOnTop: true,
  //     skipTaskbar: false,
  //     hasShadow: true,
  //     backgroundColor: '#0a0a0f',
  //     show: false,
  //     webPreferences: {
  //       preload: path.join(__dirname, 'preload.js'),
  //       contextIsolation: true,
  //       nodeIntegration: false,
  //       sandbox: false,
  //     },
  //     icon: path.join(__dirname, 'assets/icon.png'),
  //   });

  //   this.window.once('ready-to-show', () => {
  //     this.window.show();
  //     this.isVisible = true;
  //     this.window.webContents.openDevTools();
  //   });

  //   // FORCE DEV SERVER
  //   this.window.loadURL('http://localhost:5173');

  //   this.window.on('close', (event) => {
  //     if (!isQuitting) {
  //       event.preventDefault();
  //       this.hideWindow();
  //     }
  //   });

  //   this.window.on('closed', () => {
  //     this.saveBounds();
  //     this.window = null;
  //     this.isVisible = false;
  //   });

  //   this.window.on('resize', () => { this.saveBounds(); });
  //   this.window.on('move', () => { this.saveBounds(); });
  //   this.window.on('minimize', () => { this.isMinimized = true; });
  //   this.window.on('restore', () => {
  //     this.isMinimized = false;
  //     this.isVisible = true;
  //   });
  //   this.window.on('show', () => { this.isVisible = true; });
  //   this.window.on('hide', () => { this.isVisible = false; });

  //   mainWindow = this.window;
  //   return this.window;
  // }
  createWindow() {
    const savedConfig = this.loadConfig();
    const defaultBounds = this.getDefaultBounds();
    this.bounds = savedConfig?.bounds || defaultBounds;
    // Fresh install => no saved config => stays default true (from constructor).
    // Existing install => whatever the user last set, restored here.
    this.stealthEnabled = savedConfig?.stealthEnabled ?? true;

    this.window = new BrowserWindow({
      width: this.bounds.width || 420,
      height: this.bounds.height || 650,
      minWidth: 360,
      minHeight: 500,
      x: this.bounds.x,
      y: this.bounds.y,
      frame: false,
      // transparent can hide a failed UI — keep solid bg until UI is stable
      transparent: false,
      alwaysOnTop: true,
      skipTaskbar: false,
      hasShadow: true,
      backgroundColor: '#0a0a0f',
      show: false,
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: false,
        webSecurity: false, // allow file:// ES modules + relative assets
      },
      ...(fs.existsSync(path.join(__dirname, 'assets', 'icon.png'))
        ? { icon: path.join(__dirname, 'assets', 'icon.png') }
        : {}),
    });

    this.window.setAlwaysOnTop(true, 'screen-saver');
    this.window.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    this.window.setContentProtection(this.stealthEnabled);

    this.window.once('ready-to-show', () => {
      this.window.show();
      this.isVisible = true;
      if (isDev || process.env.SA_DEVTOOLS === '1') this.window.webContents.openDevTools({ mode: 'detach' });
    });

    this.window.webContents.on('did-fail-load', (_e, code, desc, url) => {
      console.error('[load fail]', code, desc, url);
    });
    this.window.webContents.on('console-message', (_e, level, message, line, sourceId) => {
      const tag = ['log', 'warn', 'error'][level] || 'log';
      console[tag === 'log' ? 'log' : tag](`[renderer ${tag}]`, message, sourceId + ':' + line);
    });
    this.window.webContents.on('did-finish-load', () => {
      console.log('[did-finish-load]', this.window.webContents.getURL());
    });

    // Load React app
    if (isDev) {
      this.window.loadURL('http://localhost:5173');
    } else {
      // Prefer asar.unpacked path (ES modules break inside app.asar)
      const candidates = [
        path.join(process.resourcesPath, 'app.asar.unpacked', 'frontend', 'index.html'),
        path.join(__dirname, 'frontend', 'index.html'),
        path.join(app.getAppPath(), 'frontend', 'index.html'),
      ];
      const indexPath = candidates.find((p) => fs.existsSync(p));
      console.log('[production load candidates]', candidates.map((p) => [p, fs.existsSync(p)]));
      if (!indexPath) {
        console.error('[production load] frontend/index.html NOT FOUND');
        this.window.loadURL(
          'data:text/html,<h2 style="color:#fff;font-family:sans-serif;padding:24px">frontend/index.html missing — rebuild with frontend copied into call/client/frontend</h2>'
        );
      } else {
        console.log('[production load]', indexPath);
        this.window.loadFile(indexPath);
      }
    }

    this.window.on('close', (event) => {
      if (!isQuitting) {
        event.preventDefault();
        this.hideWindow();
      }
    });

    this.window.on('closed', () => {
      this.saveBounds();
      this.window = null;
      this.isVisible = false;
    });

    this.window.on('resize', () => { this.saveBounds(); });
    this.window.on('move', () => { this.saveBounds(); });
    this.window.on('minimize', () => { this.isMinimized = true; });
    this.window.on('restore', () => {
      this.isMinimized = false;
      this.isVisible = true;
    });
    this.window.on('show', () => { this.isVisible = true; });
    this.window.on('hide', () => { this.isVisible = false; });

    mainWindow = this.window;
    return this.window;
  }

  saveBounds() {
    if (!this.window) return;
    const bounds = this.window.getBounds();
    this.bounds = bounds;
    const config = this.loadConfig() || {};
    config.bounds = bounds;
    this.saveConfig(config);
  }

  showWindow() {
    if (!this.window) return;
    if (this.isMinimized) {
      this.window.restore();
    } else {
      this.window.show();
      this.window.focus();
    }
    this.isVisible = true;
  }

  hideWindow() {
    if (!this.window) return;
    this.window.hide();
    this.isVisible = false;
  }

  toggleWindow() {
    if (this.isVisible) this.hideWindow();
    else this.showWindow();
  }

  toggleAlwaysOnTop() {
    if (!this.window) return false;
    const isTop = this.window.isAlwaysOnTop();
    this.window.setAlwaysOnTop(!isTop);
    return !isTop;
  }

  minimizeWindow() {
    if (!this.window) return;
    this.window.minimize();
    this.isMinimized = true;
  }

  closeWindow() {
    if (!this.window) return;
    isQuitting = true;
    this.window.close();
  }

  // ── Maximize / Restore toggle ─────────────────────────────────
  toggleMaximize() {
    if (!this.window) return false;
    if (this.window.isMaximized()) {
      this.window.unmaximize();
    } else {
      this.window.maximize();
    }
    return this.window.isMaximized();
  }

  // ── Stealth mode (content protection) ───────────────────────────
  setStealthMode(enabled) {
    if (!this.window) return false;
    this.window.setContentProtection(enabled);
    this.stealthEnabled = enabled;

    // Persist alongside bounds, same pattern as saveBounds() above —
    // so it survives app restarts, not just page reloads.
    const config = this.loadConfig() || {};
    config.stealthEnabled = enabled;
    this.saveConfig(config);

    return enabled;
  }

  // Lets the renderer sync its UI state after every mount/reload —
  // needed because window.location.reload() on login/logout remounts
  // TitleBar, resetting its local React state, while the actual
  // Electron window (and this class) never restart.
  getStealthMode() {
    return this.stealthEnabled;
  }

  // ── Snap-to-edge (Ctrl+Arrow) ────────────────────────────────────
  // snapWindow(direction) {
  //   if (!this.window) return;
  //   const { workArea } = screen.getPrimaryDisplay();

  //   const half = { width: Math.round(workArea.width / 2), height: workArea.height };

  //   switch (direction) {
  //     case 'left':
  //       this.window.setBounds({ x: workArea.x, y: workArea.y, ...half });
  //       break;
  //     case 'right':
  //       this.window.setBounds({ x: workArea.x + half.width, y: workArea.y, ...half });
  //       break;
  //     case 'up':
  //       this.window.maximize();
  //       break;
  //     case 'down':
  //       this.window.unmaximize();
  //       break;
  //   }
  // }
    // ── Incremental move (Ctrl+Arrow) ────────────────────────────────
  moveWindow(direction) {
    if (!this.window) return;
    const STEP = 20; // pixels per key-press — adjust if too fast/slow
    const bounds = this.window.getBounds();

    switch (direction) {
      case 'left':
        this.window.setBounds({ ...bounds, x: bounds.x - STEP });
        break;
      case 'right':
        this.window.setBounds({ ...bounds, x: bounds.x + STEP });
        break;
      case 'up':
        this.window.setBounds({ ...bounds, y: bounds.y - STEP });
        break;
      case 'down':
        this.window.setBounds({ ...bounds, y: bounds.y + STEP });
        break;
    }
  }

  // ── Opacity control ────────────────────────────────────────────
  setOpacity(value) {
    if (!this.window) return false;
    const clamped = Math.min(1, Math.max(0.3, value)); // 30%–100% floor, so it never goes fully invisible to the user themself
    this.window.setOpacity(clamped);
    return clamped;
  }
}

const windowManager = new WindowManager();

// ── App Lifecycle ──────────────────────────────────────────────
app.whenReady().then(async () => {
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
    // media, microphone, display-capture, mediaKeySystem, etc.
    if (
      permission === 'media' ||
      permission === 'microphone' ||
      permission === 'display-capture' ||
      permission === 'desktopCapturer'
    ) {
      callback(true);
    } else {
      callback(false);
    }
  });

  session.defaultSession.setPermissionCheckHandler((_wc, permission) => {
    return ['media', 'microphone', 'display-capture'].includes(permission);
  });

  // getDisplayMedia() ke liye: screen + system audio loopback (Mac 13+ & Windows)
  session.defaultSession.setDisplayMediaRequestHandler(
    async (_request, callback) => {
      try {
        const sources = await desktopCapturer.getSources({
          types: ['screen'],
          thumbnailSize: { width: 1, height: 1 },
        });
        if (!sources.length) return callback({});
        callback({ video: sources[0], audio: 'loopback' });
      } catch (err) {
        console.error('[display-media-handler] failed:', err.message);
        callback({});
      }
    }
  );

  // macOS: without this + Info.plist usage strings, getUserMedia never prompts
  // and can fail silently (empty tracks / no permission entry).
  if (isMac) {
    try {
      const { systemPreferences } = require('electron');
      const mic = await systemPreferences.askForMediaAccess('microphone');
      console.log('[permissions] microphone access:', mic);
      console.log('[permissions] screen status:', macScreenStatus());
    } catch (err) {
      console.warn('[permissions] askForMediaAccess failed:', err.message);
    }
  }

  windowManager.createWindow();

  // ── Ctrl+Arrow snap-to-edge shortcuts ─────────────────────────
  const mod = isMac ? 'Alt+Command' : 'Control';
  globalShortcut.register(`${mod}+Left`, () => windowManager.moveWindow('left'));
  globalShortcut.register(`${mod}+Right`, () => windowManager.moveWindow('right'));
  globalShortcut.register(`${mod}+Up`, () => windowManager.moveWindow('up'));
  globalShortcut.register(`${mod}+Down`, () => windowManager.moveWindow('down'));
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});

app.on('window-all-closed', () => {
  if (!isMac) app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    windowManager.createWindow();
  } else {
    windowManager.showWindow();
  }
});

// ── Single Instance Lock ──────────────────────────────────────
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    windowManager.showWindow();
  });
}

// ── Global Error Handlers ──────────────────────────────────────
process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason) => {
  console.error('❌ Unhandled Rejection:', reason);
});

// ── IPC Handlers ──────────────────────────────────────────────

// ── Store tokens securely ──────────────────────────────────────
ipcMain.handle('auth-store-tokens', async (event, accessToken, refreshToken) => {
  try {
    const result = storeTokens(accessToken, refreshToken);
    return { success: result };
  } catch (err) {
    console.error('❌ Store tokens error:', err.message);
    return { success: false, error: err.message };
  }
});

// ── Get tokens ──────────────────────────────────────────────────
ipcMain.handle('auth-get-tokens', async () => {
  try {
    const tokens = getTokens();
    if (tokens) {
      return { success: true, accessToken: tokens.accessToken, refreshToken: tokens.refreshToken };
    }
    return { success: false };
  } catch (err) {
    console.error('❌ Get tokens error:', err.message);
    return { success: false, error: err.message };
  }
});

// ── Clear tokens ─────────────────────────────────────────────────
ipcMain.handle('auth-clear-tokens', async () => {
  try {
    const result = clearTokens();
    return { success: result };
  } catch (err) {
    console.error('❌ Clear tokens error:', err.message);
    return { success: false, error: err.message };
  }
});

// ── Check if tokens exist ──────────────────────────────────────
ipcMain.handle('auth-has-tokens', async () => {
  try {
    return { success: true, hasTokens: hasTokens() };
  } catch (err) {
    return { success: false, hasTokens: false };
  }
});

// Window controls
ipcMain.handle('window-toggle-top', () => {
  const isTop = windowManager.toggleAlwaysOnTop();
  return { success: true, isTop };
});

ipcMain.handle('window-minimize', () => {
  windowManager.minimizeWindow();
  return { success: true };
});

ipcMain.handle('window-close', () => {
  windowManager.closeWindow();
  return { success: true };
});

ipcMain.handle('window-maximize', () => {
  const isMaximized = windowManager.toggleMaximize();
  return { success: true, isMaximized };
});

ipcMain.handle('window-set-stealth', (event, enabled) => {
  const result = windowManager.setStealthMode(!!enabled);
  return { success: true, stealthEnabled: result };
});

ipcMain.handle('window-get-stealth', () => {
  return { success: true, stealthEnabled: windowManager.getStealthMode() };
});

ipcMain.handle('window-set-opacity', (event, value) => {
  const result = windowManager.setOpacity(value);
  return { success: true, opacity: result };
});

// ── AUDIO SOURCE DISCOVERY (the only audio work that belongs in main) ──
//
// Renderer calls this once, right before it calls getUserMedia itself.
// We just find the best desktopCapturer audio source and hand its id
// back — see electron/audio/device-detector.js for the platform-specific
// selection logic (loopback/stereo-mix on Windows, BlackHole/system audio
// on Mac).
ipcMain.handle('audio-check-readiness', async () => {
  try {
    console.log('🔎 [IPC] audio-check-readiness called');

    if (isMac) {
      const screen = macScreenStatus();
      const mic = macMicStatus();
      console.log('[IPC] mac permissions → screen:', screen, 'mic:', mic);
      if (screen !== 'granted') {
        // getSources() ek baar chalane se macOS prompt / entry bana deta hai
        await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 1, height: 1 } }).catch(() => {});
        openMacPrivacy('Privacy_ScreenCapture');
        return {
          ok: false,
          message:
            'Screen & System Audio Recording permission nahi mili (status: ' + screen + '). ' +
            'System Settings → Privacy & Security → Screen & System Audio Recording me "Support Assistant" ON karo, ' +
            'phir app ko Quit (Cmd+Q) karke dobara kholo.',
        };
      }
      if (mic === 'denied' || mic === 'restricted') {
        openMacPrivacy('Privacy_Microphone');
        return {
          ok: false,
          message: 'Microphone permission off hai. Privacy & Security → Microphone me Support Assistant ON karo, app restart karo.',
        };
      }
    }

    const devices = await detectSystemAudioDevices();

    if (devices.error) {
      console.error('❌ [IPC] Device detection error:', devices.error);
      return { ok: false, message: devices.error };
    }

    if (!devices.recommendedSource) {
      console.warn('⚠️ [IPC] No usable audio source found on this machine');
      return {
        ok: false,
        message:
          isMac
            ? 'No system audio source found. Install BlackHole or enable system audio capture in System Settings.'
            : 'No system audio source found. Please check your audio drivers.',
      };
    }

    const sourceMeta = devices.sources.find((s) => s.id === devices.recommendedSource);

    console.log('✅ [IPC] Recommended source:', sourceMeta?.name || devices.recommendedSource);

    return {
      ok: true,
      sourceId: devices.recommendedSource,
      sourceName: sourceMeta?.name || 'System Audio',
      hasScreenSource: devices.hasScreenSource,
    };
  } catch (err) {
    console.error('❌ [IPC] audio-check-readiness failed:', err.message);
    return { ok: false, message: err.message };
  }
});

// Informational only — lets main track capture state for tray/UI purposes.
// The renderer owns the actual audio pipeline and WebSocket connection.
ipcMain.on('audio-report-started', () => {
  console.log('🎤 [IPC] Renderer reported: audio capture started');
});

ipcMain.on('audio-report-stopped', () => {
  console.log('⏹ [IPC] Renderer reported: audio capture stopped');
});

// ── SCREENSHOT CAPTURE (Phase 13, Step 1) ───────────────────────
//
// Reuses desktopCapturer, same as audio-check-readiness above, but this
// time requests an actual thumbnail image instead of just a source id.
// Returns a base64 PNG data URL — ready to send straight to
// POST /api/ai/screenshot's `image` field with no conversion needed on
// the renderer side.
//
// thumbnailSize caps the captured resolution — 1920x1080 is generous
// enough for a vision model to read UI text clearly, without sending an
// enormous multi-megabyte payload for a 4K/5K display.
ipcMain.handle('capture-screenshot', async () => {
  try {
    console.log('📸 [IPC] capture-screenshot called');

    if (isMac && macScreenStatus() !== 'granted') {
      await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 1, height: 1 } }).catch(() => {});
      openMacPrivacy('Privacy_ScreenCapture');
      return {
        ok: false,
        message:
          'Screen Recording permission nahi hai (status: ' + macScreenStatus() + '). ' +
          'System Settings → Privacy & Security → Screen & System Audio Recording me Support Assistant ON karo, phir app restart karo.',
      };
    }

    // Cap resolution — full Retina PNG was causing HTTP 413 (payload too large)
    const sources = await desktopCapturer.getSources({
      types: ['screen'],
      thumbnailSize: { width: 1280, height: 720 },
    });

    if (!sources || sources.length === 0) {
      console.warn('⚠️ [IPC] No screen sources available for screenshot');
      return { ok: false, message: 'No screen available to capture' };
    }

    const primary =
      sources.find((s) => /entire screen|screen 1|primary/i.test(s.name)) || sources[0];

    if (primary.thumbnail.isEmpty()) {
      console.warn('⚠️ [IPC] Captured thumbnail is empty');
      return { ok: false, message: 'Screenshot capture returned an empty image' };
    }

    // JPEG ~70% quality is far smaller than PNG and fine for vision models
    const jpeg = primary.thumbnail.toJPEG(70);
    const dataUrl = `data:image/jpeg;base64,${jpeg.toString('base64')}`;

    console.log(
      `✅ [IPC] Screenshot captured from "${primary.name}" ` +
      `(${(dataUrl.length / 1024).toFixed(1)} KB data-URL, jpeg bytes=${jpeg.length})`
    );

    return { ok: true, image: dataUrl, sourceName: primary.name };
  } catch (err) {
    console.error('❌ [IPC] capture-screenshot failed:', err.message);
    return { ok: false, message: err.message };
  }
});

// ── Clipboard ──────────────────────────────────────────────────
ipcMain.handle('copy-to-clipboard', (event, text) => {
  try {
    require('electron').clipboard.writeText(String(text ?? ''));
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// ── Auto-Updater ──────────────────────────────────────────────
if (!isDev && !isMac) {
  // Mac build unsigned hai -> electron-updater yaha hamesha error deta hai, isliye skip.
  autoUpdater.on('error', (err) => console.warn('[updater] error:', err && err.message));
  setTimeout(() => {
    autoUpdater.checkForUpdatesAndNotify().catch((err) =>
      console.warn('[updater] check failed:', err && err.message)
    );
  }, 5000);
}

module.exports = { app, windowManager };