// Runs after electron-builder packs the app, BEFORE the DMG is created.
// Unsigned arm64 Mac apps get no stable identity, so macOS never keeps the
// Screen Recording / Microphone permission. Ad-hoc signing fixes that.
const { execFileSync } = require('child_process');
const path = require('path');

exports.default = async function afterPack(context) {
  if (context.electronPlatformName !== 'darwin') return;
  const appPath = path.join(
    context.appOutDir,
    `${context.packager.appInfo.productFilename}.app`
  );
  console.log('[afterPack] ad-hoc signing:', appPath);
  execFileSync('codesign', ['--force', '--deep', '--sign', '-', appPath], { stdio: 'inherit' });
};
