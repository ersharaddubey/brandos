# Support Assistant — MacBook (M1/M2/M3/M4) Build

## One-time setup
```bash
cd SupportAssistant
```

## Build DMG (copy-paste all)

```bash
cd call/server
npm install
npm run build

cd ../..
rm -rf call/client/frontend
mkdir -p call/client/frontend
cp -r call/server/dist/* call/client/frontend/

cd call/client
npm install
npm run dist:mac
```

## Output
- App: `call/client/dist/mac-arm64/Support Assistant.app`
- DMG: `call/client/dist/Support Assistant-1.0.0-arm64.dmg`

## Open
```bash
open "call/client/dist/mac-arm64/Support Assistant.app"
```

If Gatekeeper blocks: Right-click → Open → Open.

## Debug (if blank screen)
```bash
"./call/client/dist/mac-arm64/Support Assistant.app/Contents/MacOS/Support Assistant"
```
DevTools opens automatically. Check Console for red errors.

## Included fixes
- vite `base: './'` (relative paths for file://)
- frontend unpacked from asar (ES modules work)
- production load via app.asar.unpacked path
- screenshot JPEG 1280x720 (fixes HTTP 413)
- icon 1024x1024 (Mac requirement)
- arm64 only (Apple Silicon)

## Mac fixes (latest)
- Electron 33 + getDisplayMedia loopback for system audio (macOS 13+), BlackHole as fallback
- Ad-hoc code signing (call/client/sign-adhoc.js) so Screen/Mic permissions stick
- build-mac.sh resets stale TCC permissions after every build
- After first launch: allow prompts, then Cmd+Q and reopen once
- Debug: SA_DEVTOOLS=1 "./call/client/dist/mac-arm64/Support Assistant.app/Contents/MacOS/Support Assistant"
