#!/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
echo "==> Building frontend (vite base: './')..."
cd "$ROOT/call/server"
# Ensure vite.config.js exists with base: './'
if [ ! -f vite.config.js ]; then
  echo "ERROR: vite.config.js missing. base: './' required for Electron."
  exit 1
fi
npm install --no-audit --no-fund
npm run build
echo "==> Copying frontend to Electron..."
rm -rf "$ROOT/call/client/frontend"
mkdir -p "$ROOT/call/client/frontend"
cp -r dist/* "$ROOT/call/client/frontend/"
# Safety: force relative paths if any absolute slipped in
sed -i 's|href="/favicon.svg"|href="./favicon.svg"|g; s|src="/assets/|src="./assets/|g; s|href="/assets/|href="./assets/|g' "$ROOT/call/client/frontend/index.html" 2>/dev/null || true
echo "==> Checking assets..."
mkdir -p "$ROOT/call/client/assets"
if [ ! -f "$ROOT/call/client/assets/icon.ico" ]; then
  echo "WARN: assets/icon.ico missing — build may warn about icon"
fi
echo "==> Building Electron EXE..."
cd "$ROOT/call/client"
npm install --no-audit --no-fund
npx electron-builder --win --x64 --publish never
echo ""
echo "✅ Done! Check: call/client/dist/"
ls -la dist/*.exe 2>/dev/null || ls -la dist/
