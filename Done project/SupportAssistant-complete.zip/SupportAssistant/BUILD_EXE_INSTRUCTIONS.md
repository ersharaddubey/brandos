# Support Assistant - EXE Build Instructions (Fixed v2)

## Previous problems (already fixed)
1. `main.js` me `isDev = true` hardcoded tha → hamesha `http://localhost:5173` load hota tha.
2. Packaged EXE me Vite dev server nahi hota, isliye blank screen.
3. Vite build me absolute paths (`/assets/...`) the, jo `file://` protocol me fail hote hain.
4. Electron builder me React `dist` folder properly include nahi ho raha tha.
5. **Missing `vite.config.js`** (base: './' nahi tha) → rebuild pe phir absolute paths.
6. **Missing `assets/icon.ico` / `icon.png`** → electron-builder icon warning/fail.

## Kya fix kiya gaya (v2)
- `client/main.js`: `isDev = !app.isPackaged` + production me `loadFile(.../frontend/index.html)`
- `client/main.js`: icon path safe (`fs.existsSync` check)
- `server/vite.config.js`: **added** with `base: './'` (Electron file:// ke liye zaroori)
- Existing `dist` ko relative paths ke saath `client/frontend/` me copy kiya
- `client/package.json`: files list me `assets/**/*` + frontend include
- `client/assets/icon.ico` + `icon.png`: placeholder icons added (apna proper icon replace kar sakte ho)

## EXE banane ke steps (Windows par)

### 1. Requirements
- Node.js 18+ installed

### 2. One-command build (recommended)
```bash
bash build-exe.sh
```

### 3. Manual steps
```bash
# Frontend
cd call/server
npm install
npm run build
# dist/ banega

# Copy to Electron
cd ../..
rm -rf call/client/frontend
mkdir -p call/client/frontend
cp -r call/server/dist/* call/client/frontend/
# relative paths ensure (vite already base: './')
sed -i 's|href="/favicon.svg"|href="./favicon.svg"|g; s|src="/assets/|src="./assets/|g; s|href="/assets/|href="./assets/|g' call/client/frontend/index.html 2>/dev/null || true

# Electron EXE
cd call/client
npm install
npm run dist
# ya: npx electron-builder --win --x64 --publish never
```

### 4. Output
`call/client/dist/` me `Support Assistant Setup 1.0.0.exe` (NSIS installer) mil jayega.

### Dev mode (testing)
Terminal 1:
```bash
cd call/server
npm run dev
# → http://localhost:5173
```
Terminal 2:
```bash
cd call/client
npm start
# Electron localhost:5173 load karega
```

## React / Vite notes
- React `^19.2.7` + Vite 8 compatible.
- Agar node_modules conflict ho:
```bash
cd call/server
rm -rf node_modules package-lock.json
npm install
```

## Important files
- `call/server/vite.config.js`  ← base: './' (NEW / restored)
- `call/client/main.js`         ← production loadFile + safe icon
- `call/client/package.json`    ← files + assets include
- `call/client/assets/`         ← icon.ico, icon.png
- `call/client/frontend/`       ← pre-built React app (relative paths)
