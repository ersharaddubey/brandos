import { Router } from 'express';
import { User } from '../models/User.js';
import {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} from '../utils/jwt.util.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

function tokensFor(user) {
  const payload = { sub: user._id.toString(), email: user.email };
  return {
    accessToken: signAccessToken(payload),
    refreshToken: signRefreshToken(payload),
  };
}

/** POST /api/auth/register  { email, password, name? } */
router.post('/register', async (req, res) => {
  try {
    const { email, password, name } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required' });
    }
    if (password.length < 6) {
      return res.status(400).json({ success: false, error: 'Password must be at least 6 characters' });
    }

    const existing = await User.findOne({ email: email.toLowerCase().trim() });
    if (existing) {
      return res.status(409).json({ success: false, error: 'Email already registered' });
    }

    const passwordHash = await User.hashPassword(password);
    const user = await User.create({
      email: email.toLowerCase().trim(),
      passwordHash,
      name: (name || '').trim(),
    });

    const { accessToken, refreshToken } = tokensFor(user);
    user.refreshTokens = [...(user.refreshTokens || []), refreshToken].slice(-10);
    await user.save();

    return res.status(201).json({
      success: true,
      user: user.toPublicJSON(),
      accessToken,
      refreshToken,
    });
  } catch (err) {
    console.error('[auth/register]', err);
    return res.status(500).json({ success: false, error: 'Registration failed' });
  }
});

/** POST /api/auth/login  { email, password } */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required' });
    }

    const user = await User.findOne({ email: email.toLowerCase().trim() });
    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ success: false, error: 'Invalid email or password' });
    }

    const { accessToken, refreshToken } = tokensFor(user);
    user.refreshTokens = [...(user.refreshTokens || []), refreshToken].slice(-10);
    await user.save();

    return res.json({
      success: true,
      user: user.toPublicJSON(),
      accessToken,
      refreshToken,
    });
  } catch (err) {
    console.error('[auth/login]', err);
    return res.status(500).json({ success: false, error: 'Login failed' });
  }
});

/** POST /api/auth/refresh  { refreshToken } */
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body || {};
    if (!refreshToken) {
      return res.status(400).json({ success: false, error: 'refreshToken is required' });
    }

    let payload;
    try {
      payload = verifyRefreshToken(refreshToken);
    } catch {
      return res.status(401).json({ success: false, error: 'Invalid or expired refresh token' });
    }

    const user = await User.findById(payload.sub);
    if (!user || !(user.refreshTokens || []).includes(refreshToken)) {
      return res.status(401).json({ success: false, error: 'Refresh token revoked or unknown' });
    }

    // Rotate refresh token
    const tokens = tokensFor(user);
    user.refreshTokens = (user.refreshTokens || [])
      .filter((t) => t !== refreshToken)
      .concat(tokens.refreshToken)
      .slice(-10);
    await user.save();

    return res.json({
      success: true,
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      user: user.toPublicJSON(),
    });
  } catch (err) {
    console.error('[auth/refresh]', err);
    return res.status(500).json({ success: false, error: 'Refresh failed' });
  }
});

/** POST /api/auth/logout  { refreshToken? } */
router.post('/logout', async (req, res) => {
  try {
    const { refreshToken } = req.body || {};
    if (refreshToken) {
      try {
        const payload = verifyRefreshToken(refreshToken);
        const user = await User.findById(payload.sub);
        if (user) {
          user.refreshTokens = (user.refreshTokens || []).filter((t) => t !== refreshToken);
          await user.save();
        }
      } catch {
        // ignore invalid token on logout
      }
    }
    return res.json({ success: true });
  } catch (err) {
    console.error('[auth/logout]', err);
    return res.status(500).json({ success: false, error: 'Logout failed' });
  }
});

/** GET /api/auth/me */
router.get('/me', requireAuth, async (req, res) => {
  return res.json({ success: true, user: req.user });
});

export default router;
