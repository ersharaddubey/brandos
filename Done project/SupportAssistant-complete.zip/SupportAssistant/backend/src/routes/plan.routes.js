import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

/** Supported AI providers and which modes they can power */
export const PROVIDER_CAPABILITIES = {
  groq: { modes: ['voice', 'chat', 'screenshot'], label: 'Groq' },
  gemini: { modes: ['voice', 'chat', 'screenshot'], label: 'Google Gemini' },
  mistral: { modes: ['voice', 'chat', 'screenshot'], label: 'Mistral' },
  openai: { modes: ['voice', 'chat', 'screenshot'], label: 'OpenAI' },
  anthropic: { modes: ['voice', 'chat', 'screenshot'], label: 'Anthropic Claude' },
};

const VALID_MODES = ['voice', 'chat', 'screenshot'];
const VALID_PROVIDERS = Object.keys(PROVIDER_CAPABILITIES);

function prefsToObject(mapOrObj) {
  if (!mapOrObj) return {};
  if (mapOrObj instanceof Map) return Object.fromEntries(mapOrObj);
  return { ...mapOrObj };
}

/** GET /api/plan */
router.get('/', requireAuth, async (req, res) => {
  try {
    const user = req.userDoc;
    const configuredProviders = (user.providers || []).map((p) => p.name);

    return res.json({
      success: true,
      plan: {
        tier: user.plan?.tier || null,
        status: user.plan?.status || 'inactive',
      },
      providerPreferences: prefsToObject(user.providerPreferences),
      configuredProviders,
      providerCapabilities: PROVIDER_CAPABILITIES,
      hasAssemblyAI: Boolean(user.assemblyaiKey),
    });
  } catch (err) {
    console.error('[plan/get]', err);
    return res.status(500).json({ success: false, error: 'Failed to load plan' });
  }
});

/**
 * POST /api/plan/activate-l1
 * Body: {
 *   assemblyaiKey: string,
 *   providers: [{ name, key, useFor: string[] }],
 *   termsAccepted: boolean
 * }
 */
router.post('/activate-l1', requireAuth, async (req, res) => {
  try {
    const { assemblyaiKey, providers, termsAccepted } = req.body || {};

    if (!termsAccepted) {
      return res.status(400).json({ success: false, error: 'Terms must be accepted' });
    }
    if (!assemblyaiKey || !String(assemblyaiKey).trim()) {
      return res.status(400).json({ success: false, error: 'AssemblyAI key is required' });
    }
    if (!Array.isArray(providers) || providers.length === 0) {
      return res.status(400).json({ success: false, error: 'At least one AI provider is required' });
    }

    const cleaned = [];
    const preferences = {};

    for (const p of providers) {
      const name = String(p.name || '').toLowerCase().trim();
      const key = String(p.key || '').trim();
      const useFor = Array.isArray(p.useFor)
        ? p.useFor.map((m) => String(m).toLowerCase()).filter((m) => VALID_MODES.includes(m))
        : [];

      if (!VALID_PROVIDERS.includes(name)) {
        return res.status(400).json({
          success: false,
          error: `Unknown provider "${p.name}". Supported: ${VALID_PROVIDERS.join(', ')}`,
        });
      }
      if (!key) {
        return res.status(400).json({ success: false, error: `API key required for ${name}` });
      }
      if (useFor.length === 0) {
        return res.status(400).json({ success: false, error: `Select at least one mode for ${name}` });
      }

      cleaned.push({ name, key, useFor });
      for (const mode of useFor) {
        preferences[mode] = name;
      }
    }

    // Ensure all three modes have a provider if possible
    for (const mode of VALID_MODES) {
      if (!preferences[mode] && cleaned.length) {
        preferences[mode] = cleaned[0].name;
      }
    }

    const user = req.userDoc;
    user.assemblyaiKey = String(assemblyaiKey).trim();
    user.providers = cleaned;
    user.providerPreferences = preferences;
    user.plan = {
      tier: 'L1',
      status: 'active',
      termsAcceptedAt: new Date(),
    };
    await user.save();

    return res.json({
      success: true,
      plan: user.plan,
      providerPreferences: preferences,
      configuredProviders: cleaned.map((p) => p.name),
      providerCapabilities: PROVIDER_CAPABILITIES,
    });
  } catch (err) {
    console.error('[plan/activate-l1]', err);
    return res.status(500).json({ success: false, error: 'Activation failed' });
  }
});

/** PATCH /api/plan/providers  { mode, provider } */
router.patch('/providers', requireAuth, async (req, res) => {
  try {
    const mode = String(req.body?.mode || '').toLowerCase();
    const provider = String(req.body?.provider || '').toLowerCase();

    if (!VALID_MODES.includes(mode)) {
      return res.status(400).json({ success: false, error: `Invalid mode. Use: ${VALID_MODES.join(', ')}` });
    }
    if (!VALID_PROVIDERS.includes(provider)) {
      return res.status(400).json({ success: false, error: `Invalid provider` });
    }

    const user = req.userDoc;
    const hasKey = (user.providers || []).some((p) => p.name === provider);
    if (!hasKey) {
      return res.status(400).json({
        success: false,
        error: `Provider "${provider}" is not configured. Add its key first.`,
      });
    }

    const prefs = prefsToObject(user.providerPreferences);
    prefs[mode] = provider;
    user.providerPreferences = prefs;
    await user.save();

    return res.json({
      success: true,
      providerPreferences: prefs,
    });
  } catch (err) {
    console.error('[plan/providers]', err);
    return res.status(500).json({ success: false, error: 'Reassignment failed' });
  }
});

/** PATCH /api/plan/keys  { provider, key } — rotate/update a stored key */
router.patch('/keys', requireAuth, async (req, res) => {
  try {
    const provider = String(req.body?.provider || '').toLowerCase();
    const key = String(req.body?.key || '').trim();

    if (!VALID_PROVIDERS.includes(provider)) {
      return res.status(400).json({ success: false, error: 'Invalid provider' });
    }
    if (!key) {
      return res.status(400).json({ success: false, error: 'Key is required' });
    }

    const user = req.userDoc;
    const list = user.providers || [];
    const idx = list.findIndex((p) => p.name === provider);

    if (idx >= 0) {
      list[idx].key = key;
    } else {
      list.push({ name: provider, key, useFor: VALID_MODES.slice() });
    }
    user.providers = list;

    // Special case: assemblyai can also be updated this way if name matches
    if (provider === 'assemblyai') {
      user.assemblyaiKey = key;
    }

    await user.save();
    return res.json({ success: true });
  } catch (err) {
    console.error('[plan/keys]', err);
    return res.status(500).json({ success: false, error: 'Key update failed' });
  }
});

export default router;
