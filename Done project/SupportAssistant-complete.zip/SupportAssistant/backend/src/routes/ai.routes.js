import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { Conversation } from '../models/Conversation.js';
import { generateAnswer } from '../services/ai.service.js';

const router = Router();

async function getOrCreateConversation(userId, conversationId, mode) {
  if (conversationId) {
    const existing = await Conversation.findOne({ _id: conversationId, userId });
    if (existing) return existing;
  }
  return Conversation.create({
    userId,
    title: 'New conversation',
    mode: mode === 'voice' ? 'voice' : mode === 'screenshot' ? 'screenshot' : 'chat',
    messages: [],
  });
}

function historyFromConv(conv) {
  return (conv.messages || []).map((m) => ({
    role: m.role,
    content: m.content,
  }));
}

/** POST /api/ai/text  { question, conversationId? } */
router.post('/text', requireAuth, async (req, res) => {
  try {
    const question = String(req.body?.question || '').trim();
    if (!question) {
      return res.status(400).json({ success: false, error: 'question is required' });
    }

    const conv = await getOrCreateConversation(
      req.userDoc._id,
      req.body?.conversationId,
      'chat'
    );

    const { answer, provider, model } = await generateAnswer({
      userDoc: req.userDoc,
      mode: 'chat',
      question,
      history: historyFromConv(conv),
    });

    conv.messages.push(
      { role: 'user', content: question, mode: 'chat' },
      { role: 'assistant', content: answer, mode: 'chat', provider, model }
    );
    if (conv.title === 'New conversation') {
      conv.title = question.slice(0, 80);
    }
    if (conv.mode !== 'chat') conv.mode = 'mixed';
    await conv.save();

    return res.json({
      success: true,
      question,
      answer,
      provider,
      model,
      conversationId: conv._id.toString(),
    });
  } catch (err) {
    console.error('[ai/text]', err);
    return res.status(500).json({ success: false, error: err.message || 'AI request failed' });
  }
});

/**
 * POST /api/ai/screenshot
 * { image: dataURL, question?, conversationId? }
 */
router.post('/screenshot', requireAuth, async (req, res) => {
  try {
    const image = req.body?.image;
    if (!image || typeof image !== 'string') {
      return res.status(400).json({ success: false, error: 'image (base64/dataURL) is required' });
    }

    // Rough size guard (~10MB base64)
    if (image.length > 14_000_000) {
      return res.status(413).json({ success: false, error: 'Screenshot too large' });
    }

    const question = String(req.body?.question || '').trim();
    const prompt =
      question ||
      'Analyze this screenshot. Identify any errors, UI issues, or questions visible and explain how to fix or answer them.';

    const conv = await getOrCreateConversation(
      req.userDoc._id,
      req.body?.conversationId,
      'screenshot'
    );

    const { answer, provider, model } = await generateAnswer({
      userDoc: req.userDoc,
      mode: 'screenshot',
      question: prompt,
      history: historyFromConv(conv),
      imageBase64: image,
    });

    conv.messages.push(
      {
        role: 'user',
        content: question || '[Screenshot]',
        mode: 'screenshot',
        imagePreview: image.slice(0, 64) + '…', // don't store full image in DB
      },
      { role: 'assistant', content: answer, mode: 'screenshot', provider, model }
    );
    if (conv.title === 'New conversation') {
      conv.title = (question || 'Screenshot').slice(0, 80);
    }
    if (conv.mode !== 'screenshot') conv.mode = 'mixed';
    await conv.save();

    return res.json({
      success: true,
      question: question || null,
      answer,
      provider,
      model,
      conversationId: conv._id.toString(),
    });
  } catch (err) {
    console.error('[ai/screenshot]', err);
    return res.status(500).json({ success: false, error: err.message || 'Screenshot AI failed' });
  }
});

export default router;
