import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { Conversation } from '../models/Conversation.js';

const router = Router();

/** GET /api/conversations?mode=voice|chat|screenshot */
router.get('/', requireAuth, async (req, res) => {
  try {
    const filter = { userId: req.userDoc._id };
    if (req.query.mode) {
      filter.$or = [{ mode: req.query.mode }, { mode: 'mixed' }];
    }

    const list = await Conversation.find(filter)
      .sort({ updatedAt: -1 })
      .limit(100)
      .select('_id title mode createdAt updatedAt messages')
      .lean();

    const conversations = list.map((c) => {
      const last = c.messages?.[c.messages.length - 1];
      return {
        id: c._id.toString(),
        title: c.title,
        mode: c.mode,
        createdAt: c.createdAt,
        updatedAt: c.updatedAt,
        messageCount: c.messages?.length || 0,
        preview: last?.content?.slice(0, 120) || '',
      };
    });

    return res.json({ success: true, conversations });
  } catch (err) {
    console.error('[conversations/list]', err);
    return res.status(500).json({ success: false, error: 'Failed to load conversations' });
  }
});

/** GET /api/conversations/:id */
router.get('/:id', requireAuth, async (req, res) => {
  try {
    const conv = await Conversation.findOne({
      _id: req.params.id,
      userId: req.userDoc._id,
    }).lean();

    if (!conv) {
      return res.status(404).json({ success: false, error: 'Conversation not found' });
    }

    return res.json({
      success: true,
      conversation: {
        id: conv._id.toString(),
        title: conv.title,
        mode: conv.mode,
        createdAt: conv.createdAt,
        updatedAt: conv.updatedAt,
      },
      messages: (conv.messages || []).map((m) => ({
        id: m._id?.toString(),
        role: m.role,
        content: m.content,
        mode: m.mode,
        provider: m.provider,
        model: m.model,
        imagePreview: m.imagePreview ? '[image]' : null,
        createdAt: m.createdAt,
      })),
    });
  } catch (err) {
    console.error('[conversations/get]', err);
    return res.status(500).json({ success: false, error: 'Failed to load conversation' });
  }
});

export default router;
