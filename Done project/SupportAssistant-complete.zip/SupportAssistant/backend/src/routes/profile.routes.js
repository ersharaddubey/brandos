import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

const EMPTY_PROFILE = {
  introduction: '',
  experienceLevel: '',
  totalExperience: '',
  languages: [],
  frontend: [],
  databases: [],
  projects: [],
  remarks: '',
};

/** GET /api/profile */
router.get('/', requireAuth, async (req, res) => {
  try {
    const tp = req.userDoc.techProfile || {};
    return res.json({
      success: true,
      techProfile: {
        ...EMPTY_PROFILE,
        introduction: tp.introduction || '',
        experienceLevel: tp.experienceLevel || '',
        totalExperience: tp.totalExperience || '',
        languages: tp.languages || [],
        frontend: tp.frontend || [],
        databases: tp.databases || [],
        projects: (tp.projects || []).map((p) => ({
          name: p.name || '',
          description: p.description || '',
          techStack: p.techStack || '',
        })),
        remarks: tp.remarks || '',
      },
    });
  } catch (err) {
    console.error('[profile/get]', err);
    return res.status(500).json({ success: false, error: 'Failed to load profile' });
  }
});

/** PUT /api/profile/tech */
router.put('/tech', requireAuth, async (req, res) => {
  try {
    const body = req.body || {};
    const user = req.userDoc;

    user.techProfile = {
      introduction: String(body.introduction || ''),
      experienceLevel: String(body.experienceLevel || ''),
      totalExperience: String(body.totalExperience || ''),
      languages: Array.isArray(body.languages) ? body.languages.map(String) : [],
      frontend: Array.isArray(body.frontend) ? body.frontend.map(String) : [],
      databases: Array.isArray(body.databases) ? body.databases.map(String) : [],
      projects: Array.isArray(body.projects)
        ? body.projects.map((p) => ({
            name: String(p?.name || ''),
            description: String(p?.description || ''),
            techStack: String(p?.techStack || ''),
          }))
        : [],
      remarks: String(body.remarks || ''),
    };

    await user.save();

    return res.json({
      success: true,
      techProfile: {
        ...EMPTY_PROFILE,
        ...user.techProfile.toObject?.() || user.techProfile,
      },
    });
  } catch (err) {
    console.error('[profile/tech]', err);
    return res.status(500).json({ success: false, error: 'Failed to save profile' });
  }
});

export default router;
