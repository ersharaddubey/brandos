import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const providerKeySchema = new mongoose.Schema(
  {
    name: { type: String, required: true }, // groq | gemini | mistral | openai | anthropic
    key: { type: String, required: true },
    useFor: [{ type: String }], // voice | chat | screenshot
  },
  { _id: false }
);

const projectSchema = new mongoose.Schema(
  {
    name: { type: String, default: '' },
    description: { type: String, default: '' },
    techStack: { type: String, default: '' },
  },
  { _id: false }
);

const techProfileSchema = new mongoose.Schema(
  {
    introduction: { type: String, default: '' },
    experienceLevel: { type: String, default: '' },
    totalExperience: { type: String, default: '' },
    languages: [{ type: String }],
    frontend: [{ type: String }],
    databases: [{ type: String }],
    projects: [projectSchema],
    remarks: { type: String, default: '' },
  },
  { _id: false }
);

const userSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    passwordHash: { type: String, required: true },
    name: { type: String, default: '' },

    // Plan (L1 = bring-your-own-keys)
    plan: {
      tier: { type: String, default: null }, // 'L1' | null
      status: { type: String, default: 'inactive' }, // inactive | active
      termsAcceptedAt: { type: Date, default: null },
    },

    // Encrypted-at-rest ideally; for now stored as plain (user's own keys)
    assemblyaiKey: { type: String, default: null },
    providers: [providerKeySchema],

    // mode -> provider name
    providerPreferences: {
      type: Map,
      of: String,
      default: {},
    },

    techProfile: {
      type: techProfileSchema,
      default: () => ({}),
    },

    refreshTokens: [{ type: String }], // store hashed or raw jti; keep simple list of valid refresh tokens
  },
  { timestamps: true }
);

userSchema.methods.comparePassword = async function (plain) {
  return bcrypt.compare(plain, this.passwordHash);
};

userSchema.statics.hashPassword = async function (plain) {
  return bcrypt.hash(plain, 12);
};

userSchema.methods.toPublicJSON = function () {
  return {
    id: this._id.toString(),
    email: this.email,
    name: this.name,
    plan: {
      tier: this.plan?.tier || null,
      status: this.plan?.status || 'inactive',
    },
  };
};

export const User = mongoose.model('User', userSchema);
export default User;
