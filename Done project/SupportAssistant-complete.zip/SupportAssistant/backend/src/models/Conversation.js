import mongoose from 'mongoose';

const messageSchema = new mongoose.Schema(
  {
    role: { type: String, enum: ['user', 'assistant', 'system'], required: true },
    content: { type: String, required: true },
    mode: { type: String, enum: ['voice', 'chat', 'screenshot', 'system'], default: 'chat' },
    provider: { type: String, default: null },
    model: { type: String, default: null },
    // optional screenshot data URL or path (store lightly — prefer not keeping huge images long-term)
    imagePreview: { type: String, default: null },
  },
  { timestamps: true }
);

const conversationSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    title: { type: String, default: 'New conversation' },
    mode: {
      type: String,
      enum: ['voice', 'chat', 'screenshot', 'mixed'],
      default: 'mixed',
    },
    messages: [messageSchema],
  },
  { timestamps: true }
);

conversationSchema.index({ userId: 1, updatedAt: -1 });

export const Conversation = mongoose.model('Conversation', conversationSchema);
export default Conversation;
