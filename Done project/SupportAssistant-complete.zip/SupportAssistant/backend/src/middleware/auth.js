import { verifyAccessToken } from '../utils/jwt.util.js';
import { User } from '../models/User.js';

/**
 * Express middleware: requires Authorization: Bearer <accessToken>
 * Sets req.user (public user doc fields + full mongoose doc as req.userDoc)
 */
export async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const match = header.match(/^Bearer\s+(.+)$/i);
    if (!match) {
      return res.status(401).json({ success: false, error: 'Missing or invalid Authorization header' });
    }

    const token = match[1];
    let payload;
    try {
      payload = verifyAccessToken(token);
    } catch {
      return res.status(401).json({ success: false, error: 'Invalid or expired access token' });
    }

    const user = await User.findById(payload.sub);
    if (!user) {
      return res.status(401).json({ success: false, error: 'User not found' });
    }

    req.user = user.toPublicJSON();
    req.userDoc = user;
    req.tokenPayload = payload;
    next();
  } catch (err) {
    console.error('[auth middleware]', err);
    return res.status(500).json({ success: false, error: 'Auth middleware error' });
  }
}

/**
 * Optional auth — if token present and valid, attach user; otherwise continue.
 */
export async function optionalAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const match = header.match(/^Bearer\s+(.+)$/i);
  if (!match) return next();
  try {
    const payload = verifyAccessToken(match[1]);
    const user = await User.findById(payload.sub);
    if (user) {
      req.user = user.toPublicJSON();
      req.userDoc = user;
      req.tokenPayload = payload;
    }
  } catch {
    // ignore
  }
  next();
}
