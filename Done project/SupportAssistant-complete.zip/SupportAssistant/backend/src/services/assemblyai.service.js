/**
 * AssemblyAI Realtime transcription helper using the official SDK / WebSocket.
 * User supplies their own AssemblyAI API key (L1 plan).
 *
 * PCM: 16-bit mono, 16 kHz (matches frontend AudioWorklet output after resample if needed).
 * Frontend sends raw Int16 PCM binary frames.
 */

import WebSocket from 'ws';
import { EventEmitter } from 'events';

const AAI_REALTIME_URL = 'wss://api.assemblyai.com/v2/realtime/ws?sample_rate=16000';

export class AssemblyAISession extends EventEmitter {
  constructor(apiKey) {
    super();
    this.apiKey = apiKey;
    this.ws = null;
    this.ready = false;
    this.closed = false;
    this.bufferedChunks = [];
    this.MAX_BUFFERED = 50;
  }

  connect() {
    return new Promise((resolve, reject) => {
      if (this.closed) return reject(new Error('Session already closed'));

      this.ws = new WebSocket(AAI_REALTIME_URL, {
        headers: { Authorization: this.apiKey },
      });

      const timeout = setTimeout(() => {
        reject(new Error('AssemblyAI connect timeout'));
        try {
          this.ws?.close();
        } catch {
          /* ignore */
        }
      }, 15000);

      this.ws.on('open', () => {
        // wait for SessionBegins
      });

      this.ws.on('message', (raw) => {
        let data;
        try {
          data = JSON.parse(raw.toString());
        } catch {
          return;
        }

        if (data.message_type === 'SessionBegins') {
          clearTimeout(timeout);
          this.ready = true;
          // flush buffer
          for (const chunk of this.bufferedChunks) {
            this._sendAudio(chunk);
          }
          this.bufferedChunks = [];
          this.emit('ready', data);
          resolve(data);
        } else if (data.message_type === 'PartialTranscript') {
          if (data.text) this.emit('interim', data.text);
        } else if (data.message_type === 'FinalTranscript') {
          if (data.text) this.emit('final', data.text);
        } else if (data.message_type === 'SessionTerminated') {
          this.emit('terminated', data);
        } else if (data.error || data.message_type === 'error') {
          this.emit('error', new Error(data.error || data.message || 'AssemblyAI error'));
        }
      });

      this.ws.on('error', (err) => {
        clearTimeout(timeout);
        this.emit('error', err);
        reject(err);
      });

      this.ws.on('close', () => {
        this.ready = false;
        this.emit('close');
      });
    });
  }

  /** @param {Buffer|ArrayBuffer|Int16Array} pcm */
  sendAudio(pcm) {
    if (this.closed) return;
    const buf = Buffer.isBuffer(pcm) ? pcm : Buffer.from(pcm.buffer || pcm);

    if (!this.ready) {
      if (this.bufferedChunks.length < this.MAX_BUFFERED) {
        this.bufferedChunks.push(buf);
      }
      return;
    }
    this._sendAudio(buf);
  }

  _sendAudio(buf) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    // AssemblyAI expects base64-encoded PCM in JSON, OR binary depending on config.
    // v2 realtime: send JSON { audio_data: base64 }
    const b64 = buf.toString('base64');
    try {
      this.ws.send(JSON.stringify({ audio_data: b64 }));
    } catch (err) {
      this.emit('error', err);
    }
  }

  async close() {
    this.closed = true;
    this.ready = false;
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify({ terminate_session: true }));
      } catch {
        /* ignore */
      }
      await new Promise((r) => setTimeout(r, 200));
      try {
        this.ws.close();
      } catch {
        /* ignore */
      }
    }
    this.ws = null;
  }
}

export default AssemblyAISession;
