/**
 * Multi-provider AI chat completion helper.
 * Supports: groq, gemini, mistral, openai, anthropic
 * Uses user's own API keys from their plan.
 */

import { config } from '../config.js';

function buildSystemPrompt(techProfile) {
  const parts = [config.aiSystemPrefix];
  if (techProfile) {
    const bits = [];
    if (techProfile.introduction) bits.push(`About the user: ${techProfile.introduction}`);
    if (techProfile.experienceLevel) bits.push(`Experience level: ${techProfile.experienceLevel}`);
    if (techProfile.totalExperience) bits.push(`Total experience: ${techProfile.totalExperience}`);
    if (techProfile.languages?.length) bits.push(`Languages: ${techProfile.languages.join(', ')}`);
    if (techProfile.frontend?.length) bits.push(`Frontend: ${techProfile.frontend.join(', ')}`);
    if (techProfile.databases?.length) bits.push(`Databases: ${techProfile.databases.join(', ')}`);
    if (techProfile.projects?.length) {
      bits.push(
        'Projects: ' +
          techProfile.projects
            .map((p) => `${p.name}${p.techStack ? ` (${p.techStack})` : ''}`)
            .join('; ')
      );
    }
    if (techProfile.remarks) bits.push(`Notes: ${techProfile.remarks}`);
    if (bits.length) {
      parts.push('User tech profile:\n' + bits.join('\n'));
      parts.push('Tailor answers to this background when relevant.');
    }
  }
  return parts.join('\n\n');
}

function getProviderKey(userDoc, providerName) {
  const p = (userDoc.providers || []).find((x) => x.name === providerName);
  return p?.key || null;
}

function resolveProviderForMode(userDoc, mode) {
  const prefs =
    userDoc.providerPreferences instanceof Map
      ? Object.fromEntries(userDoc.providerPreferences)
      : userDoc.providerPreferences || {};
  const name = prefs[mode] || (userDoc.providers?.[0]?.name);
  if (!name) return null;
  const key = getProviderKey(userDoc, name);
  if (!key) return null;
  return { name, key };
}

/** OpenAI-compatible chat completions (Groq, Mistral, OpenAI, etc.) */
async function callOpenAICompatible({ apiKey, baseUrl, model, system, messages, imageBase64 }) {
  const msgs = [{ role: 'system', content: system }];

  for (const m of messages) {
    if (m.role === 'user' && imageBase64 && m === messages[messages.length - 1]) {
      msgs.push({
        role: 'user',
        content: [
          { type: 'text', text: m.content || 'What do you see in this screenshot? Help me solve any issue shown.' },
          {
            type: 'image_url',
            image_url: {
              url: imageBase64.startsWith('data:') ? imageBase64 : `data:image/png;base64,${imageBase64}`,
            },
          },
        ],
      });
    } else {
      msgs.push({ role: m.role, content: m.content });
    }
  }

  const res = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages: msgs,
      temperature: 0.4,
      max_tokens: 2048,
    }),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.error?.message || data?.message || `Provider error ${res.status}`;
    throw new Error(msg);
  }
  const answer = data.choices?.[0]?.message?.content || '';
  return { answer, model: data.model || model };
}

/** Google Gemini generateContent */
async function callGemini({ apiKey, model, system, messages, imageBase64 }) {
  const contents = [];
  for (const m of messages) {
    const role = m.role === 'assistant' ? 'model' : 'user';
    const parts = [{ text: m.content || '' }];
    if (imageBase64 && m === messages[messages.length - 1] && role === 'user') {
      const raw = imageBase64.replace(/^data:image\/\w+;base64,/, '');
      parts.push({
        inline_data: {
          mime_type: 'image/png',
          data: raw,
        },
      });
      if (!m.content) {
        parts[0].text = 'What do you see in this screenshot? Help me solve any issue shown.';
      }
    }
    contents.push({ role, parts });
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: system }] },
      contents,
      generationConfig: { temperature: 0.4, maxOutputTokens: 2048 },
    }),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.error?.message || `Gemini error ${res.status}`;
    throw new Error(msg);
  }
  const answer =
    data.candidates?.[0]?.content?.parts?.map((p) => p.text).join('') || '';
  return { answer, model };
}

/** Anthropic Messages API */
async function callAnthropic({ apiKey, model, system, messages, imageBase64 }) {
  const anthMsgs = [];
  for (const m of messages) {
    if (m.role === 'user' && imageBase64 && m === messages[messages.length - 1]) {
      const raw = imageBase64.replace(/^data:image\/\w+;base64,/, '');
      anthMsgs.push({
        role: 'user',
        content: [
          {
            type: 'image',
            source: { type: 'base64', media_type: 'image/png', data: raw },
          },
          {
            type: 'text',
            text: m.content || 'What do you see in this screenshot? Help me solve any issue shown.',
          },
        ],
      });
    } else {
      anthMsgs.push({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content });
    }
  }

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      max_tokens: 2048,
      system,
      messages: anthMsgs,
    }),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.error?.message || `Anthropic error ${res.status}`;
    throw new Error(msg);
  }
  const answer = data.content?.map((c) => c.text).join('') || '';
  return { answer, model: data.model || model };
}

const DEFAULT_MODELS = {
  groq: 'llama-3.3-70b-versatile',
  mistral: 'mistral-small-latest',
  openai: 'gpt-4o-mini',
  gemini: 'gemini-2.0-flash',
  anthropic: 'claude-3-5-haiku-latest',
};

const OPENAI_COMPAT_BASE = {
  groq: 'https://api.groq.com/openai/v1',
  mistral: 'https://api.mistral.ai/v1',
  openai: 'https://api.openai.com/v1',
};

/**
 * Generate an AI answer for the user.
 * @param {object} opts
 * @param {import('../models/User.js').User} opts.userDoc
 * @param {'voice'|'chat'|'screenshot'} opts.mode
 * @param {string} opts.question
 * @param {Array<{role, content}>} [opts.history]
 * @param {string} [opts.imageBase64] - data URL or raw base64 for screenshot mode
 */
export async function generateAnswer({ userDoc, mode, question, history = [], imageBase64 }) {
  if (userDoc.plan?.status !== 'active') {
    throw new Error('No active plan. Activate L1 and add your API keys first.');
  }

  const resolved = resolveProviderForMode(userDoc, mode);
  if (!resolved) {
    throw new Error(`No AI provider configured for mode "${mode}". Update plan settings.`);
  }

  const system = buildSystemPrompt(userDoc.techProfile);
  const messages = [
    ...history.slice(-12).map((h) => ({
      role: h.role === 'assistant' ? 'assistant' : 'user',
      content: h.content,
    })),
    { role: 'user', content: question || (imageBase64 ? '' : 'Hello') },
  ];

  const { name, key } = resolved;
  const model = DEFAULT_MODELS[name] || 'gpt-4o-mini';

  let result;
  if (name === 'gemini') {
    result = await callGemini({ apiKey: key, model, system, messages, imageBase64 });
  } else if (name === 'anthropic') {
    result = await callAnthropic({ apiKey: key, model, system, messages, imageBase64 });
  } else {
    const baseUrl = OPENAI_COMPAT_BASE[name];
    if (!baseUrl) throw new Error(`Unsupported provider: ${name}`);
    // Groq vision is limited; if screenshot + groq, fall back to text-only description request
    const img = name === 'groq' && imageBase64 ? null : imageBase64;
    if (name === 'groq' && imageBase64) {
      messages[messages.length - 1].content =
        (question || '') +
        '\n\n[User attached a screenshot. Describe likely UI/error and suggest fixes based on the caption if any.]';
    }
    result = await callOpenAICompatible({
      apiKey: key,
      baseUrl,
      model,
      system,
      messages,
      imageBase64: img,
    });
  }

  return {
    answer: result.answer,
    provider: name,
    model: result.model,
  };
}

export { resolveProviderForMode, getProviderKey, buildSystemPrompt };
