import express from 'express';
import cors from 'cors';
import http from 'http';
import mongoose from 'mongoose';
import { config } from './config.js';
import authRoutes from './routes/auth.routes.js';
import conversationsRoutes from './routes/conversations.routes.js';
import planRoutes from './routes/plan.routes.js';
import profileRoutes from './routes/profile.routes.js';
import aiRoutes from './routes/ai.routes.js';
import { attachWebSocketServer } from './infrastructure/websocket/server.js';

const app = express();

// Body size for screenshot base64 payloads
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

app.use(
  cors({
    origin: config.corsOrigins.includes('*') ? true : config.corsOrigins,
    credentials: true,
  })
);

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'support-assistant-backend' });
});

app.use('/api/auth', authRoutes);
app.use('/api/conversations', conversationsRoutes);
app.use('/api/plan', planRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/ai', aiRoutes);

// 404
app.use((_req, res) => {
  res.status(404).json({ success: false, error: 'Not found' });
});

// Error handler
app.use((err, _req, res, _next) => {
  console.error('[express]', err);
  if (err?.type === 'entity.too.large') {
    return res.status(413).json({ success: false, error: 'Payload too large' });
  }
  res.status(500).json({ success: false, error: 'Internal server error' });
});

async function main() {
  console.log('[db] Connecting to', config.mongoUri);
  await mongoose.connect(config.mongoUri);
  console.log('[db] Connected');

  const server = http.createServer(app);
  attachWebSocketServer(server);

  server.listen(config.port, () => {
    console.log(`[http] Support Assistant backend listening on :${config.port}`);
    console.log(`[http] REST  http://localhost:${config.port}/api`);
    console.log(`[ws]   stream ws://localhost:${config.port}/stream?token=<JWT>`);
  });
}

main().catch((err) => {
  console.error('Failed to start:', err);
  process.exit(1);
});
