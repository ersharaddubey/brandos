import dotenv from 'dotenv';
dotenv.config();

export const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  mongoUri: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/support-assistant',

  jwt: {
    accessSecret: process.env.JWT_ACCESS_SECRET || 'dev-access-secret-change-in-prod-32chars',
    refreshSecret: process.env.JWT_REFRESH_SECRET || 'dev-refresh-secret-change-in-prod-32chars',
    accessExpiry: process.env.ACCESS_TOKEN_EXPIRY || '15m',
    refreshExpiry: process.env.REFRESH_TOKEN_EXPIRY || '7d',
  },

  corsOrigins: (process.env.CORS_ORIGINS || '*')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),

  aiSystemPrefix:
    process.env.AI_SYSTEM_PREFIX ||
    'You are a helpful technical support assistant. Answer clearly and concisely based on the user\'s tech profile when available.',

  /** Max concurrent AssemblyAI realtime sessions per process */
  maxConcurrentSessions: parseInt(process.env.MAX_CONCURRENT_SESSIONS || '20', 10),

  /** Idle timeout for WS sessions (ms) */
  idleTimeoutMs: parseInt(process.env.IDLE_TIMEOUT_MS || '300000', 10), // 5 min
};

export default config;
