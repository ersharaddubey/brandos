/**
 * WebSocket /stream protocol — matches frontend systemAudioCapture.js contract.
 *
 * Connect:  ws(s)://host/stream?token=<JWT access token>
 *
 * Client -> Server (JSON):
 *   { type: 'start', mode }
 *   { type: 'respond' }   — run AI on buffered final transcript
 *   { type: 'stop' }
 * Client -> Server (binary): raw Int16 PCM
 *
 * Server -> Client (JSON):
 *   connected, ready, assembly_ready, queued, transcript_interim,
 *   transcript_final, processing, answer, error, idle_timeout, stopped
 *   + conversationId on ready/answer when available
 */

import { WebSocketServer } from 'ws';
import { v4 as uuidv4 } from 'uuid';
import { verifyAccessToken } from '../../utils/jwt.util.js';
import { User } from '../../models/User.js';
import { Conversation } from '../../models/Conversation.js';
import { AssemblyAISession } from '../../services/assemblyai.service.js';
import { generateAnswer } from '../../services/ai.service.js';
import { config } from '../../config.js';

let activeSessions = 0;

function send(ws, obj) {
  if (ws.readyState === 1) {
    ws.send(JSON.stringify(obj));
  }
}

export function attachWebSocketServer(httpServer) {
  const wss = new WebSocketServer({ server: httpServer, path: '/stream' });

  wss.on('connection', async (ws, req) => {
    const sessionId = uuidv4();
    let userDoc = null;
    let aai = null;
    let conversation = null;
    let mode = 'default';
    let finalBuffer = '';
    let lastActivity = Date.now();
    let idleTimer = null;
    let started = false;

    const touch = () => {
      lastActivity = Date.now();
    };

    const resetIdle = () => {
      if (idleTimer) clearInterval(idleTimer);
      idleTimer = setInterval(() => {
        if (Date.now() - lastActivity > config.idleTimeoutMs) {
          send(ws, {
            type: 'idle_timeout',
            message: 'Session closed due to inactivity',
          });
          cleanup();
          try {
            ws.close();
          } catch {
            /* ignore */
          }
        }
      }, 30000);
    };

    const cleanup = async () => {
      if (idleTimer) clearInterval(idleTimer);
      idleTimer = null;
      if (aai) {
        try {
          await aai.close();
        } catch {
          /* ignore */
        }
        aai = null;
        activeSessions = Math.max(0, activeSessions - 1);
      }
    };

    // Auth from query token
    try {
      const url = new URL(req.url || '', `http://${req.headers.host}`);
      const token = url.searchParams.get('token');
      if (!token) {
        send(ws, { type: 'error', message: 'Missing token query param' });
        ws.close();
        return;
      }
      const payload = verifyAccessToken(token);
      userDoc = await User.findById(payload.sub);
      if (!userDoc) {
        send(ws, { type: 'error', message: 'User not found' });
        ws.close();
        return;
      }
    } catch (err) {
      send(ws, { type: 'error', message: 'Invalid or expired token' });
      ws.close();
      return;
    }

    send(ws, { type: 'connected', sessionId });
    resetIdle();

    ws.on('message', async (data, isBinary) => {
      touch();

      if (isBinary) {
        if (aai && started) {
          aai.sendAudio(data);
        }
        return;
      }

      let msg;
      try {
        msg = JSON.parse(data.toString());
      } catch {
        return;
      }

      if (msg.type === 'start') {
        if (started) return;
        mode = msg.mode || 'default';

        if (userDoc.plan?.status !== 'active' || !userDoc.assemblyaiKey) {
          send(ws, {
            type: 'error',
            message: 'Active plan with AssemblyAI key required for voice mode',
          });
          return;
        }

        if (activeSessions >= config.maxConcurrentSessions) {
          send(ws, {
            type: 'queued',
            position: activeSessions - config.maxConcurrentSessions + 1,
            message: 'Waiting for a free transcription slot…',
          });
          // Simple wait-and-retry once
          await new Promise((r) => setTimeout(r, 2000));
          if (activeSessions >= config.maxConcurrentSessions) {
            send(ws, { type: 'error', message: 'Server busy — try again shortly' });
            return;
          }
        }

        // Create shared conversation for this voice session
        conversation = await Conversation.create({
          userId: userDoc._id,
          title: 'Voice session',
          mode: 'voice',
          messages: [],
        });

        try {
          aai = new AssemblyAISession(userDoc.assemblyaiKey);
          activeSessions += 1;

          aai.on('interim', (text) => {
            send(ws, { type: 'transcript_interim', transcript: text });
          });
          aai.on('final', (text) => {
            finalBuffer = (finalBuffer + ' ' + text).trim();
            send(ws, { type: 'transcript_final', transcript: text });
          });
          aai.on('error', (err) => {
            send(ws, { type: 'error', message: err.message || 'Transcription error' });
          });

          await aai.connect();
          started = true;

          send(ws, { type: 'ready' });
          send(ws, { type: 'assembly_ready' });
          // Frontend listens for type: 'conversation_id' (underscore)
          send(ws, {
            type: 'conversation_id',
            conversationId: conversation._id.toString(),
          });
        } catch (err) {
          activeSessions = Math.max(0, activeSessions - 1);
          aai = null;
          send(ws, {
            type: 'error',
            message: err.message || 'Failed to start AssemblyAI session',
          });
        }
        return;
      }

      if (msg.type === 'respond') {
        if (!finalBuffer.trim()) {
          send(ws, { type: 'error', message: 'No transcript to answer yet' });
          return;
        }

        const question = finalBuffer.trim();
        finalBuffer = '';
        send(ws, { type: 'processing' });

        try {
          // Refresh user doc for latest keys/profile
          userDoc = await User.findById(userDoc._id);

          if (!conversation) {
            conversation = await Conversation.create({
              userId: userDoc._id,
              title: question.slice(0, 80),
              mode: 'voice',
              messages: [],
            });
          }

          const history = (conversation.messages || []).map((m) => ({
            role: m.role,
            content: m.content,
          }));

          const { answer, provider, model } = await generateAnswer({
            userDoc,
            mode: 'voice',
            question,
            history,
          });

          conversation.messages.push(
            { role: 'user', content: question, mode: 'voice' },
            { role: 'assistant', content: answer, mode: 'voice', provider, model }
          );
          if (conversation.title === 'Voice session') {
            conversation.title = question.slice(0, 80);
          }
          await conversation.save();

          send(ws, {
            type: 'answer',
            answer,
            question,
            provider,
            model,
            conversationId: conversation._id.toString(),
          });
        } catch (err) {
          send(ws, { type: 'error', message: err.message || 'AI answer failed' });
        }
        return;
      }

      if (msg.type === 'stop') {
        send(ws, { type: 'stopped' });
        await cleanup();
        try {
          ws.close();
        } catch {
          /* ignore */
        }
      }
    });

    ws.on('close', () => {
      cleanup();
    });

    ws.on('error', () => {
      cleanup();
    });
  });

  console.log('[ws] WebSocket server attached at path /stream');
  return wss;
}

export default attachWebSocketServer;
