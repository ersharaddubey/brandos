# Support Assistant — Backend

Node.js (Express) + MongoDB + WebSocket backend that matches the Electron/React frontend in `call/server` (Vite UI) and `call/client`.

## Features

| Area | Endpoints / path |
|------|------------------|
| Auth | `POST /api/auth/register`, `login`, `refresh`, `logout` · `GET /api/auth/me` |
| Plan (L1 BYOK) | `GET /api/plan` · `POST /api/plan/activate-l1` · `PATCH /api/plan/providers` · `PATCH /api/plan/keys` |
| Profile | `GET /api/profile` · `PUT /api/profile/tech` |
| Conversations | `GET /api/conversations` · `GET /api/conversations/:id` |
| AI | `POST /api/ai/text` · `POST /api/ai/screenshot` |
| Voice | `WS /stream?token=<accessJWT>` (AssemblyAI realtime + AI answer) |

Users bring their own keys (AssemblyAI + Groq / Gemini / Mistral / OpenAI / Anthropic).

## Quick start

```bash
# 1. MongoDB running locally (or set MONGODB_URI)
# 2. Install
cd backend
cp .env.example .env
npm install

# 3. Run
npm run dev
# → http://localhost:3000
# → ws://localhost:3000/stream
```

### Frontend local env

In `call/server/.env` (Vite frontend):

```
VITE_API_BASE=http://localhost:3000
VITE_WS_URL=ws://localhost:3000/stream
```

Restart Vite after changing env.

## WebSocket protocol (voice)

1. Connect: `ws://host/stream?token=<accessToken>`
2. Client sends `{ "type": "start", "mode": "default" }`
3. Server replies `connected` → `ready` (+ `conversationId`) → `assembly_ready`
4. Client streams **binary Int16 PCM** (16 kHz mono recommended)
5. Server emits `transcript_interim` / `transcript_final`
6. Client sends `{ "type": "respond" }` → server `processing` → `answer`
7. Client sends `{ "type": "stop" }` → `stopped`

## Activate plan (example)

```bash
# After register/login, with access token:
curl -X POST http://localhost:3000/api/plan/activate-l1 \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "assemblyaiKey": "YOUR_AAI_KEY",
    "providers": [
      { "name": "groq", "key": "gsk_...", "useFor": ["voice", "chat"] },
      { "name": "gemini", "key": "AIza...", "useFor": ["screenshot"] }
    ],
    "termsAccepted": true
  }'
```

## Project layout

```
backend/
  package.json
  .env.example
  src/
    index.js
    config.js
    models/          User, Conversation
    routes/          auth, plan, profile, conversations, ai
    middleware/      auth.js
    services/        ai.service.js, assemblyai.service.js
    infrastructure/websocket/server.js
    utils/jwt.util.js
```

## Production notes

- Set strong `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET`
- Use TLS (reverse proxy) so frontend can use `https://` + `wss://`
- Prefer encrypting stored API keys at rest (KMS / app-level encryption)
- Tune `MAX_CONCURRENT_SESSIONS` for AssemblyAI rate limits
