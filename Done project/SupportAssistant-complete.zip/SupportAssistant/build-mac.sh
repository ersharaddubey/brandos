#!/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "==> 1/5 Frontend install + build"
cd "$ROOT/call/server"
npm install --no-audit --no-fund
npm run build

echo "==> 2/5 Copy dist -> client/frontend"
rm -rf "$ROOT/call/client/frontend"
mkdir -p "$ROOT/call/client/frontend"
cp -r dist/* "$ROOT/call/client/frontend/"
sed -i.bak 's|href="/favicon.svg"|href="./favicon.svg"|g; s|src="/assets/|src="./assets/|g; s|href="/assets/|href="./assets/|g' "$ROOT/call/client/frontend/index.html" 2>/dev/null || true
rm -f "$ROOT/call/client/frontend/index.html.bak"

echo "==> 3/5 Electron install (Electron 33 — Mac system-audio loopback ke liye)"
cd "$ROOT/call/client"
rm -rf node_modules/electron
npm install --no-audit --no-fund

echo "==> 4/5 Build Mac arm64 (ad-hoc signed via sign-adhoc.js)"
rm -rf dist
npx electron-builder --mac --arm64 --publish never

echo "==> 5/5 Purani/stale permissions reset (har rebuild ke baad zaruri)"
tccutil reset ScreenCapture com.supportassistant.app || true
tccutil reset Microphone    com.supportassistant.app || true
tccutil reset All           com.supportassistant.app || true
xattr -cr "dist/mac-arm64/Support Assistant.app" || true

echo ""
echo "✅ Done. Ab chalao:"
echo "  open \"$ROOT/call/client/dist/mac-arm64/Support Assistant.app\""
echo "Permission prompts aaye to Allow karo, phir app Cmd+Q karke ek baar dobara kholo."
