import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function RecycleBin() {
  const [list, setList] = useState([]);
  const [err, setErr] = useState('');
  const [msg, setMsg] = useState('');

  const load = () => api.recycle.list().then(setList).catch((e) => setErr(e.message));
  useEffect(() => {
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, []);

  const hoursLeft = (expiresAt) => {
    const ms = new Date(expiresAt) - Date.now();
    if (ms <= 0) return 'expiring…';
    const h = Math.floor(ms / 3600000);
    const m = Math.floor((ms % 3600000) / 60000);
    return `${h}h ${m}m left`;
  };

  const permanent = async (id) => {
    if (!confirm('Permanently delete this item? This cannot be undone.')) return;
    await api.recycle.remove(id);
    setMsg('Permanently deleted.');
    load();
  };

  const empty = async () => {
    if (!confirm('Empty the entire Recycle Bin permanently?')) return;
    const r = await api.recycle.empty();
    setMsg(`Emptied (${r.removed || 0} items).`);
    load();
  };

  return (
    <>
      <h1>Recycle Bin</h1>
      <p className="sub">
        Items from deleted groups stay here for 24 hours. Permanent delete removes them now. Otherwise they auto-remove after the timer.
      </p>
      {err && <div className="err">{err}</div>}
      {msg && <div className="ok">{msg}</div>}

      <div className="row" style={{ marginBottom: 14 }}>
        <button type="button" className="ghost" onClick={load}>
          Refresh
        </button>
        {list.length > 0 && (
          <button type="button" className="danger" onClick={empty}>
            Empty bin
          </button>
        )}
      </div>

      <div className="grid grid-4">
        {list.map((item) => {
          const snap = item.snapshot || {};
          const url = snap.url || (snap.filename ? `/uploads/${snap.filename}` : null);
          return (
            <div className="card" key={item._id}>
              {url ? (
                <img className="thumb" src={url} alt="" />
              ) : (
                <div className="thumb" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)' }}>
                  {item.kind}
                </div>
              )}
              <div className="row" style={{ marginTop: 8 }}>
                <span className="badge">{item.kind}</span>
                <span className="badge warn">{hoursLeft(item.expiresAt)}</span>
              </div>
              <div className="muted small" style={{ marginTop: 6 }}>
                {item.reason || 'deleted'} · {new Date(item.createdAt).toLocaleString()}
              </div>
              <div className="row" style={{ marginTop: 8 }}>
                <button type="button" className="danger" onClick={() => permanent(item._id)}>
                  Delete permanently
                </button>
              </div>
            </div>
          );
        })}
        {!list.length && <p className="muted">Recycle Bin is empty.</p>}
      </div>
    </>
  );
}
