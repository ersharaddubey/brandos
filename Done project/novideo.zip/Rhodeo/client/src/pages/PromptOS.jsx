import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { TourProvider, GuideBar, Tip, EmptyHint, useTour } from '../components/Help.jsx';

const DEFAULT_BODY = `Create a campaign image.

IDENTITY (keep exactly consistent with the reference):
{{identity}}

ENVIRONMENT: {{environment}}
CAMPAIGN GOAL: {{goal}}
SCENE: {{scene}}
COMPOSITION: {{composition}}
STYLE: {{style}}`;

const DUMMY_PROMPTS = [
  {
    name: 'Hero product shot',
    tags: 'product,hero,ecommerce',
    body: `Professional product photography of {{identity}}.

SCENE: {{scene}}
COMPOSITION: {{composition}}
STYLE: {{style}}
GOAL: {{goal}}

Keep materials, logo placement, and proportions exactly as the locked identity.
Lighting: soft studio key light, subtle rim. Background clean and uncluttered.
Avoid: {{avoid}}`,
  },
  {
    name: 'Lifestyle character',
    tags: 'character,lifestyle,social',
    body: `Photoreal portrait of {{identity}} in a natural setting.

SCENE: {{scene}}
COMPOSITION: {{composition}}
STYLE: {{style}}
GOAL: {{goal}}

Preserve exact face shape, hair, glasses, and signature details from the identity lock.
Warm natural light, shallow depth of field, editorial mood.
Avoid: {{avoid}}`,
  },
  {
    name: 'Brand environment',
    tags: 'environment,brand,campaign',
    body: `Wide establishing shot of {{identity}} as the hero environment.

SCENE: {{scene}}
COMPOSITION: {{composition}}
STYLE: {{style}}
GOAL: {{goal}}

Match architecture, materials, and lighting language of the locked environment identity.
Cinematic color grade, high detail, no people unless specified.
Avoid: {{avoid}}`,
  },
];

function Diff({ a = '', b = '' }) {
  const other = new Set(b.split('\n'));
  return <pre>{a.split('\n').map((l, i) => <span key={i} className={'diffline' + (other.has(l) ? '' : ' chg')}>{l || ' '}</span>)}</pre>;
}

const TOUR_STEPS = [
  {
    selector: '[data-tour="pos-saved"]',
    title: '1. Saved prompts (left)',
    body: 'All of your private templates list here. Click to open. If empty, use Fill dummy prompts for three examples.',
    why: '“Prompts = reusable creative assets.”',
  },
  {
    selector: '[data-tour="pos-new"]',
    title: '2. New prompt',
    body: 'Name + tags + template body. Variables like {{identity}} {{scene}} {{goal}} are filled in Studio.',
    why: '“One structure for every campaign.”',
  },
  {
    selector: '[data-tour="pos-detail"]',
    title: '3. Edit & versions',
    body: 'Right side pe body edit → Save new version. Purani versions history me rehti hain; compare karke current set karo.',
    why: '“Kabhi bhi peechhe rollback.”',
  },
];

function PromptOSInner() {
  const [list, setList] = useState([]);
  const [sel, setSel] = useState(null);
  const [draft, setDraft] = useState({ name: '', body: DEFAULT_BODY, tags: '' });
  const [edit, setEdit] = useState({ body: '', note: '' });
  const [cmp, setCmp] = useState({ a: '', b: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const load = async (keep) => {
    const l = await api.prompts.list('?visibility=private');
    setList(l);
    const cur = l.find((p) => p._id === (keep || sel?._id));
    if (cur) pick(cur);
  };
  const pick = (p) => {
    setSel(p);
    const v = p.versions.find((x) => x.version === p.currentVersion);
    setEdit({ body: v?.body || '', note: '' });
    setCmp({ a: String(Math.max(1, p.currentVersion - 1)), b: String(p.currentVersion) });
  };
  useEffect(() => { load().catch((e) => setErr(e.message)); }, []);

  const guard = (fn) => async () => {
    setErr('');
    setBusy(true);
    try { await fn(); } catch (e) { setErr(e.message); }
    setBusy(false);
  };
  const create = guard(async () => {
    const p = await api.prompts.create({
      name: draft.name,
      body: draft.body,
      tags: draft.tags.split(',').map((t) => t.trim()).filter(Boolean),
    });
    setDraft({ name: '', body: DEFAULT_BODY, tags: '' });
    await load(p._id);
  });
  const saveVersion = guard(async () => {
    const p = await api.prompts.addVersion(sel._id, edit);
    await load(p._id);
  });
  const remove = guard(async () => {
    if (!confirm('Delete prompt?')) return;
    await api.prompts.remove(sel._id);
    setSel(null);
    await load();
  });
  const makePublic = guard(async () => {
    await api.prompts.setVisibility(sel._id, 'public');
    await load(sel._id);
  });
  const setCurrent = (v) => guard(async () => {
    await api.prompts.setCurrent(sel._id, v);
    await load(sel._id);
  })();

  /** One click: 3 example templates create + first select */
  const fillDummy = guard(async () => {
    let last = null;
    for (const d of DUMMY_PROMPTS) {
      const existing = list.find((p) => p.name === d.name);
      if (existing) {
        last = existing;
        continue;
      }
      last = await api.prompts.create({
        name: d.name,
        body: d.body,
        tags: d.tags.split(',').map((t) => t.trim()),
      });
    }
    await load(last?._id);
  });

  /** Fill only the “New prompt” form fields (no API) */
  const fillDraftDummy = () => {
    setDraft({
      name: 'Social square promo',
      tags: 'social,1:1,promo',
      body: DEFAULT_BODY + '\n\nAspect: 1:1. High sharpness, no watermark, no extra text.',
    });
  };

  const va = sel?.versions.find((v) => v.version === Number(cmp.a));
  const vb = sel?.versions.find((v) => v.version === Number(cmp.b));

  return (
    <>
      <h1>Prompt OS</h1>
      <p className="sub">
        Prompts = reusable creative assets. Variables:{' '}
        <code>{'{{identity}} {{environment}} {{goal}} {{scene}} {{composition}} {{style}} {{avoid}}'}</code>
      </p>
      <GuideBar onDummy={fillDummy} dummyLabel="Fill dummy prompts (3 examples)" />
      {err && <div className="err">{err}</div>}

      <div className="two" style={{ gridTemplateColumns: '300px 1fr' }}>
        <div>
          <div className="card" data-tour="pos-saved">
            <h2>Saved prompts <Tip id="pos.saved" /></h2>
            {list.map((p) => (
              <div
                key={p._id}
                className={'card selectable' + (sel?._id === p._id ? ' on' : '')}
                style={{ padding: 10, marginBottom: 8 }}
                onClick={() => pick(p)}
              >
                <b>{p.name}</b>
                <div className="muted small">
                  v{p.currentVersion} · {p.versions.length} version(s){' '}
                  {p.tags.map((t) => (
                    <span className="badge" key={t} style={{ marginLeft: 4 }}>{t}</span>
                  ))}
                </div>
              </div>
            ))}
            {!list.length && (
              <p className="muted small">
                No prompts yet. Use Fill dummy prompts or create one under New prompt.
              </p>
            )}
          </div>

          <div className="card" data-tour="pos-new">
            <h2>New prompt <Tip id="pos.new" /></h2>
            <div className="row" style={{ marginBottom: 8 }}>
              <button type="button" className="ghost dummy-btn" onClick={fillDraftDummy}>
                Fill form dummy
              </button>
            </div>
            <label>Name</label>
            <input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="e.g. Hero product shot" />
            <label>Tags (comma separated)</label>
            <input value={draft.tags} onChange={(e) => setDraft({ ...draft, tags: e.target.value })} placeholder="product, hero" />
            <label>Template</label>
            <textarea style={{ minHeight: 160 }} value={draft.body} onChange={(e) => setDraft({ ...draft, body: e.target.value })} />
            <div className="row" style={{ marginTop: 12 }}>
              <button disabled={!draft.name || !draft.body || busy} onClick={create}>Create</button>
            </div>
          </div>
        </div>

        <div data-tour="pos-detail">
          {!sel ? (
            <EmptyHint
              title="Left se prompt select karo"
              body="Choose a template from the list, or create three examples with Fill dummy prompts. After select you can edit, view history, and compare versions."
              why="“Empty screen confuse na kare — pehla step clear ho.”"
            >
              <Tip id="pos.empty" />
              <div className="row" style={{ marginTop: 12 }}>
                <button type="button" className="ghost dummy-btn" onClick={fillDummy} disabled={busy}>
                  Fill dummy prompts
                </button>
              </div>
            </EmptyHint>
          ) : (
            <>
              <div className="card">
                <div className="row" style={{ justifyContent: 'space-between' }}>
                  <h2>
                    {sel.name} <span className="badge good">current v{sel.currentVersion}</span>{' '}
                    <Tip id="pos.edit" />
                  </h2>
                  <div className="row">
                    <button className="ghost" onClick={makePublic}>Move to Open Shelf</button>
                    <button className="danger" onClick={remove}>Delete</button>
                  </div>
                </div>
                <label>Edit (saves as a new version)</label>
                <textarea style={{ minHeight: 200 }} value={edit.body} onChange={(e) => setEdit({ ...edit, body: e.target.value })} />
                <label>Version note</label>
                <input value={edit.note} onChange={(e) => setEdit({ ...edit, note: e.target.value })} placeholder="what changed?" />
                <div className="row" style={{ marginTop: 12 }}>
                  <button onClick={saveVersion} disabled={busy}>Save new version</button>
                </div>
              </div>
              <div className="card">
                <h2>History & comparison <Tip id="pos.history" /></h2>
                <div className="row">
                  {sel.versions.map((v) => (
                    <button
                      key={v.version}
                      className={v.version === sel.currentVersion ? '' : 'ghost'}
                      title={v.note || ''}
                      onClick={() => setCurrent(v.version)}
                    >
                      v{v.version}
                    </button>
                  ))}
                  <span className="muted small">(click = make current)</span>
                </div>
                <div className="row" style={{ margin: '12px 0' }}>
                  <span className="muted">Compare</span>
                  <select style={{ width: 90 }} value={cmp.a} onChange={(e) => setCmp({ ...cmp, a: e.target.value })}>
                    {sel.versions.map((v) => <option key={v.version}>{v.version}</option>)}
                  </select>
                  <span className="muted">vs</span>
                  <select style={{ width: 90 }} value={cmp.b} onChange={(e) => setCmp({ ...cmp, b: e.target.value })}>
                    {sel.versions.map((v) => <option key={v.version}>{v.version}</option>)}
                  </select>
                </div>
                <div className="two">
                  <div>
                    <div className="muted small">v{cmp.a} {va?.note && `· ${va.note}`}</div>
                    <Diff a={va?.body} b={vb?.body} />
                  </div>
                  <div>
                    <div className="muted small">v{cmp.b} {vb?.note && `· ${vb.note}`}</div>
                    <Diff a={vb?.body} b={va?.body} />
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}

export default function PromptOS() {
  return (
    <TourProvider steps={TOUR_STEPS}>
      <PromptOSInner />
    </TourProvider>
  );
}
