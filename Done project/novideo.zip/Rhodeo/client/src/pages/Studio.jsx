import { useEffect, useState } from 'react';
import { api } from '../api.js';
import PromptView from '../components/PromptView.jsx';
import { TourProvider, GuideBar, Tip, EmptyHint } from '../components/Help.jsx';
import CreateGroup from '../components/CreateGroup.jsx';

const scoreClass = (s) => (s == null ? '' : s >= 75 ? 'good' : s >= 50 ? 'warn' : 'bad');

const DUMMY_FORM = {
  campaignName: 'Summer Launch 2026',
  goal: 'Instagram carousel hero for summer product drop',
  scene: 'Sunlit rooftop terrace, soft morning haze, city skyline soft in background',
  composition: 'Centered hero product, eye-level, shallow depth of field, 50mm feel',
  style: 'Clean premium commercial, warm tones, high detail, subtle film grain',
  templateId: '',
  aspectRatio: '4:5',
  avoid: 'crowd, text overlay, harsh shadows, watermark, distorted logo',
  maxAttempts: 3,
  threshold: 75,
};

const TOUR_STEPS = [
  {
    selector: '[data-tour="studio-ids"]',
    title: '1. Locked identities',
    body: 'Only LOCKED identities appear here. Select them so the generator receives reference images for consistency.',
    why: '“Without identity lock there is no consistency guarantee.”',
  },
  {
    selector: '[data-tour="studio-brief"]',
    title: '2. Campaign brief',
    body: 'Goal, scene, composition, and style go into the final prompt. Use Fill dummy data for example values.',
    why: '“Same identity, different campaign — change only the brief.”',
  },
  {
    selector: '[data-tour="studio-actions"]',
    title: '3. Get prompt / Generate',
    body: 'Get prompt = copy-paste JSON + paragraph. Generate here = create the image on this server (mock or Flux).',
    why: '“Prompt copy is free; generation is optional.”',
  },
];

function StudioInner() {
  const [ids, setIds] = useState([]);
  const [prompts, setPrompts] = useState([]);
  const [past, setPast] = useState([]);
  const [sel, setSel] = useState([]);
  const [form, setForm] = useState({
    campaignName: '', goal: '', scene: '', composition: '', style: '',
    templateId: '', aspectRatio: '', avoid: '', maxAttempts: 3, threshold: 75,
  });
  const [compiled, setCompiled] = useState(null);
  const [active, setActive] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const loadPast = () => api.generations.list().then(setPast).catch(() => {});
  useEffect(() => {
    api.identities.list('?status=locked').then(setIds).catch((e) => setErr(e.message));
    api.prompts.list().then(setPrompts);
    loadPast();
  }, []);

  useEffect(() => {
    if (!active || !['running', 'queued'].includes(active.status)) return;
    const t = setInterval(async () => {
      try {
        const g = await api.generations.get(active._id);
        setActive(g);
        if (!['running', 'queued'].includes(g.status)) { clearInterval(t); loadPast(); }
      } catch (e) { setErr(e.message); }
    }, 2500);
    return () => clearInterval(t);
  }, [active?._id, active?.status]);

  const toggle = (id) => setSel((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const fillDummy = () => {
    setForm({ ...DUMMY_FORM, templateId: prompts[0]?._id || '' });
    if (ids.length && !sel.length) setSel([ids[0]._id]);
  };

  const go = async () => {
    setErr(''); setBusy(true);
    try {
      const g = await api.generations.create({ ...form, identityIds: sel });
      setActive(await api.generations.get(g._id));
    } catch (e) { setErr(e.message); }
    setBusy(false);
  };

  const compilePrompt = async () => {
    setErr(''); setBusy(true);
    try { setCompiled(await api.compile({ ...form, identityIds: sel })); }
    catch (e) { setErr(e.message); }
    setBusy(false);
  };

  return (
    <>
      <h1>Studio</h1>
      <p className="sub">Identity + Campaign + Environment + Style + Composition → Generate → Check → Auto-improve</p>
      <div style={{ marginBottom: 12 }}><CreateGroup visibility="private" onCreated={() => {}} compact /></div>
      <GuideBar onDummy={fillDummy} dummyLabel="Fill dummy campaign data" />
      {err && <div className="err">{err}</div>}

      <div className="card" data-tour="studio-ids">
        <h2>1. Locked identities <Tip id="studio.ids" /></h2>
        {!ids.length && (
          <EmptyHint
            title="Pehle Identity Lock karo"
            body="Identity Lock page pe reference upload → analyse → Lock. Tabhi yahan dikhegi."
            why="“Unlocked draft generate loop me nahi jaati — consistency ke liye lock zaroori.”"
          />
        )}
        <div className="grid">
          {ids.map((i) => (
            <div
              key={i._id}
              className={'card selectable' + (sel.includes(i._id) ? ' on' : '')}
              style={{ marginBottom: 0 }}
              onClick={() => toggle(i._id)}
            >
              {i.referenceAssetIds[0] && <img className="thumb" src={i.referenceAssetIds[0].url} alt="" />}
              <div style={{ marginTop: 8 }}><b>{i.name}</b> <span className="muted small">{i.type}</span></div>
            </div>
          ))}
        </div>
      </div>

      <div className="card" data-tour="studio-brief">
        <h2>2. Campaign brief <Tip id="studio.brief" /></h2>
        <div className="two">
          <div>
            <label>Campaign name (optional, Asset Bank mein group hoga)</label>
            <input value={form.campaignName} onChange={set('campaignName')} placeholder="Summer Launch 2026" />
          </div>
          <div>
            <label>Prompt template (optional)</label>
            <select value={form.templateId} onChange={set('templateId')}>
              <option value="">default structure</option>
              {prompts.map((p) => (
                <option key={p._id} value={p._id}>{p.name} (v{p.currentVersion})</option>
              ))}
            </select>
          </div>
        </div>
        <label>Campaign goal</label>
        <input value={form.goal} onChange={set('goal')} placeholder="Summer launch social creative" />
        <label>Scene</label>
        <textarea value={form.scene} onChange={set('scene')} placeholder="On a sunlit rooftop, morning haze" />
        <div className="two">
          <div>
            <label>Composition</label>
            <input value={form.composition} onChange={set('composition')} placeholder="Centered hero shot, shallow depth of field" />
          </div>
          <div>
            <label>Style</label>
            <input value={form.style} onChange={set('style')} placeholder="Clean, premium, warm tones" />
          </div>
        </div>
        <div className="two">
          <div>
            <label>Aspect ratio</label>
            <select value={form.aspectRatio} onChange={set('aspectRatio')}>
              <option value="">from reference</option>
              {['1:1', '4:5', '3:4', '9:16', '16:9'].map((a) => <option key={a}>{a}</option>)}
            </select>
          </div>
          <div>
            <label>Avoid (comma separated, optional)</label>
            <input value={form.avoid} onChange={set('avoid')} placeholder="crowd, text overlay, harsh shadows" />
          </div>
        </div>
        <div className="two">
          <div>
            <label>Max attempts (auto-improve loop)</label>
            <input type="number" min="1" max="6" value={form.maxAttempts} onChange={set('maxAttempts')} />
          </div>
          <div>
            <label>Pass threshold (consistency score)</label>
            <input type="number" min="1" max="100" value={form.threshold} onChange={set('threshold')} />
          </div>
        </div>
        <div className="row" style={{ marginTop: 14 }} data-tour="studio-actions">
          <button disabled={!sel.length || busy} onClick={compilePrompt}>
            Get prompt (JSON + paragraph)
          </button>
          <button className="ghost" disabled={!sel.length || busy || ['running', 'queued'].includes(active?.status)} onClick={go}>
            {['running', 'queued'].includes(active?.status) ? 'Generating...' : 'Generate here (needs generator)'}
          </button>
          <Tip id="studio.actions" />
        </div>
      </div>

      <PromptView result={compiled} title="Prompt for your campaign" />

      {active && <Result gen={active} />}

      {past.length > 0 && (
        <div className="card">
          <h2>Recent generations</h2>
          {past.map((g) => (
            <div key={g._id} className="row" style={{ justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid var(--line)' }}>
              <span>{g.inputs?.goal || g.inputs?.scene || 'Untitled'} <span className="muted small">{g.campaignId?.name}</span></span>
              <span className="row">
                <span className={'badge ' + g.status}>{g.status}</span>
                <button className="ghost" onClick={() => setActive(g)}>Open</button>
              </span>
            </div>
          ))}
        </div>
      )}
    </>
  );
}

function Result({ gen }) {
  return (
    <div className="card">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>Result</h2>
        <span className={'badge ' + gen.status}>{gen.status}{['running', 'queued'].includes(gen.status) && ' ...'}</span>
      </div>
      {gen.error && <div className="err">{gen.error}</div>}
      {['running', 'queued'].includes(gen.status) && <div style={{ margin: '10px 0' }}><div className="row" style={{ justifyContent: 'space-between' }}><span className="muted small">{gen.currentStep || 'Working...'}</span><b>{gen.progress || 0}%</b></div><div style={{ height: 6, borderRadius: 99, background: 'var(--line)', overflow: 'hidden' }}><div style={{ height: '100%', width: `${Math.max(0, Math.min(100, gen.progress || 0))}%`, background: 'var(--good)', transition: 'width .3s' }} /></div></div>}
      <div className="grid big">
        {gen.attempts.map((a) => (
          <div className="card" key={a.n} style={{ marginBottom: 0, borderColor: gen.bestAttempt === a.n ? 'var(--good)' : undefined }}>
            {a.assetId && <img className="thumb" src={a.assetId.url} alt={`attempt ${a.n}`} />}
            <div className="row" style={{ margin: '8px 0', justifyContent: 'space-between' }}>
              <b>Attempt {a.n}{gen.bestAttempt === a.n && ' · best'}</b>
              <span className="muted small">{a.width && a.height ? `${a.width}×${a.height}` : ''}{a.seed != null ? ` · seed ${a.seed}` : ''}</span>
              <span className={'badge ' + scoreClass(a.score)}>{a.score == null ? 'unchecked' : `score ${a.score}`}</span>
            </div>
            {a.checks?.map((c) => <div className="small muted" key={c.name}>{c.name}: {c.score}</div>)}
            {a.error && <div className="small" style={{ color: 'var(--bad)' }}>{a.error}</div>}
            {a.note && <div className="small muted">{a.note}</div>}
            {a.mismatches?.length > 0 && <ul className="plain small">{a.mismatches.map((m, i) => <li key={i}>{m}</li>)}</ul>}
            <details><summary>prompt used</summary><pre>{a.prompt}</pre></details>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Studio() {
  return (
    <TourProvider steps={TOUR_STEPS}>
      <StudioInner />
    </TourProvider>
  );
}
