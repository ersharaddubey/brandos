import { Router } from 'express';
import RecycleBin from '../models/RecycleBin.js';
import Asset from '../models/Asset.js';
import { wrap } from '../middleware/common.js';
import { removeAssetFile } from '../services/assets.js';

const r = Router();

r.get('/', wrap(async (req, res) => {
  const now = new Date();
  res.json(await RecycleBin.find({ expiresAt: { $gt: now } }).sort('-createdAt').limit(200));
}));

/** Permanent delete one recycle entry */
r.delete('/:id', wrap(async (req, res) => {
  const item = await RecycleBin.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ error: 'Not found' });
  // If snapshot still has a file on disk for assets, try remove
  if (item.kind === 'asset' && item.snapshot?.filename) {
    await removeAssetFile(item.snapshot).catch(() => {});
  }
  res.json({ ok: true });
}));

/** Empty entire bin (permanent) */
r.delete('/', wrap(async (req, res) => {
  const items = await RecycleBin.find();
  for (const item of items) {
    if (item.kind === 'asset' && item.snapshot?.filename) {
      await removeAssetFile(item.snapshot).catch(() => {});
    }
  }
  await RecycleBin.deleteMany({});
  res.json({ ok: true, removed: items.length });
}));

/** Restore asset from bin to private Asset Bank */
r.post('/:id/restore', wrap(async (req, res) => {
  const item = await RecycleBin.findById(req.params.id);
  if (!item) return res.status(404).json({ error: 'Not found' });
  if (item.kind !== 'asset') {
    return res.status(400).json({ error: 'Only assets can be restored this way' });
  }
  const snap = item.snapshot || {};
  // Re-create asset record if file still exists conceptually — mark private
  if (snap._id) {
    const existing = await Asset.findById(snap._id);
    if (existing) {
      existing.visibility = 'private';
      await existing.save();
      await RecycleBin.findByIdAndDelete(item._id);
      return res.json(existing);
    }
  }
  await RecycleBin.findByIdAndDelete(item._id);
  res.json({ ok: true, restored: false, note: 'Snapshot cleared; original file may already be gone' });
}));

export default r;
