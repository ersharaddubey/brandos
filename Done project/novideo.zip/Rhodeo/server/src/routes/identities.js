import { Router } from 'express';
import Identity from '../models/Identity.js';
import Asset from '../models/Asset.js';
import { wrap, upload } from '../middleware/common.js';
import { ingestImage, removeAssetFile } from '../services/assets.js';
import { analyzeIdentity } from '../services/identityAnalyzer.js';
import { PROFILE_KEYS, clientSchema, computeLockStats } from '../services/lockSchema.js';

const r = Router();
const withRefs = (q) => q.populate('referenceAssetIds');

r.get('/meta/keys', (req, res) => res.json(PROFILE_KEYS));
r.get('/meta/schema', (req, res) => res.json(clientSchema()));

r.get('/', wrap(async (req, res) => {
  const filter = {};
  if (req.query.type) filter.type = req.query.type;
  if (req.query.status) filter.status = req.query.status;
  res.json(await withRefs(Identity.find(filter).sort('-createdAt')));
}));

r.get('/:id', wrap(async (req, res) => {
  const doc = await withRefs(Identity.findById(req.params.id));
  if (!doc) return res.status(404).json({ error: 'Identity not found' });
  res.json(doc);
}));

// Create: upload reference -> async "understand" step -> user reviews -> Lock
r.post('/', upload.single('image'), wrap(async (req, res) => {
  const { name, type, description, visibility } = req.body;
  if (!name || !type) return res.status(400).json({ error: 'name and type are required' });
  if (!req.file) return res.status(400).json({ error: 'Reference image is required' });
  const vis = visibility === 'public' ? 'public' : 'private';
  const { asset } = await ingestImage({ buffer: req.file.buffer, kind: 'reference', visibility: vis, category: type });
  const doc = await Identity.create({ name, type, description, referenceAssetIds: [asset._id], status: 'analyzing' });
  await Asset.updateOne({ _id: asset._id }, { $addToSet: { identityIds: doc._id } });
  analyzeIdentity(doc._id).catch(console.error);
  res.status(201).json(await withRefs(Identity.findById(doc._id)));
}));

r.post('/:id/reference', upload.single('image'), wrap(async (req, res) => {
  const doc = await Identity.findById(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Identity not found' });
  if (!req.file) return res.status(400).json({ error: 'Image required' });
  const { asset } = await ingestImage({ buffer: req.file.buffer, kind: 'reference', identityIds: [doc._id] });
  doc.referenceAssetIds.addToSet(asset._id);
  await doc.save();
  res.json(await withRefs(Identity.findById(doc._id)));
}));

r.put('/:id', wrap(async (req, res) => {
  const doc = await Identity.findById(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Identity not found' });
  if (doc.status === 'locked') return res.status(409).json({ error: 'Unlock the identity before editing' });
  const { name, description, profile, rules, anchors } = req.body;
  if (name !== undefined) doc.name = name;
  if (description !== undefined) doc.description = description;
  if (profile !== undefined) { doc.profile = profile; doc.markModified('profile'); }
  if (rules !== undefined) doc.rules = rules.map((x) => String(x).trim()).filter(Boolean);
  if (anchors !== undefined) doc.anchors = anchors.map((x) => String(x).trim()).filter(Boolean);
  await doc.save();
  res.json(await withRefs(Identity.findById(doc._id)));
}));

r.post('/:id/lock', wrap(async (req, res) => {
  const doc = await Identity.findById(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Identity not found' });
  const filled = Object.values(doc.profile || {}).some((v) => String(v).trim());
  if (!filled) return res.status(400).json({ error: 'Profile is empty - fill it or re-run analysis first' });
  doc.history.push({ version: doc.version, profile: doc.profile, rules: doc.rules, anchors: doc.anchors, lockPercent: computeLockStats(doc).percent });
  doc.version += 1;
  doc.status = 'locked';
  await doc.save();
  res.json(await withRefs(Identity.findById(doc._id)));
}));

r.post('/:id/unlock', wrap(async (req, res) => {
  const doc = await Identity.findByIdAndUpdate(req.params.id, { status: 'draft' }, { new: true });
  if (!doc) return res.status(404).json({ error: 'Identity not found' });
  res.json(await withRefs(Identity.findById(doc._id)));
}));

r.post('/:id/reanalyze', wrap(async (req, res) => {
  const doc = await Identity.findById(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Identity not found' });
  if (doc.status === 'locked') return res.status(409).json({ error: 'Unlock first' });
  doc.status = 'analyzing';
  await doc.save();
  analyzeIdentity(doc._id).catch(console.error);
  res.json(await withRefs(Identity.findById(doc._id)));
}));

r.delete('/:id', wrap(async (req, res) => {
  const doc = await Identity.findByIdAndDelete(req.params.id);
  if (doc) {
    for (const aid of doc.referenceAssetIds) {
      const a = await Asset.findByIdAndDelete(aid);
      if (a) await removeAssetFile(a);
    }
  }
  res.json({ ok: true });
}));

export default r;
