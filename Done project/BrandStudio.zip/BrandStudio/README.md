# brandstudio — brandstudio Platform

Lock product · character · brand · environment identities once, then generate consistent images & videos across campaigns.

## Stack

| Layer | Tech |
|-------|------|
| Client | React 18 + Vite + Tailwind |
| API | Express + Mongoose |
| DB | MongoDB |
| Vision / LLM | Ollama (optional) |
| Generation | Mock / ComfyUI / A1111 / InvokeAI / fal etc. |

## Quick start

```bash
# 1. MongoDB running on localhost:27017
# 2. (Optional) Ollama with a vision model

cd server
cp .env.example .env          # edit keys / GENERATOR_PROVIDER=mock for local test
npm install
npm run dev                   # → http://localhost:5002

cd ../client
npm install
npm run dev                   # → http://localhost:5173  (proxies /api & /uploads)
```

Open http://localhost:5173 → **Identity Lock** → upload reference → Lock → **Studio**.

## Studio — Reference selection (updated)

- Select any number of **locked** identities (product + character + brand + environment, or multiple of the same type).
- Selected chips always show at the bottom with **type badge**.
- **+ Add reference…** dropdown lists remaining locked identities as `type · name` — no 3-item limit.
- Chips are ordered the same way the prompt compiler uses: character → product → brand → environment.
- Click **×** on a chip (or the card) to deselect.
- **Ad-hoc upload box** (strip ke neeche): type (brand / product / character / environment) select karo + image upload. Naya identity ban jata hai; analyse + Lock ke baad wapas Studio mein select kar sakte ho — purani + nayi dono saath use karke perfect banao.

This fixes the previous UX gap where after selecting 3 identities there was no clear way to add a 4th, and where type was not obvious when adding more. Ad-hoc upload se Studio se hi naya reference add ho sakta hai.

## Main flows

1. **Identity Lock** (`/identities`)  
   - Single reference upload + type, or  
   - “Extract all from one image” (product / character / environment / brand layers).
2. **Studio** (`/studio`)  
   - Pick locked identities → campaign brief → Compile / Generate Image or Video.
3. **Asset Bank / Open Shelf** — private vs shared reference storage.
4. **Check** — consistency score against locked identity.
5. **Prompt OS / Workflow Builder** — templates & graphs.

## Generator providers

Set `GENERATOR_PROVIDER` in `server/.env`:

- `mock` — no external GPU, returns placeholder (good for UI testing)
- `comfyui` — local ComfyUI + InstantID / IP-Adapter workflows
- `a1111`, `invokeai`, etc. (see `.env.example`)

## Project layout

```
brandstudio/
  client/          React app
  server/          Express API + services
  flux-server/     Optional FLUX helper
  transformers-service/  Optional grounding / SAM
  colab/           Colab notebooks
  docker-compose.integrations.yml
```

## Notes

- Only **locked** identities appear in Studio.
- Multiple references per identity are supported via Identity Detail → “Add another reference”.
- For full consistency, lock one identity per type you care about, then select the combination in Studio.

## Image storage (ImageKit)

Set `IMAGEKIT_PUBLIC_KEY`, `IMAGEKIT_PRIVATE_KEY`, `IMAGEKIT_URL_ENDPOINT` in `server/.env` (also in your hosting dashboard's environment variables). All images are saved to ImageKit; `server/uploads` is just a cache. Existing local images: `cd server && npm run backfill-images`.

## Login

Poora app ab login ke peeche hai (server-side token check, sirf UI hide nahi).

- Default username: `brandstudio`
- Default password: `brandstudio@Studio#2026`
- Badalne ke liye `ADMIN_USERNAME`, `ADMIN_PASSWORD` aur `AUTH_SECRET` env vars set karo (local `server/.env` ya Vercel dashboard).

## Deploy on Vercel (live)

Ek hi Vercel project: `client/` static build + `api/index.js` serverless Express (`/api/*`). Same domain, isliye CORS / proxy ki zaroorat nahi.

1. **MongoDB Atlas** cluster banao, Network Access me `0.0.0.0/0` allow karo, connection string copy karo.
2. **ImageKit** account se 3 keys lo (live par images sirf yahin permanent save hoti hain; Vercel ka disk temporary hai).
3. Repo ko GitHub par push karo → Vercel → *Add New Project* → repo import. Root Directory = repo root (`brandstudio/`). Framework = *Other*. Build settings `vercel.json` se aa jaati hain.
4. *Settings → Environment Variables* me daalo:

| Variable | Value |
|----------|-------|
| `MONGO_URI` | Atlas connection string |
| `ADMIN_USERNAME` / `ADMIN_PASSWORD` | login credentials |
| `AUTH_SECRET` | lambi random string |
| `IMAGEKIT_PUBLIC_KEY`, `IMAGEKIT_PRIVATE_KEY`, `IMAGEKIT_URL_ENDPOINT` | ImageKit keys |
| `GENERATOR_PROVIDER` | `pollinations` (free) ya jo provider use karna ho + uski API key |
| `OLLAMA_URL` | sirf agar Ollama kahin hosted hai (localhost live par kaam nahi karta) |

5. Deploy. Baad me env var badlo to *Redeploy* karna padta hai.

Live par kya alag hai:
- Background kaam (image generation, identity analysis) `waitUntil` se response ke baad chalta hai; max time `vercel.json` me `maxDuration: 300`.
- Upload limit Vercel ki taraf se ~4.5 MB per request.
- Localhost services (Ollama, ComfyUI, A1111, Qdrant, n8n…) Vercel se connect nahi ho sakti — hosted URL do ya unhe off rakho.

## Deploy on Render (recommended for full features)

Render par normal Node server chalta hai: queue, lambe jobs, badi uploads sab bina Vercel ki limits ke.

1. Repo GitHub par push karo.
2. Render → *New → Blueprint* → repo select (`render.yaml` apne aap padh leta hai). Ya manually: Web Service, Build `npm --prefix client install && npm --prefix client run build && npm --prefix server install`, Start `npm --prefix server start`.
3. Env vars bharo: `MONGO_URI` (Atlas), `ADMIN_PASSWORD`, ImageKit ki 3 keys. `AUTH_SECRET` auto-generate hota hai.
4. Atlas Network Access me `0.0.0.0/0` allow karo.
5. Ek hi URL par app + API dono chalte hain.

Note: Render ka disk redeploy par wipe hota hai (images ImageKit me safe hain). Ollama / ComfyUI jaisi GPU services Render par nahi chalti — unke liye hosted provider ya alag GPU host chahiye.

## Deploy on Koyeb (Docker)

`Dockerfile` ek hi image me client build + Express API banata hai (port 8000, low-memory mode ON).

1. Repo GitHub par push karo → Koyeb → *Create Service → Web Service → GitHub* → repo select.
2. Builder: **Dockerfile** (root `Dockerfile`). Instance: Free. Region: Frankfurt / Washington.
3. Port: `8000` (HTTP). Health check path: `/api/health`.
4. Environment variables: `MONGO_URI` (MongoDB Atlas, Network Access `0.0.0.0/0`), `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `AUTH_SECRET`, `IMAGEKIT_PUBLIC_KEY`, `IMAGEKIT_PRIVATE_KEY`, `IMAGEKIT_URL_ENDPOINT`, `GENERATOR_PROVIDER=pollinations`.
5. Deploy. Free instance ~1 ghante bina traffic ke sleep ho jata hai; pehli request par thoda wait lagta hai.

Local Docker test: `docker build -t brandstudio . && docker run -p 8000:8000 --env-file server/.env brandstudio`
