import ImageKit from 'imagekit';

/**
 * Persistent image storage (ImageKit).
 *
 * Local disk (server/uploads) is only a cache: on Render / Railway / Docker /
 * every fresh zip deploy that folder is wiped, but MongoDB keeps the Asset rows,
 * so images "disappear". Every stored image is therefore also uploaded here, and
 * read back from here if the local file is missing.
 *
 * If the IMAGEKIT_* env vars are not set, everything falls back to local-only.
 */
let client = null;
let tried = false;

function getClient() {
  if (tried) return client;
  tried = true;
  const { IMAGEKIT_PUBLIC_KEY, IMAGEKIT_PRIVATE_KEY, IMAGEKIT_URL_ENDPOINT } = process.env;
  if (IMAGEKIT_PUBLIC_KEY && IMAGEKIT_PRIVATE_KEY && IMAGEKIT_URL_ENDPOINT) {
    client = new ImageKit({
      publicKey: IMAGEKIT_PUBLIC_KEY,
      privateKey: IMAGEKIT_PRIVATE_KEY,
      urlEndpoint: IMAGEKIT_URL_ENDPOINT,
    });
  } else {
    console.warn('[storage] IMAGEKIT_* not set — images are stored on local disk only (they vanish on redeploy)');
  }
  return client;
}

export const storageEnabled = () => !!getClient();

/** Upload bytes. Returns { url, fileId } or null (never throws). */
export async function uploadBuffer(buffer, fileName, folder = '/brandstudio/assets') {
  const ik = getClient();
  if (!ik) return null;
  try {
    const r = await ik.upload({ file: buffer, fileName, folder, useUniqueFileName: false, overwriteFile: true });
    return { url: r.url, fileId: r.fileId };
  } catch (e) {
    console.error('[storage] ImageKit upload failed:', e.message);
    return null;
  }
}

/** Download bytes from a stored URL. Returns Buffer or null. */
export async function downloadBuffer(url) {
  if (!url) return null;
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(20000) });
    if (!res.ok) return null;
    return Buffer.from(await res.arrayBuffer());
  } catch (e) {
    console.error('[storage] ImageKit download failed:', e.message);
    return null;
  }
}

export async function deleteRemote(fileId) {
  const ik = getClient();
  if (!ik || !fileId) return;
  try {
    await ik.deleteFile(fileId);
  } catch (e) {
    console.warn('[storage] ImageKit delete failed:', e.message);
  }
}
