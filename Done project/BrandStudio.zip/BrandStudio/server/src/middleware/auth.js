import crypto from 'crypto';
import config from '../config.js';

const b64 = (buf) => Buffer.from(buf).toString('base64url');
const secret = () =>
  config.auth.secret ||
  crypto.createHash('sha256').update(`brandstudio|${config.auth.username}|${config.auth.password}`).digest('hex');
const sign = (data) => crypto.createHmac('sha256', secret()).update(data).digest('base64url');

const safeEqual = (a, b) => {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
};

export function issueToken(username) {
  const payload = b64(JSON.stringify({ u: username, exp: Date.now() + config.auth.ttlHours * 3600 * 1000 }));
  return `${payload}.${sign(payload)}`;
}

export function verifyToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  if (!safeEqual(sig, sign(payload))) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return data.exp > Date.now() ? data : null;
  } catch {
    return null;
  }
}

const bearer = (req) => {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : '';
};

/** Sab /api routes ke liye (login + health ke alawa) */
export function requireAuth(req, res, next) {
  const session = verifyToken(bearer(req));
  if (!session) return res.status(401).json({ error: 'Login required' });
  req.user = session.u;
  next();
}

export async function login(req, res) {
  const { username = '', password = '' } = req.body || {};
  const ok = safeEqual(username, config.auth.username) && safeEqual(password, config.auth.password);
  if (!ok) {
    await new Promise((r) => setTimeout(r, 600)); // brute-force slow karne ke liye
    return res.status(401).json({ error: 'Wrong username or password' });
  }
  res.json({ token: issueToken(config.auth.username), username: config.auth.username });
}

export const me = (req, res) => res.json({ username: req.user });
