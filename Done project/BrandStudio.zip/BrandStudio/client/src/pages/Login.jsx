import { useState } from 'react';
import { api, auth } from '../api.js';
import Logo from '../components/Logo.jsx';

export default function Login({ onSuccess }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [shakeKey, setShakeKey] = useState(0);

  const submit = async (e) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      const { token } = await api.login(username.trim(), password);
      auth.save(token);
      onSuccess();
    } catch (err) {
      setError(err.message === 'Failed to fetch' ? 'Cannot reach the server. Check your connection and try again.' : err.message);
      setShakeKey((k) => k + 1);
      setBusy(false);
    }
  };

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={submit} key={shakeKey} data-shake={shakeKey > 0 ? 'on' : 'off'}>
        <Logo size={52} className="login-logo" />
        <h1>brandstudio</h1>
        <p className="login-sub">Sign in to your brandstudio studio.</p>

        <label htmlFor="login-user">Username</label>
        <input
          id="login-user"
          type="text"
          autoComplete="username"
          autoCapitalize="none"
          spellCheck={false}
          autoFocus
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />

        <label htmlFor="login-pass">Password</label>
        <div className="login-pass">
          <input
            id="login-pass"
            type={show ? 'text' : 'password'}
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="button" className="login-eye" onClick={() => setShow((v) => !v)} aria-label={show ? 'Hide password' : 'Show password'}>
            {show ? 'Hide' : 'Show'}
          </button>
        </div>

        <p className="login-error" role="alert" aria-live="polite">{error}</p>

        <button type="submit" className="primary login-submit" disabled={busy || !username || !password}>
          {busy ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </div>
  );
}
