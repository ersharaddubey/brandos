/** StrangersMeet — simplified like KoPartner: Services + Events + BF/GF */

export interface Experience {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  color: string;
  price?: number;
  duration?: string;
}

/** KoPartner-style service list */
export const services = [
  { id: 'movie', title: 'Movie Partner', icon: '🎬', desc: 'Cinema company', priceFrom: 699 },
  { id: 'coffee', title: 'Coffee Partner', icon: '☕', desc: 'Cafe chat', priceFrom: 499 },
  { id: 'hangout', title: 'Hangout', icon: '🤝', desc: 'Casual company', priceFrom: 599 },
  { id: 'shopping', title: 'Shopping Buddy', icon: '🛍️', desc: 'Mall & shopping', priceFrom: 599 },
  { id: 'event', title: 'Event Partner', icon: '🎉', desc: 'Weddings & parties', priceFrom: 1499 },
  { id: 'travel', title: 'Travel Partner', icon: '✈️', desc: 'Day trip / city', priceFrom: 999 },
  { id: 'club', title: 'Clubbing', icon: '🪩', desc: 'Night out company', priceFrom: 999 },
  { id: 'concert', title: 'Concert Partner', icon: '🎵', desc: 'Live show +1', priceFrom: 799 },
  { id: 'cafe_food', title: 'Cafe & Food', icon: '🍜', desc: 'Food crawl', priceFrom: 699 },
  { id: 'city_tour', title: 'City Tour', icon: '🗺️', desc: 'Local spots', priceFrom: 899 },
  { id: 'gaming', title: 'Gaming Partner', icon: '🎮', desc: 'Play together', priceFrom: 499 },
  { id: 'inperson', title: 'In-Person Meet', icon: '💬', desc: 'Talk & company', priceFrom: 599 },
];

/** Keep experiences alias for older screens */
export const experiences: Experience[] = services.map((s, i) => ({
  id: String(i + 1),
  title: s.title,
  subtitle: s.desc,
  description: `${s.desc}. Verified partner · Platonic · Public places.`,
  icon: s.icon,
  color: ['#ff6b35', '#3b82f6', '#a855f7', '#ec4899', '#f59e0b', '#14b8a6'][i % 6],
  price: s.priceFrom,
  duration: '1–3 hrs',
}));

export const howItWorks = [
  { step: 1, title: 'Choose service or event', description: 'Pick a service or a city event.' },
  { step: 2, title: 'Add to cart & book', description: 'Event price goes to cart. Optionally add BF/GF.' },
  { step: 3, title: 'Get verified partner', description: 'ID-verified · Platonic · Safe.' },
  { step: 4, title: 'Meet & enjoy', description: 'Public venues · Easy cancel.' },
];

export const stats = [
  { value: '21K+', label: 'Members', icon: '👥' },
  { value: '20+', label: 'Cities', icon: '📍' },
  { value: '4.9', label: 'Rating', icon: '⭐' },
  { value: '100%', label: 'Verified', icon: '🛡️' },
];

export const features = [
  { title: 'Verified Partners', description: 'ID-checked professionals.', icon: '🪪' },
  { title: 'Safe & Platonic', description: 'Clear boundaries always.', icon: '🤝' },
  { title: 'City Events', description: 'Book events in your city.', icon: '🎫' },
  { title: 'BF / GF optional', description: 'Add boyfriend or girlfriend if you want.', icon: '💜' },
];

export const trustBadges = [
  { icon: '🪪', label: 'ID Verified' },
  { icon: '📍', label: 'Public Meetups' },
  { icon: '💜', label: '100% Platonic' },
  { icon: '🔒', label: 'Private' },
];

export const cities = [
  { name: 'Delhi NCR', tagline: 'Where connections begin' },
  { name: 'Mumbai', tagline: 'Maximum city vibes' },
  { name: 'Bangalore', tagline: 'Tech city, real connections' },
  { name: 'Pune', tagline: 'Smart city vibes' },
  { name: 'Hyderabad', tagline: 'Every moment connects' },
  { name: 'Ahmedabad', tagline: 'New vibes, new people' },
  { name: 'Jaipur', tagline: 'Royal meets romance' },
  { name: 'Chandigarh', tagline: 'Beautiful city' },
  { name: 'Lucknow', tagline: 'Nawabi vibes' },
  { name: 'Kolkata', tagline: 'City of joy' },
  { name: 'Chennai', tagline: 'Southern charm' },
  { name: 'Goa', tagline: 'Unmatched energy' },
];

export interface Companion {
  id: string;
  name: string;
  role: string;
  rating: number;
  rate: number;
  tags: string[];
  icon: string;
  bio: string;
  online?: boolean;
  city?: string;
  verified?: boolean;
  gender?: 'male' | 'female';
}

export const companionCategories = [
  { key: 'boyfriend', label: 'Boyfriend', icon: '💙', desc: 'Male companion for events & company' },
  { key: 'girlfriend', label: 'Girlfriend', icon: '💖', desc: 'Female companion for events & company' },
];

export const companions: Companion[] = [
  {
    id: 'c1',
    name: 'Arjun M.',
    role: 'Boyfriend',
    rating: 4.9,
    rate: 999,
    tags: ['Events', 'Movies', 'Cafe'],
    icon: '👨',
    bio: 'Warm company for dinners, events and outings. Strictly platonic.',
    online: true,
    city: 'Delhi NCR',
    verified: true,
    gender: 'male',
  },
  {
    id: 'c2',
    name: 'Rahul K.',
    role: 'Boyfriend',
    rating: 4.8,
    rate: 799,
    tags: ['Hangout', 'Travel', 'Gaming'],
    icon: '🧑',
    bio: 'Easy-going partner for hangouts and city plans.',
    online: true,
    city: 'Bangalore',
    verified: true,
    gender: 'male',
  },
  {
    id: 'c3',
    name: 'Vikram S.',
    role: 'Boyfriend',
    rating: 4.7,
    rate: 899,
    tags: ['Event', 'Family', 'Coffee'],
    icon: '🧔',
    bio: 'Reliable +1 for social and family occasions.',
    city: 'Mumbai',
    verified: true,
    gender: 'male',
  },
  {
    id: 'c4',
    name: 'Priya S.',
    role: 'Girlfriend',
    rating: 5.0,
    rate: 1199,
    tags: ['Events', 'Shopping', 'Cafe'],
    icon: '👩',
    bio: 'Elegant company for events, shopping and conversations.',
    online: true,
    city: 'Mumbai',
    verified: true,
    gender: 'female',
  },
  {
    id: 'c5',
    name: 'Neha R.',
    role: 'Girlfriend',
    rating: 4.9,
    rate: 999,
    tags: ['Movies', 'Food', 'Travel'],
    icon: '💃',
    bio: 'Fun company for movies, food and day plans.',
    online: true,
    city: 'Delhi NCR',
    verified: true,
    gender: 'female',
  },
  {
    id: 'c6',
    name: 'Aisha P.',
    role: 'Girlfriend',
    rating: 4.8,
    rate: 1099,
    tags: ['City tour', 'Events', 'Cafe'],
    icon: '😊',
    bio: 'Friendly partner for city tours and social outings.',
    city: 'Pune',
    verified: true,
    gender: 'female',
  },
];

export const packages = [
  { id: 'p1', category: 'Service', title: '1 Hour', price: 699, unit: '/hour', features: ['1 hour company', 'Public venue'], popular: false },
  { id: 'p2', category: 'Service', title: '3 Hours', price: 1799, unit: '/3 hours', features: ['3 hours', 'Flexible activity'], popular: true },
  { id: 'p3', category: 'Service', title: 'Event (4 hrs)', price: 2499, unit: '/4 hours', features: ['Event +1', 'Professional'], popular: false },
];

export const activities = [
  'Movie',
  'Coffee / Cafe',
  'Hangout',
  'Shopping',
  'Event / Wedding',
  'Travel / Tour',
  'Clubbing',
  'Concert',
  'Gaming',
  'Just meeting',
];

export const durations = [
  { label: '1 Hour', hours: 1 },
  { label: '2 Hours', hours: 2 },
  { label: '3 Hours', hours: 3 },
  { label: '4 Hours', hours: 4 },
  { label: '6 Hours', hours: 6 },
];

/** Cart line item (event and/or companion) */
export type CartItem = {
  type: 'event' | 'companion' | 'service';
  id: string;
  title: string;
  price: number;
  meta?: string;
};
