export const heroSlides = [
  {
    id: 's1',
    title: 'Professional Companions',
    subtitle: 'Verified · Platonic · Safe',
    cta: 'Browse services',
    target: 'Home',
    bg: '#E9E3FF',
    emoji: '💜',
  },
  {
    id: 's2',
    title: 'City Events',
    subtitle: 'Book an event · add BF/GF if you want',
    cta: 'See events',
    target: 'CityEvents',
    bg: '#FFE5D0',
    emoji: '🎫',
  },
  {
    id: 's3',
    title: 'Boyfriend / Girlfriend',
    subtitle: 'Optional companion for any plan',
    cta: 'View profiles',
    target: 'Companions',
    bg: '#F4DDE3',
    emoji: '💙',
  },
];

export const mallCategories = [
  { key: 'services', label: 'Services', icon: '✨', screen: 'Home' },
  { key: 'events', label: 'Events', icon: '🎫', screen: 'CityEvents' },
  { key: 'boyfriend', label: 'Boyfriend', icon: '💙', screen: 'Companions' },
  { key: 'girlfriend', label: 'Girlfriend', icon: '💖', screen: 'Companions' },
  { key: 'book', label: 'Book', icon: '⚡', screen: 'Booking' },
];

/** Minimal meet features — map to services / events / companions */
export const meetFeatures = [
  { key: 'movie', label: 'Movie Partner', icon: '🎬', desc: 'from ₹699', screen: 'Booking', section: 'services' },
  { key: 'coffee', label: 'Coffee Partner', icon: '☕', desc: 'from ₹499', screen: 'Booking', section: 'services' },
  { key: 'hangout', label: 'Hangout', icon: '🤝', desc: 'from ₹599', screen: 'Booking', section: 'services' },
  { key: 'shopping', label: 'Shopping', icon: '🛍️', desc: 'from ₹599', screen: 'Booking', section: 'services' },
  { key: 'event', label: 'Event Partner', icon: '🎉', desc: 'from ₹1499', screen: 'Booking', section: 'services' },
  { key: 'city_events', label: 'City Events', icon: '🎫', desc: 'Book by city', screen: 'CityEvents', section: 'events' },
  { key: 'bf', label: 'Boyfriend', icon: '💙', desc: 'Male companion', screen: 'Companions', section: 'bfgf' },
  { key: 'gf', label: 'Girlfriend', icon: '💖', desc: 'Female companion', screen: 'Companions', section: 'bfgf' },
];

export const meetSections = [
  { key: 'services', title: 'SERVICES', subtitle: 'Like KoPartner — book a partner' },
  { key: 'events', title: 'CITY EVENTS', subtitle: 'Event ticket → cart · optional BF/GF' },
  { key: 'bfgf', title: 'BOYFRIEND / GIRLFRIEND', subtitle: 'Only if you want to add one' },
];
