import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { colors } from '../theme/colors';

interface FooterProps {
  activeTab: string;
  onTabPress: (tab: string) => void;
  bottomInset?: number;
}

const tabs = [
  { key: 'Home', label: 'Home', icon: '🏠' },
  { key: 'CityEvents', label: 'Events', icon: '🎫' },
  { key: 'Companions', label: 'BF / GF', icon: '💜' },
  { key: 'Profile', label: 'You', icon: '👤' },
];

export default function Footer({ activeTab, onTabPress, bottomInset = 0 }: FooterProps) {
  return (
    <View style={[styles.container, { paddingBottom: Math.max(bottomInset, 10) + 6 }]}>
      {tabs.map((tab) => {
        const isActive = activeTab === tab.key || (tab.key === 'CityEvents' && activeTab === 'Cities');
        return (
          <TouchableOpacity
            key={tab.key}
            style={[styles.tab, isActive && styles.tabActive]}
            onPress={() => onTabPress(tab.key)}
            activeOpacity={0.75}
          >
            <Text style={[styles.icon, isActive && styles.iconActive]}>{tab.icon}</Text>
            <Text style={[styles.label, isActive && styles.labelActive]} numberOfLines={1}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: 8,
    paddingHorizontal: 4,
    shadowColor: '#252432',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 8,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
    borderRadius: 14,
    marginHorizontal: 2,
  },
  tabActive: { backgroundColor: colors.primarySoft },
  icon: { fontSize: 17, marginBottom: 2, opacity: 0.5 },
  iconActive: { opacity: 1 },
  label: { fontSize: 9, color: colors.textMuted, fontWeight: '600' },
  labelActive: { color: colors.primary, fontWeight: '800' },
});
