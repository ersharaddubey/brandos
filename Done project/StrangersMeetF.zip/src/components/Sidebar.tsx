import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  Pressable,
  ScrollView,
} from 'react-native';
import { colors } from '../theme/colors';
import { meetFeatures } from '../data/home';

const { width } = Dimensions.get('window');
const SIDEBAR_WIDTH = Math.min(width * 0.82, 320);

interface SidebarProps {
  visible: boolean;
  onClose: () => void;
  activeTab: string;
  onNavigate: (screen: string, params?: any) => void;
  currentScreen: string;
  topInset?: number;
}

const exploreItems = [
  { key: 'Home', label: 'Services', icon: '✨', desc: 'Movie · Cafe · Event partner', accent: colors.clayPink },
  { key: 'CityEvents', label: 'City Events', icon: '🎫', desc: 'Book event → cart', accent: colors.peach },
  { key: 'Companions', label: 'Boyfriend / Girlfriend', icon: '💜', desc: 'Optional companion', accent: colors.lavender },
  { key: 'Booking', label: 'Book Now', icon: '⚡', desc: 'Service or event', accent: colors.mint },
];

const accountItems = [
  { key: 'MyBookings', label: 'My Bookings', icon: '🎫', desc: 'Upcoming plans', accent: colors.lavender },
  { key: 'Favorites', label: 'Favorites', icon: '❤️', desc: 'Saved picks', accent: colors.clayPink },
  { key: 'Notifications', label: 'Notifications', icon: '🔔', desc: 'Alerts & updates', accent: colors.peach },
  { key: 'EditProfile', label: 'Edit Profile', icon: '✏️', desc: 'Name, photo & bio', accent: colors.mint },
];

const supportItems = [
  { key: 'Help', label: 'Help & Support', icon: '💬', desc: '24/7 assistance' },
  { key: 'Privacy', label: 'Privacy & Safety', icon: '🛡️', desc: 'Your data is safe' },
  { key: 'Terms', label: 'Terms', icon: '📄', desc: 'Policies' },
  { key: 'About', label: 'About', icon: 'ℹ️', desc: 'Version 1.0.0' },
];

export default function Sidebar({
  visible,
  onClose,
  activeTab,
  onNavigate,
  currentScreen,
  topInset = 0,
}: SidebarProps) {
  const slideAnim = useRef(new Animated.Value(-SIDEBAR_WIDTH)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.spring(slideAnim, {
          toValue: 0,
          useNativeDriver: true,
          tension: 68,
          friction: 12,
        }),
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 220,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(slideAnim, {
          toValue: -SIDEBAR_WIDTH,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 160,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [visible]);

  const handleNav = (key: string) => {
    onNavigate(key);
    onClose();
  };

  if (!visible) return null;

  const isActive = (key: string) => currentScreen === key || activeTab === key;

  const renderFeatureRow = (
    item: { key: string; label: string; icon: string; desc: string; accent?: string },
    featured?: boolean
  ) => {
    const active = isActive(item.key);
    return (
      <TouchableOpacity
        key={item.key}
        style={[
          styles.menuItem,
          featured && styles.menuItemFeatured,
          active && styles.menuItemActive,
        ]}
        onPress={() => handleNav(item.key)}
        activeOpacity={0.75}
      >
        <View
          style={[
            styles.iconWrap,
            { backgroundColor: item.accent || colors.lavender },
            active && styles.iconWrapActive,
          ]}
        >
          <Text style={styles.menuIcon}>{item.icon}</Text>
        </View>
        <View style={styles.menuTextWrap}>
          <Text style={[styles.menuLabel, active && styles.menuLabelActive]}>{item.label}</Text>
          <Text style={styles.menuDesc} numberOfLines={1}>
            {item.desc}
          </Text>
        </View>
        {active ? (
          <View style={styles.activePill}>
            <Text style={styles.activePillText}>•</Text>
          </View>
        ) : (
          <Text style={styles.chevron}>›</Text>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      <Animated.View style={[styles.overlay, { opacity: fadeAnim }]}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
      </Animated.View>

      <Animated.View
        style={[
          styles.sidebar,
          {
            transform: [{ translateX: slideAnim }],
            paddingTop: topInset + 8,
          },
        ]}
      >
        <View style={styles.header}>
          <View style={styles.brandBlock}>
            <View style={styles.logoMark}>
              <Text style={styles.logoMarkText}>♥</Text>
            </View>
            <View>
              <View style={styles.logoRow}>
                <Text style={styles.logo}>Strangers</Text>
                <Text style={styles.logoAccent}>Meet</Text>
              </View>
              <Text style={styles.tagline}>Male · Female · Real meets</Text>
            </View>
          </View>
          <TouchableOpacity onPress={onClose} style={styles.closeBtn} hitSlop={12}>
            <Text style={styles.closeText}>✕</Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          style={styles.scroll}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
        >
          <TouchableOpacity
            style={styles.promoCard}
            activeOpacity={0.85}
            onPress={() => handleNav('FreeMeetup')}
          >
            <View style={styles.promoBadge}>
              <Text style={styles.promoBadgeText}>FREE</Text>
            </View>
            <Text style={styles.promoTitle}>Join a Free Meetup</Text>
            <Text style={styles.promoSub}>Male · Female · No booking fee</Text>
            <View style={styles.promoCta}>
              <Text style={styles.promoCtaText}>Explore →</Text>
            </View>
          </TouchableOpacity>

          <Text style={styles.sectionLabel}>EXPLORE</Text>
          {exploreItems.map((item) => renderFeatureRow(item, item.key === 'FreeMeetup'))}

          <Text style={[styles.sectionLabel, styles.sectionGap]}>MEET TYPES</Text>
          <Text style={styles.sectionHint}>1:1 · Male · Female</Text>
          {meetFeatures
            .filter((f) => f.section === 'meet')
            .map((f) => (
              <TouchableOpacity
                key={f.key}
                style={styles.chipRow}
                onPress={() => { onNavigate('FeatureDetail', { featureKey: f.key }); onClose(); }}
                activeOpacity={0.7}
              >
                <Text style={styles.chipIcon}>{f.icon}</Text>
                <Text style={styles.chipLabel}>{f.label}</Text>
                <Text style={styles.chevron}>›</Text>
              </TouchableOpacity>
            ))}

          <Text style={[styles.sectionLabel, styles.sectionGap]}>GROUP HANGS</Text>
          {meetFeatures
            .filter((f) => f.section === 'group')
            .map((f) => (
              <TouchableOpacity
                key={f.key}
                style={styles.chipRow}
                onPress={() => { onNavigate('FeatureDetail', { featureKey: f.key }); onClose(); }}
                activeOpacity={0.7}
              >
                <Text style={styles.chipIcon}>{f.icon}</Text>
                <Text style={styles.chipLabel}>{f.label}</Text>
                <Text style={styles.chevron}>›</Text>
              </TouchableOpacity>
            ))}

          <Text style={[styles.sectionLabel, styles.sectionGap]}>INDIA SPECIALS</Text>
          {meetFeatures
            .filter((f) => f.section === 'niche')
            .map((f) => (
              <TouchableOpacity
                key={f.key}
                style={styles.chipRow}
                onPress={() => { onNavigate('FeatureDetail', { featureKey: f.key }); onClose(); }}
                activeOpacity={0.7}
              >
                <Text style={styles.chipIcon}>{f.icon}</Text>
                <Text style={styles.chipLabel}>{f.label}</Text>
                <Text style={styles.chevron}>›</Text>
              </TouchableOpacity>
            ))}

          <Text style={[styles.sectionLabel, styles.sectionGap]}>YOUR SPACE</Text>
          {accountItems.map((item) => renderFeatureRow(item))}

          <Text style={[styles.sectionLabel, styles.sectionGap]}>SUPPORT</Text>
          {supportItems.map((item) => (
            <TouchableOpacity
              key={item.key}
              style={[styles.supportItem, isActive(item.key) && styles.supportItemActive]}
              onPress={() => handleNav(item.key)}
              activeOpacity={0.7}
            >
              <Text style={styles.supportIcon}>{item.icon}</Text>
              <Text style={[styles.supportLabel, isActive(item.key) && styles.supportLabelActive]}>
                {item.label}
              </Text>
            </TouchableOpacity>
          ))}

          <View style={styles.footerBlock}>
            <Text style={styles.footerHeart}>♥</Text>
            <Text style={styles.footerBrand}>STRANGERS MEET</Text>
            <Text style={styles.footerNote}>Equal Date™ · Fair vibes only</Text>
          </View>
        </ScrollView>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(37, 36, 50, 0.5)',
  },
  sidebar: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: SIDEBAR_WIDTH,
    backgroundColor: colors.surfaceRaised,
    borderRightWidth: 1,
    borderRightColor: colors.borderStrong,
    shadowColor: '#252432',
    shadowOffset: { width: 8, height: 0 },
    shadowOpacity: 0.12,
    shadowRadius: 24,
    elevation: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  brandBlock: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  logoMark: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 4,
  },
  logoMarkText: { color: '#fff', fontSize: 18 },
  logoRow: { flexDirection: 'row', alignItems: 'center' },
  logo: { color: colors.text, fontSize: 17, fontWeight: '800' },
  logoAccent: { color: colors.primary, fontSize: 17, fontWeight: '800' },
  tagline: {
    color: colors.textMuted,
    fontSize: 11,
    marginTop: 1,
    fontWeight: '500',
  },
  closeBtn: {
    width: 34,
    height: 34,
    borderRadius: 12,
    backgroundColor: colors.backgroundSecondary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  closeText: {
    color: colors.textSecondary,
    fontSize: 13,
    fontWeight: '700',
  },
  scroll: { flex: 1 },
  scrollContent: {
    paddingHorizontal: 14,
    paddingTop: 16,
    paddingBottom: 48,
  },
  promoCard: {
    backgroundColor: colors.primary,
    borderRadius: 18,
    padding: 16,
    marginBottom: 22,
    overflow: 'hidden',
  },
  promoBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.25)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    marginBottom: 8,
  },
  promoBadgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1,
  },
  promoTitle: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '800',
  },
  promoSub: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 12,
    marginTop: 4,
  },
  promoCta: {
    marginTop: 12,
    alignSelf: 'flex-start',
    backgroundColor: '#fff',
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
  },
  promoCtaText: {
    color: colors.primary,
    fontSize: 13,
    fontWeight: '800',
  },
  sectionLabel: {
    color: colors.textMuted,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.6,
    marginBottom: 8,
    marginLeft: 6,
  },
  sectionHint: {
    color: colors.textMuted,
    fontSize: 10,
    marginLeft: 6,
    marginBottom: 8,
    marginTop: -4,
  },
  sectionGap: {
    marginTop: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 16,
    marginBottom: 6,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  menuItemFeatured: {
    borderColor: 'rgba(117, 99, 232, 0.25)',
    backgroundColor: colors.primarySoft,
  },
  menuItemActive: {
    borderColor: 'rgba(117, 99, 232, 0.4)',
    backgroundColor: colors.primarySoft,
  },
  iconWrap: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  iconWrapActive: {
    borderWidth: 2,
    borderColor: colors.primary,
  },
  menuIcon: { fontSize: 18 },
  menuTextWrap: { flex: 1 },
  menuLabel: {
    color: colors.text,
    fontSize: 14,
    fontWeight: '700',
  },
  menuLabelActive: {
    color: colors.primaryDark,
  },
  menuDesc: {
    color: colors.textMuted,
    fontSize: 11,
    marginTop: 2,
  },
  chevron: {
    color: colors.textMuted,
    fontSize: 18,
    fontWeight: '300',
    marginLeft: 4,
  },
  activePill: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activePillText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '900',
  },
  chipRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 12,
    marginBottom: 2,
  },
  chipIcon: {
    fontSize: 16,
    width: 28,
    textAlign: 'center',
    marginRight: 8,
  },
  chipLabel: {
    flex: 1,
    color: colors.textSecondary,
    fontSize: 13,
    fontWeight: '600',
  },
  supportItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 11,
    paddingHorizontal: 12,
    borderRadius: 12,
    marginBottom: 2,
  },
  supportItemActive: {
    backgroundColor: colors.backgroundSecondary,
  },
  supportIcon: {
    fontSize: 16,
    marginRight: 12,
    width: 24,
    textAlign: 'center',
  },
  supportLabel: {
    color: colors.textSecondary,
    fontSize: 13,
    fontWeight: '600',
  },
  supportLabelActive: {
    color: colors.primary,
    fontWeight: '700',
  },
  footerBlock: {
    marginTop: 28,
    alignItems: 'center',
    paddingVertical: 16,
  },
  footerHeart: {
    color: colors.accent,
    fontSize: 16,
    marginBottom: 4,
  },
  footerBrand: {
    color: colors.text,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.2,
  },
  footerNote: {
    color: colors.textMuted,
    fontSize: 11,
    marginTop: 4,
  },
});
