import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { colors } from '../theme/colors';
import { Companion, trustBadges } from '../data/experiences';

interface Props {
  companion: Companion;
  onBack: () => void;
  onNavigate: (screen: string, params?: any) => void;
}

export default function CompanionDetailScreen({ companion, onBack, onNavigate }: Props) {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.hero}>
        <Text style={styles.icon}>{companion.icon}</Text>
        <Text style={styles.name}>{companion.name}</Text>
        <Text style={styles.role}>{companion.role}</Text>
        <View style={styles.meta}>
          <Text style={styles.rating}>⭐ {companion.rating.toFixed(1)}</Text>
          <Text style={styles.rate}>₹{companion.rate}/hr</Text>
          {companion.online && <Text style={styles.online}>● Online</Text>}
        </View>
        {(companion.city || companion.verified) && (
          <View style={styles.cityRow}>
            {companion.verified && (
              <View style={styles.verifiedBadge}>
                <Text style={styles.verifiedText}>🪪 ID Verified</Text>
              </View>
            )}
            {companion.city ? (
              <Text style={styles.cityText}>📍 {companion.city}</Text>
            ) : null}
          </View>
        )}
      </View>

      <View style={styles.body}>
        <Text style={styles.sectionLabel}>ABOUT</Text>
        <Text style={styles.bio}>{companion.bio}</Text>

        <Text style={styles.sectionLabel}>TAGS</Text>
        <View style={styles.tags}>
          {companion.tags.map((t) => (
            <View key={t} style={styles.tag}>
              <Text style={styles.tagText}>{t}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.sectionLabel}>TRUST</Text>
        <View style={styles.trustRow}>
          {trustBadges.map((b) => (
            <View key={b.label} style={styles.trustChip}>
              <Text style={styles.trustIcon}>{b.icon}</Text>
              <Text style={styles.trustLabel}>{b.label}</Text>
            </View>
          ))}
        </View>
        <Text style={styles.safety}>
          Strictly platonic · Public places for meets · Easy cancel
        </Text>

        <TouchableOpacity
          style={styles.bookBtn}
          onPress={() => onNavigate('Booking', { companion })}
          activeOpacity={0.85}
        >
          <Text style={styles.bookBtnText}>
            Book {companion.name.split(' ')[0]} · ₹{companion.rate}/hr
          </Text>
        </TouchableOpacity>
      </View>
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: {
    alignItems: 'center',
    paddingTop: 28,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  icon: { fontSize: 56, marginBottom: 12 },
  name: { color: colors.text, fontSize: 26, fontWeight: '800' },
  role: { color: colors.primary, fontSize: 15, fontWeight: '600', marginTop: 4 },
  meta: { flexDirection: 'row', alignItems: 'center', gap: 14, marginTop: 12 },
  rating: { color: colors.textSecondary, fontSize: 14 },
  rate: { color: colors.accent, fontSize: 16, fontWeight: '800' },
  online: { color: colors.success, fontSize: 13, fontWeight: '600' },
  cityRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 12 },
  verifiedBadge: {
    backgroundColor: 'rgba(34,197,94,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
  },
  verifiedText: { color: colors.success, fontSize: 12, fontWeight: '700' },
  cityText: { color: colors.textSecondary, fontSize: 13 },
  body: { paddingHorizontal: 24 },
  sectionLabel: {
    color: colors.secondary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.4,
    marginTop: 20,
    marginBottom: 8,
  },
  bio: { color: colors.textSecondary, fontSize: 15, lineHeight: 22 },
  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tag: {
    backgroundColor: colors.glass,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  tagText: { color: colors.textSecondary, fontSize: 13 },
  trustRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 8 },
  trustChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.glass,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  trustIcon: { fontSize: 12 },
  trustLabel: { color: colors.textSecondary, fontSize: 11, fontWeight: '600' },
  safety: { color: colors.textMuted, fontSize: 14, lineHeight: 20 },
  bookBtn: {
    marginTop: 28,
    backgroundColor: colors.primary,
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
  },
  bookBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
