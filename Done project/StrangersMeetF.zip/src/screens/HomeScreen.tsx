import React, { useRef, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  NativeSyntheticEvent,
  NativeScrollEvent,
} from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import { colors as staticColors } from '../theme/colors';
import { experiences as staticExperiences, companions as staticCompanions, packages as staticPackages, stats } from '../data/experiences';
import { heroSlides as staticHeroSlides, mallCategories, meetFeatures, meetSections } from '../data/home';
import { fetchSlides, fetchCompanions, fetchExperiences, fetchPackages } from '../api';

const { width } = Dimensions.get('window');
const SLIDE_W = width - 40;

interface Props {
  onNavigate: (screen: string, params?: any) => void;
}

export default function HomeScreen({ onNavigate }: Props) {
  const { colors } = useTheme();
  const [slide, setSlide] = useState(0);
  const scrollRef = useRef<ScrollView>(null);
  const [heroSlides, setHeroSlides] = useState(staticHeroSlides);
  const [companions, setCompanions] = useState(staticCompanions);
  const [experiences, setExperiences] = useState(staticExperiences);
  const [packages, setPackages] = useState(staticPackages);

  useEffect(() => {
    (async () => {
      const [s, c, e, p] = await Promise.all([
        fetchSlides(),
        fetchCompanions(),
        fetchExperiences(),
        fetchPackages(),
      ]);
      if (s && s.length) setHeroSlides(s.map((x: any) => ({
        id: x.id,
        title: x.title,
        subtitle: x.subtitle,
        cta: x.cta,
        target: x.target || 'Home',
        bg: x.bg || '#E9E3FF',
        emoji: x.emoji || '💜',
      })));
      if (c && c.length) setCompanions(c);
      if (e && e.length) setExperiences(e);
      if (p && p.length) setPackages(p);
    })();
  }, []);

  useEffect(() => {
    if (!heroSlides.length) return;
    const t = setInterval(() => {
      setSlide((s) => {
        const next = (s + 1) % heroSlides.length;
        scrollRef.current?.scrollTo({ x: next * (SLIDE_W + 12), animated: true });
        return next;
      });
    }, 4200);
    return () => clearInterval(t);
  }, [heroSlides.length]);

  const onMomentum = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const x = e.nativeEvent.contentOffset.x;
    setSlide(Math.round(x / (SLIDE_W + 12)));
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]} showsVerticalScrollIndicator={false}>
      {/* Hero slider */}
      <View style={styles.sliderWrap}>
        <ScrollView
          ref={scrollRef}
          horizontal
          pagingEnabled={false}
          decelerationRate="fast"
          snapToInterval={SLIDE_W + 12}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 20 }}
          onMomentumScrollEnd={onMomentum}
        >
          {heroSlides.map((s) => (
            <TouchableOpacity
              key={s.id}
              activeOpacity={0.92}
              style={[styles.slide, { backgroundColor: s.bg }]}
              onPress={() => onNavigate(s.target)}
            >
              <Text style={styles.slideEmoji}>{s.emoji}</Text>
              <Text style={styles.slideTitle}>{s.title}</Text>
              <Text style={styles.slideSub}>{s.subtitle}</Text>
              <View style={styles.slideCta}>
                <Text style={styles.slideCtaText}>{s.cta} →</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
        <View style={styles.dots}>
          {heroSlides.map((_, i) => (
            <View key={i} style={[styles.dot, i === slide && styles.dotActive]} />
          ))}
        </View>
      </View>

      {/* Categories — mall grid (Amazon style) */}
      <Text style={styles.blockLabel}>SHOP BY VIBE</Text>
      <View style={styles.catGrid}>
        {mallCategories.map((c) => (
          <TouchableOpacity
            key={c.key}
            style={styles.catCard}
            activeOpacity={0.85}
            onPress={() => onNavigate(c.screen)}
          >
            <Text style={styles.catIcon}>{c.icon}</Text>
            <Text style={styles.catLabel}>{c.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Amazon-style Meet departments — Male · Female */}
      {meetSections.map((sec) => (
        <View key={sec.key}>
          <View style={styles.deptHead}>
            <View>
              <Text style={styles.blockLabel}>{sec.title}</Text>
              <Text style={styles.deptSub}>{sec.subtitle}</Text>
            </View>
          </View>
          <View style={styles.featureGrid}>
            {meetFeatures
              .filter((f) => f.section === sec.key)
              .map((f) => (
                <TouchableOpacity
                  key={f.key}
                  style={[styles.featureCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
                  activeOpacity={0.85}
                  onPress={() => onNavigate('FeatureDetail', { featureKey: f.key })}
                >
                  <View style={styles.featureIconBox}>
                    <Text style={styles.featureIcon}>{f.icon}</Text>
                  </View>
                  <Text style={styles.featureLabel} numberOfLines={1}>
                    {f.label}
                  </Text>
                  <Text style={styles.featureDesc} numberOfLines={1}>
                    {f.desc}
                  </Text>
                </TouchableOpacity>
              ))}
          </View>
        </View>
      ))}

      {/* Stats strip */}
      <View style={styles.statsRow}>
        {stats.slice(0, 4).map((s, i) => (
          <View key={i} style={styles.statItem}>
            <Text style={styles.statVal}>{s.value}</Text>
            <Text style={styles.statLab}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* Featured companions */}
      <View style={styles.sectionHead}>
        <Text style={styles.blockLabel}>FEATURED COMPANIONS</Text>
        <TouchableOpacity onPress={() => onNavigate('Companions')}>
          <Text style={styles.seeAll}>See all →</Text>
        </TouchableOpacity>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hPad}>
        {companions.slice(0, 5).map((c) => (
          <TouchableOpacity
            key={c.id}
            style={styles.compCard}
            activeOpacity={0.88}
            onPress={() => onNavigate('CompanionDetail', { companion: c })}
          >
            <View style={styles.compAvatar}>
              <Text style={{ fontSize: 32 }}>{c.icon}</Text>
            </View>
            <Text style={styles.compName} numberOfLines={1}>{c.name}</Text>
            <Text style={styles.compRole} numberOfLines={1}>{c.role}</Text>
            <Text style={styles.compRate}>₹{c.rate}/hr</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Experiences */}
      <View style={styles.sectionHead}>
        <Text style={styles.blockLabel}>PREMIUM EXPERIENCES</Text>
        <TouchableOpacity onPress={() => onNavigate('Experiences')}>
          <Text style={styles.seeAll}>See all →</Text>
        </TouchableOpacity>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hPad}>
        {experiences.slice(0, 4).map((exp) => (
          <TouchableOpacity
            key={exp.id}
            style={styles.expCard}
            activeOpacity={0.88}
            onPress={() => onNavigate('ExperienceDetail', { experience: exp })}
          >
            <Text style={styles.expIcon}>{exp.icon}</Text>
            <Text style={styles.expTitle}>{exp.title}</Text>
            <Text style={styles.expSub} numberOfLines={2}>{exp.subtitle}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Packages */}
      <Text style={[styles.blockLabel, { marginTop: 8 }]}>PACKAGES</Text>
      <View style={styles.pkgRow}>
        {packages.slice(0, 3).map((p) => (
          <TouchableOpacity
            key={p.id}
            style={[styles.pkgCard, p.popular && styles.pkgHot]}
            onPress={() => onNavigate('Booking', { package: p })}
            activeOpacity={0.88}
          >
            {p.popular && <Text style={styles.hotTag}>Popular</Text>}
            <Text style={styles.pkgTitle}>{p.title}</Text>
            <Text style={styles.pkgPrice}>₹{p.price}</Text>
            <Text style={styles.pkgUnit}>{p.unit}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Benefits */}
      <View style={styles.benefitBox}>
        <Text style={styles.benefitTitle}>Why StrangersMeet?</Text>
        {['Verified companions', 'Strictly platonic', 'Secure booking', 'Cities across India'].map(
          (t) => (
            <Text key={t} style={styles.benefitItem}>✓  {t}</Text>
          )
        )}
        <TouchableOpacity style={styles.primaryBtn} onPress={() => onNavigate('Booking')}>
          <Text style={styles.primaryBtnText}>Book instantly</Text>
        </TouchableOpacity>
      </View>

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: staticColors.background },
  sliderWrap: { marginTop: 12, marginBottom: 8 },
  slide: {
    width: SLIDE_W,
    marginRight: 12,
    borderRadius: 24,
    padding: 22,
    minHeight: 168,
    shadowColor: '#252432',
    shadowOffset: { width: 4, height: 8 },
    shadowOpacity: 0.1,
    shadowRadius: 14,
    elevation: 5,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.6)',
  },
  slideEmoji: { fontSize: 36, marginBottom: 10 },
  slideTitle: { color: staticColors.text, fontSize: 22, fontWeight: '800', marginBottom: 6 },
  slideSub: { color: staticColors.textSecondary, fontSize: 14, marginBottom: 14 },
  slideCta: {
    alignSelf: 'flex-start',
    backgroundColor: staticColors.surface,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 14,
    shadowColor: '#252432',
    shadowOffset: { width: 2, height: 3 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
  },
  slideCtaText: { color: staticColors.primary, fontWeight: '700', fontSize: 13 },
  dots: { flexDirection: 'row', justifyContent: 'center', marginTop: 12, gap: 6 },
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: staticColors.borderStrong },
  dotActive: { backgroundColor: staticColors.primary, width: 18 },
  blockLabel: {
    marginHorizontal: 20,
    marginTop: 20,
    marginBottom: 12,
    color: staticColors.textMuted,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.4,
  },
  catGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 14,
    gap: 10,
  },
  catCard: {
    width: (width - 28 - 30) / 4,
    backgroundColor: staticColors.surface,
    borderRadius: 18,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: staticColors.border,
    shadowColor: '#252432',
    shadowOffset: { width: 2, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  catIcon: { fontSize: 22, marginBottom: 6 },
  catLabel: { color: staticColors.textSecondary, fontSize: 10, fontWeight: '700', textAlign: 'center' },
  deptHead: {
    marginTop: 4,
  },
  deptSub: {
    marginHorizontal: 20,
    marginTop: -6,
    marginBottom: 10,
    color: staticColors.textMuted,
    fontSize: 11,
    fontWeight: '500',
  },
  featureGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 14,
    gap: 10,
  },
  featureCard: {
    width: (width - 28 - 20) / 3,
    backgroundColor: staticColors.surface,
    borderRadius: 16,
    paddingVertical: 12,
    paddingHorizontal: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: staticColors.border,
    shadowColor: '#252432',
    shadowOffset: { width: 2, height: 3 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  featureIconBox: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: staticColors.lavender,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  featureIcon: { fontSize: 20 },
  featureLabel: {
    color: staticColors.text,
    fontSize: 11,
    fontWeight: '700',
    textAlign: 'center',
  },
  featureDesc: {
    color: staticColors.textMuted,
    fontSize: 9,
    marginTop: 2,
    textAlign: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginTop: 18,
    backgroundColor: staticColors.lavender,
    borderRadius: 20,
    paddingVertical: 14,
    borderWidth: 1,
    borderColor: 'rgba(117,99,232,0.12)',
  },
  statItem: { flex: 1, alignItems: 'center' },
  statVal: { color: staticColors.primaryDark, fontWeight: '800', fontSize: 14 },
  statLab: { color: staticColors.textMuted, fontSize: 10, marginTop: 2 },
  sectionHead: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginRight: 20,
  },
  seeAll: { color: staticColors.primary, fontWeight: '700', fontSize: 13, marginTop: 20 },
  hPad: { paddingHorizontal: 20, gap: 12 },
  compCard: {
    width: 140,
    backgroundColor: staticColors.surface,
    borderRadius: 20,
    padding: 14,
    marginRight: 12,
    borderWidth: 1,
    borderColor: staticColors.border,
    shadowColor: '#252432',
    shadowOffset: { width: 3, height: 5 },
    shadowOpacity: 0.07,
    shadowRadius: 10,
    elevation: 3,
  },
  compAvatar: {
    width: 56,
    height: 56,
    borderRadius: 18,
    backgroundColor: staticColors.clayPink,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  compName: { color: staticColors.text, fontWeight: '800', fontSize: 14 },
  compRole: { color: staticColors.textMuted, fontSize: 11, marginTop: 2 },
  compRate: { color: staticColors.primary, fontWeight: '800', fontSize: 13, marginTop: 6 },
  expCard: {
    width: 160,
    backgroundColor: staticColors.surface,
    borderRadius: 20,
    padding: 16,
    marginRight: 12,
    borderWidth: 1,
    borderColor: staticColors.border,
    shadowColor: '#252432',
    shadowOffset: { width: 3, height: 5 },
    shadowOpacity: 0.07,
    shadowRadius: 10,
    elevation: 3,
  },
  expIcon: { fontSize: 28, marginBottom: 10 },
  expTitle: { color: staticColors.text, fontWeight: '800', fontSize: 15 },
  expSub: { color: staticColors.textMuted, fontSize: 12, marginTop: 4 },
  pkgRow: { flexDirection: 'row', paddingHorizontal: 16, gap: 10 },
  pkgCard: {
    flex: 1,
    backgroundColor: staticColors.surface,
    borderRadius: 18,
    padding: 12,
    borderWidth: 1,
    borderColor: staticColors.border,
    shadowColor: '#252432',
    shadowOffset: { width: 2, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  pkgHot: { backgroundColor: staticColors.peach, borderColor: 'rgba(229,165,75,0.25)' },
  hotTag: { color: staticColors.warning, fontSize: 10, fontWeight: '800', marginBottom: 4 },
  pkgTitle: { color: staticColors.text, fontWeight: '700', fontSize: 13 },
  pkgPrice: { color: staticColors.primary, fontWeight: '800', fontSize: 16, marginTop: 4 },
  pkgUnit: { color: staticColors.textMuted, fontSize: 10 },
  benefitBox: {
    marginHorizontal: 20,
    marginTop: 24,
    backgroundColor: staticColors.mint,
    borderRadius: 24,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(47,158,106,0.12)',
  },
  benefitTitle: { color: staticColors.text, fontWeight: '800', fontSize: 18, marginBottom: 12 },
  benefitItem: { color: staticColors.textSecondary, fontSize: 14, marginBottom: 6 },
  primaryBtn: {
    marginTop: 14,
    backgroundColor: staticColors.primary,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    shadowColor: staticColors.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 4,
  },
  primaryBtnText: { color: '#fff', fontWeight: '800', fontSize: 15 },
});
