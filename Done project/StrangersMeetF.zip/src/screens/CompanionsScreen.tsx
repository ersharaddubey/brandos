import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { colors } from '../theme/colors';
import { companions as staticCompanions } from '../data/experiences';
import { fetchCompanions } from '../api';

interface Props {
  onNavigate: (screen: string, params?: any) => void;
}

export default function CompanionsScreen({ onNavigate }: Props) {
  const [filter, setFilter] = useState<'all' | 'boyfriend' | 'girlfriend'>('all');
  const [companions, setCompanions] = useState(staticCompanions);

  useEffect(() => {
    (async () => {
      const c = await fetchCompanions();
      if (c && c.length) setCompanions(c);
    })();
  }, []);

  const list = useMemo(() => {
    if (filter === 'boyfriend') return companions.filter((c: any) => c.gender === 'male' || c.role?.toLowerCase().includes('boy'));
    if (filter === 'girlfriend') return companions.filter((c: any) => c.gender === 'female' || c.role?.toLowerCase().includes('girl'));
    return companions;
  }, [companions, filter]);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.label}>BOYFRIEND / GIRLFRIEND</Text>
        <Text style={styles.title}>Optional companion</Text>
        <Text style={styles.desc}>
          Event book karte time bhi add kar sakte ho. Yahan se directly bhi book.
          Verified · Platonic · Safe.
        </Text>
      </View>

      <View style={styles.filterRow}>
        {([
          { key: 'all' as const, label: 'All' },
          { key: 'boyfriend' as const, label: '💙 Boyfriend' },
          { key: 'girlfriend' as const, label: '💖 Girlfriend' },
        ]).map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[styles.filterBtn, filter === f.key && styles.filterBtnActive]}
            onPress={() => setFilter(f.key)}
          >
            <Text style={[styles.filterText, filter === f.key && styles.filterTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.list}>
        {list.map((c: any) => (
          <TouchableOpacity
            key={c.id}
            style={styles.card}
            activeOpacity={0.85}
            onPress={() => onNavigate('CompanionDetail', { companion: c })}
          >
            <Text style={styles.cardIcon}>{c.icon}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardName}>{c.name}</Text>
              <Text style={styles.cardRole}>
                {c.role} {c.verified ? '· 🪪' : ''} {c.city ? `· ${c.city}` : ''}
              </Text>
              <Text style={styles.cardBio} numberOfLines={2}>{c.bio}</Text>
            </View>
            <View style={styles.cardRight}>
              <Text style={styles.rate}>₹{c.rate}/hr</Text>
              <TouchableOpacity
                style={styles.bookBtn}
                onPress={() => onNavigate('Booking', { companion: c })}
              >
                <Text style={styles.bookBtnText}>Book</Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        ))}
      </View>
      <View style={{ height: 28 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 24, paddingTop: 20, paddingBottom: 8 },
  label: {
    color: colors.secondary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.6,
    marginBottom: 8,
  },
  title: { color: colors.text, fontSize: 26, fontWeight: '800', marginBottom: 8 },
  desc: { color: colors.textSecondary, fontSize: 14, lineHeight: 21 },
  filterRow: { flexDirection: 'row', paddingHorizontal: 20, gap: 8, marginTop: 12 },
  filterBtn: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    backgroundColor: colors.glass,
  },
  filterBtnActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  filterText: { color: colors.text, fontWeight: '700', fontSize: 12 },
  filterTextActive: { color: '#fff' },
  list: { padding: 16, gap: 10 },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.glass,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    padding: 14,
    gap: 12,
    marginBottom: 10,
  },
  cardIcon: { fontSize: 32 },
  cardName: { color: colors.text, fontWeight: '800', fontSize: 16 },
  cardRole: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  cardBio: { color: colors.textSecondary, fontSize: 12, marginTop: 4 },
  cardRight: { alignItems: 'flex-end', gap: 8 },
  rate: { color: colors.accent, fontWeight: '800' },
  bookBtn: {
    backgroundColor: colors.primary,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
  },
  bookBtnText: { color: '#fff', fontWeight: '700', fontSize: 12 },
});
