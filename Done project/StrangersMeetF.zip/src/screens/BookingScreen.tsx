import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import { createBooking } from '../api';
import {
  services,
  companions,
  durations,
  Companion,
  trustBadges,
} from '../data/experiences';

interface EventPref {
  id?: string;
  title: string;
  price: number;
  city?: string;
  date?: string;
  venue?: string;
}

interface Props {
  onBack: () => void;
  companion?: Companion | null;
  /** City event selected — price goes to cart */
  event?: EventPref | null;
  lookingForPref?: string;
  activityPref?: string;
  featureLabel?: string;
  featureIcon?: string;
  initialPackage?: { price: number; title: string } | null;
}

const PLATFORM_FEE = 49;

function parseEventPrice(price: string | number | undefined): number {
  if (typeof price === 'number') return price;
  if (!price) return 0;
  const n = String(price).replace(/[^\d]/g, '');
  return n ? parseInt(n, 10) : 0;
}

export default function BookingScreen({
  onBack,
  companion: initialCompanion,
  event: initialEvent,
  lookingForPref,
  activityPref,
  featureLabel,
  featureIcon,
}: Props) {
  const { colors } = useTheme();
  const [serviceId, setServiceId] = useState(
    services.find((s) => s.title === activityPref || s.title === featureLabel)?.id || services[0].id
  );
  const [durationIdx, setDurationIdx] = useState(1);
  const [mobile, setMobile] = useState('');
  const [addBfGf, setAddBfGf] = useState<'none' | 'boyfriend' | 'girlfriend'>(
    initialCompanion?.gender === 'female' ? 'girlfriend' : initialCompanion ? 'boyfriend' : 'none'
  );
  const [selectedCompanionId, setSelectedCompanionId] = useState(initialCompanion?.id || '');

  const eventPrice = initialEvent ? parseEventPrice(initialEvent.price) : 0;
  const hasEvent = !!initialEvent && eventPrice > 0;

  const bfList = useMemo(() => companions.filter((c) => c.gender === 'male'), []);
  const gfList = useMemo(() => companions.filter((c) => c.gender === 'female'), []);
  const companionList = addBfGf === 'girlfriend' ? gfList : addBfGf === 'boyfriend' ? bfList : [];
  const selectedCompanion =
    companions.find((c) => c.id === selectedCompanionId) ||
    (addBfGf !== 'none' ? companionList[0] : null);

  const hours = durations[durationIdx].hours;
  const service = services.find((s) => s.id === serviceId) || services[0];

  // Cart: event only OR service; + optional companion hours
  const cart = useMemo(() => {
    const items: { title: string; price: number }[] = [];
    if (hasEvent) {
      items.push({
        title: `Event: ${initialEvent!.title}`,
        price: eventPrice,
      });
    } else {
      items.push({
        title: `${service.title} · ${durations[durationIdx].label}`,
        price: (service.priceFrom || 699) * hours,
      });
    }
    if (addBfGf !== 'none' && selectedCompanion) {
      const cHours = hasEvent ? Math.max(hours, 2) : hours;
      items.push({
        title: `${selectedCompanion.role}: ${selectedCompanion.name} · ${cHours}h`,
        price: selectedCompanion.rate * cHours,
      });
    }
    return items;
  }, [hasEvent, initialEvent, eventPrice, service, durationIdx, hours, addBfGf, selectedCompanion]);

  const subtotal = cart.reduce((s, i) => s + i.price, 0);
  const total = subtotal + PLATFORM_FEE;

  const confirm = async () => {
    if (mobile.replace(/\D/g, '').length < 10) {
      Alert.alert('Mobile required', 'Enter a valid 10-digit WhatsApp number.');
      return;
    }
    const summary = cart.map((c) => c.title).join(' + ');
    await createBooking({
      lookingFor: addBfGf !== 'none' ? addBfGf : service.title,
      activity: hasEvent ? initialEvent!.title : service.title,
      duration: durations[durationIdx].label,
      mobile,
      total,
      companionId: selectedCompanion?.id,
      companionName: selectedCompanion?.name,
      feature: featureLabel || (hasEvent ? 'City Event' : service.title),
    });
    Alert.alert(
      'Booking request sent',
      `Cart:\n${cart.map((c) => `• ${c.title} — ₹${c.price}`).join('\n')}\nPlatform fee — ₹${PLATFORM_FEE}\nTotal — ₹${total}\n\nConfirm on WhatsApp: ${mobile}`,
      [{ text: 'OK', onPress: onBack }]
    );
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={[styles.label, { color: colors.secondary }]}>CART / BOOKING</Text>
        <Text style={[styles.title, { color: colors.text }]}>
          {featureIcon ? `${featureIcon} ` : ''}
          {hasEvent ? 'Event booking' : featureLabel || 'Book a service'}
        </Text>
        <Text style={[styles.desc, { color: colors.textMuted }]}>
          Event price → cart. Boyfriend / Girlfriend optional.
        </Text>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ paddingHorizontal: 16 }}>
        {trustBadges.map((b) => (
          <View key={b.label} style={[styles.trustChip, { borderColor: colors.cardBorder, backgroundColor: colors.glass }]}>
            <Text>{b.icon} </Text>
            <Text style={{ color: colors.textSecondary, fontSize: 11, fontWeight: '600' }}>{b.label}</Text>
          </View>
        ))}
      </ScrollView>

      {/* Event in cart */}
      {hasEvent && (
        <View style={[styles.card, { borderColor: colors.primary, backgroundColor: colors.glass }]}>
          <Text style={{ color: colors.secondary, fontSize: 10, fontWeight: '800', letterSpacing: 1 }}>CITY EVENT</Text>
          <Text style={{ color: colors.text, fontSize: 17, fontWeight: '800', marginTop: 4 }}>{initialEvent!.title}</Text>
          <Text style={{ color: colors.textMuted, fontSize: 12, marginTop: 2 }}>
            {[initialEvent!.city, initialEvent!.date, initialEvent!.venue].filter(Boolean).join(' · ')}
          </Text>
          <Text style={{ color: colors.accent, fontWeight: '800', fontSize: 16, marginTop: 8 }}>₹{eventPrice}</Text>
        </View>
      )}

      {/* Service picker — only if no event */}
      {!hasEvent && (
        <View style={{ paddingHorizontal: 16, marginTop: 12 }}>
          <Text style={[styles.fieldLabel, { color: colors.secondary }]}>SERVICE</Text>
          <View style={styles.grid}>
            {services.map((s) => (
              <TouchableOpacity
                key={s.id}
                onPress={() => setServiceId(s.id)}
                style={[
                  styles.serviceChip,
                  {
                    borderColor: serviceId === s.id ? colors.primary : colors.cardBorder,
                    backgroundColor: serviceId === s.id ? colors.primary + '22' : colors.glass,
                  },
                ]}
              >
                <Text style={{ fontSize: 18 }}>{s.icon}</Text>
                <Text style={{ color: colors.text, fontWeight: '700', fontSize: 11 }} numberOfLines={1}>{s.title}</Text>
                <Text style={{ color: colors.textMuted, fontSize: 10 }}>₹{s.priceFrom}+</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {/* Duration */}
      <View style={{ paddingHorizontal: 16, marginTop: 8 }}>
        <Text style={[styles.fieldLabel, { color: colors.secondary }]}>DURATION</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {durations.map((d, i) => (
            <TouchableOpacity
              key={d.label}
              onPress={() => setDurationIdx(i)}
              style={[
                styles.durChip,
                {
                  borderColor: durationIdx === i ? colors.primary : colors.cardBorder,
                  backgroundColor: durationIdx === i ? colors.primary : colors.glass,
                },
              ]}
            >
              <Text style={{ color: durationIdx === i ? '#fff' : colors.text, fontWeight: '700', fontSize: 12 }}>
                {d.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Optional BF / GF */}
      <View style={{ paddingHorizontal: 16, marginTop: 16 }}>
        <Text style={[styles.fieldLabel, { color: colors.secondary }]}>
          ADD BOYFRIEND / GIRLFRIEND (OPTIONAL)
        </Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {([
            { key: 'none' as const, label: 'No thanks' },
            { key: 'boyfriend' as const, label: '💙 Boyfriend' },
            { key: 'girlfriend' as const, label: '💖 Girlfriend' },
          ]).map((o) => (
            <TouchableOpacity
              key={o.key}
              onPress={() => {
                setAddBfGf(o.key);
                setSelectedCompanionId('');
              }}
              style={[
                styles.durChip,
                {
                  borderColor: addBfGf === o.key ? colors.primary : colors.cardBorder,
                  backgroundColor: addBfGf === o.key ? colors.primary + '22' : colors.glass,
                },
              ]}
            >
              <Text style={{ color: colors.text, fontWeight: '700', fontSize: 12 }}>{o.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {addBfGf !== 'none' && (
          <View style={{ marginTop: 10 }}>
            {companionList.map((c) => (
              <TouchableOpacity
                key={c.id}
                onPress={() => setSelectedCompanionId(c.id)}
                style={[
                  styles.compRow,
                  {
                    borderColor: (selectedCompanionId || companionList[0]?.id) === c.id ? colors.primary : colors.cardBorder,
                    backgroundColor: colors.glass,
                  },
                ]}
              >
                <Text style={{ fontSize: 22 }}>{c.icon}</Text>
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={{ color: colors.text, fontWeight: '800' }}>{c.name}</Text>
                  <Text style={{ color: colors.textMuted, fontSize: 12 }}>
                    {c.city} · ⭐ {c.rating} {c.verified ? '· 🪪' : ''}
                  </Text>
                </View>
                <Text style={{ color: colors.accent, fontWeight: '800' }}>₹{c.rate}/hr</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>

      {/* Mobile */}
      <View style={{ paddingHorizontal: 16, marginTop: 16 }}>
        <Text style={[styles.fieldLabel, { color: colors.secondary }]}>WHATSAPP NUMBER</Text>
        <TextInput
          style={[styles.input, { borderColor: colors.cardBorder, color: colors.text, backgroundColor: colors.glass }]}
          placeholder="10-digit mobile"
          placeholderTextColor={colors.textMuted}
          keyboardType="phone-pad"
          value={mobile}
          onChangeText={setMobile}
          maxLength={10}
        />
      </View>

      {/* Cart summary */}
      <View style={[styles.totalBox, { borderColor: colors.cardBorder, backgroundColor: colors.glass, marginHorizontal: 16 }]}>
        <Text style={{ color: colors.secondary, fontSize: 11, fontWeight: '800', letterSpacing: 1, marginBottom: 8 }}>
          YOUR CART
        </Text>
        {cart.map((line, i) => (
          <View key={i} style={styles.totalRow}>
            <Text style={{ color: colors.textMuted, flex: 1 }} numberOfLines={2}>{line.title}</Text>
            <Text style={{ color: colors.text }}>₹{line.price.toLocaleString()}</Text>
          </View>
        ))}
        <View style={styles.totalRow}>
          <Text style={{ color: colors.textMuted }}>Platform fee</Text>
          <Text style={{ color: colors.text }}>₹{PLATFORM_FEE}</Text>
        </View>
        <View style={[styles.totalRow, { marginTop: 8 }]}>
          <Text style={{ color: colors.text, fontWeight: '800', fontSize: 16 }}>Total</Text>
          <Text style={{ color: colors.primary, fontWeight: '800', fontSize: 18 }}>₹{total.toLocaleString()}</Text>
        </View>
      </View>

      <TouchableOpacity
        style={[styles.confirmBtn, { backgroundColor: colors.primary, marginHorizontal: 16 }]}
        onPress={confirm}
        activeOpacity={0.85}
      >
        <Text style={styles.confirmText}>Confirm · WhatsApp us</Text>
      </TouchableOpacity>
      <Text style={{ textAlign: 'center', color: colors.textMuted, fontSize: 11, marginTop: 8, marginBottom: 40 }}>
        Platonic only · Public venues · Cancel up to 2 hrs before
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 8 },
  label: { fontSize: 11, fontWeight: '800', letterSpacing: 1.2 },
  title: { fontSize: 22, fontWeight: '800', marginTop: 6 },
  desc: { fontSize: 13, marginTop: 4 },
  trustChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    marginRight: 8,
    marginVertical: 8,
  },
  card: {
    marginHorizontal: 16,
    marginTop: 8,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1.5,
  },
  fieldLabel: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1,
    marginBottom: 8,
  },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  serviceChip: {
    width: '30%',
    flexGrow: 1,
    minWidth: 100,
    borderWidth: 1,
    borderRadius: 12,
    padding: 10,
    alignItems: 'center',
  },
  durChip: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  compRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 14,
    padding: 12,
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 14,
    fontSize: 15,
  },
  totalBox: {
    marginTop: 20,
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
    gap: 8,
  },
  confirmBtn: {
    marginTop: 20,
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
  },
  confirmText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
