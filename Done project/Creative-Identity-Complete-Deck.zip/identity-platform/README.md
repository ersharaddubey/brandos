# Creative Identity

Reference → Understand → Lock → Prompt → Generate → Check → Improve → **Asset Bank** / **Open Shelf**

## Stack
- MongoDB + Mongoose
- Express (Node 18+)
- React (Vite) — liquid glass UI
- Ollama / vision for identity + consistency
- Generator: `mock` or `http` (FLUX)

## Pages
| Route | Purpose |
|-------|---------|
| `/` | Dashboard — clickable stats + flow links |
| `/identities` | Identity Lock — types: **product, character, environment, brand** only |
| `/prompts` | Prompt OS — private templates |
| `/studio` | Generate / compile prompts from locked identities |
| `/check` | Consistency check + Image Analysis |
| `/assets` | **Asset Bank** — private store, category filter, similar groups by category |
| `/open-shelf` | **Open Shelf** — shared store (assets + templates), category + group filters |

## Visibility
- **Asset Bank** = private
- **Open Shelf** = shared (renamed from Public Bank)
- Move either direction from Identity detail, Asset Bank, or Open Shelf

## Categories
Same four as Identity Lock types. Uploads and reference assets carry a category so similar groups cluster **within** product / character / environment / brand.

## Run
```bash
npm run setup
npm run dev
```
