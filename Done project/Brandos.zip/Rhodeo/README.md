# Rhodeo — Creative Identity Platform

Lock product · character · brand · environment identities once, then generate consistent images & videos across campaigns.

## Stack

| Layer | Tech |
|-------|------|
| Client | React 18 + Vite + Tailwind |
| API | Express + Mongoose |
| DB | MongoDB |
| Vision / LLM | Ollama (optional) |
| Generation | Mock / ComfyUI / A1111 / InvokeAI / fal etc. |

## Quick start

```bash
# 1. MongoDB running on localhost:27017
# 2. (Optional) Ollama with a vision model

cd server
cp .env.example .env          # edit keys / GENERATOR_PROVIDER=mock for local test
npm install
npm run dev                   # → http://localhost:5001

cd ../client
npm install
npm run dev                   # → http://localhost:5173  (proxies /api & /uploads)
```

Open http://localhost:5173 → **Identity Lock** → upload reference → Lock → **Studio**.

## Studio — Reference selection (updated)

- Select any number of **locked** identities (product + character + brand + environment, or multiple of the same type).
- Selected chips always show at the bottom with **type badge**.
- **+ Add reference…** dropdown lists remaining locked identities as `type · name` — no 3-item limit.
- Chips are ordered the same way the prompt compiler uses: character → product → brand → environment.
- Click **×** on a chip (or the card) to deselect.
- **Ad-hoc upload box** (strip ke neeche): type (brand / product / character / environment) select karo + image upload. Naya identity ban jata hai; analyse + Lock ke baad wapas Studio mein select kar sakte ho — purani + nayi dono saath use karke perfect banao.

This fixes the previous UX gap where after selecting 3 identities there was no clear way to add a 4th, and where type was not obvious when adding more. Ad-hoc upload se Studio se hi naya reference add ho sakta hai.

## Main flows

1. **Identity Lock** (`/identities`)  
   - Single reference upload + type, or  
   - “Extract all 4 from one image” (product / character / environment / brand layers).
2. **Studio** (`/studio`)  
   - Pick locked identities → campaign brief → Compile / Generate Image or Video.
3. **Asset Bank / Open Shelf** — private vs shared reference storage.
4. **Check** — consistency score against locked identity.
5. **Prompt OS / Workflow Builder** — templates & graphs.

## Generator providers

Set `GENERATOR_PROVIDER` in `server/.env`:

- `mock` — no external GPU, returns placeholder (good for UI testing)
- `comfyui` — local ComfyUI + InstantID / IP-Adapter workflows
- `a1111`, `invokeai`, etc. (see `.env.example`)

## Project layout

```
Rhodeo/
  client/          React app
  server/          Express API + services
  flux-server/     Optional FLUX helper
  transformers-service/  Optional grounding / SAM
  colab/           Colab notebooks
  docker-compose.integrations.yml
```

## Notes

- Only **locked** identities appear in Studio.
- Multiple references per identity are supported via Identity Detail → “Add another reference”.
- For full consistency, lock one identity per type you care about, then select the combination in Studio.
