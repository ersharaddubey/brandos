# Changelog

## 2026-10-24 — Studio reference UX + ad-hoc upload

### Added
- **Studio selected strip** always visible (even when empty).
- **“+ Add reference…”** dropdown chip: lists remaining locked identities as `type · name`.
  - Removes the previous “no 4th slot” friction after selecting 3 identities.
  - Works whether you select 1, 2, 3 or all 4+ identities.
- Selected chips + dropdown options sorted by type order (character → product → brand → environment) to match the prompt compiler.
- CSS for dashed `add-chip`.
- Root `README.md` with setup + Studio usage notes.
- **Ad-hoc upload box** (neeche selected-strip ke baad): type select (product / brand / character / environment) + optional name + image upload.
  - Studio se seedha naya reference bana sakte ho.
  - Identity create + analysis start hoti hai; Lock karne ke baad + Add reference se select karke purani + nayi dono use kar sakte ho.

### Changed
- Tour step & page subtitle text updated to describe unlimited selection and the + control.
- Help copy under the identity grid clarifies multi-select and the + button.

### Notes
- Ad-hoc upload creates identity (status analyzing). After analysis, go to Identity Lock → Lock, then return to Studio and select via + Add reference.
- Multiple references per identity remain available on Identity Detail → “Add another reference”.
